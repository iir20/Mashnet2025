import Sidebar from "@/components/layout/sidebar";
import TopBar from "@/components/layout/topbar";
import WelcomeBanner from "@/components/ui/welcome-banner";
import StatsCard from "@/components/ui/stats-card";
import AIAssistant from "@/components/ai/assistant";
import WalletConnect from "@/components/web3/wallet-connect";
import NFTBadges from "@/components/web3/nft-badges";
import TokenRewards from "@/components/web3/token-rewards";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import OrbitalChat from "@/components/visualizations/orbital-chat";

export default function Home() {
  const { data: chatrooms, isLoading: isLoadingChatrooms } = useQuery({
    queryKey: ['/api/chatrooms']
  });
  
  const { data: messages, isLoading: isLoadingMessages } = useQuery({
    queryKey: ['/api/chatrooms/1/messages']
  });
  
  return (
    <div className="flex flex-col lg:flex-row h-screen overflow-hidden">
      {/* Sidebar */}
      <Sidebar />
      
      {/* Main Content Area */}
      <main className="flex-1 flex flex-col overflow-hidden bg-space-dark">
        {/* Top Bar */}
        <TopBar title="AI Messaging Platform" />
        
        {/* Content Area with Scroll */}
        <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
          {/* Welcome Banner */}
          <WelcomeBanner 
            title="Welcome to"
            subtitle="Experience the future of communication with our Web3-powered AI messenger. Secure, decentralized, and intelligent conversations await."
          />
          
          {/* Stats Overview */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatsCard
              title="Active Chats"
              value={isLoadingChatrooms ? "..." : chatrooms?.length || 0}
              change="+2 this week"
              icon="ri-chat-3-line"
              iconColor="#00F0FF"
              iconBgColor="rgba(0,240,255,0.1)"
            />
            
            <StatsCard
              title="Messages"
              value={isLoadingMessages ? "..." : messages?.length || 0}
              change="+15 today"
              icon="ri-message-3-line"
              iconColor="#7B61FF"
              iconBgColor="rgba(123,97,255,0.1)"
              borderColor="neon-border-purple"
            />
            
            <StatsCard
              title="NFT Badges"
              value="2"
              change="1 pending"
              icon="ri-nft-line"
              iconColor="#FF00E5"
              iconBgColor="rgba(255,0,229,0.1)"
              borderColor="neon-border-magenta"
            />
            
            <StatsCard
              title="Token Balance"
              value="250"
              icon="ri-coins-line"
              iconColor="#00F0FF"
              iconBgColor="rgba(0,240,255,0.1)"
            />
          </div>
          
          {/* Main Content with Visualization and Sidebar */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Column - Visualization Section */}
            <div className="lg:col-span-2 space-y-6">
              {/* 3D Visualization */}
              <div className="glassmorphism rounded-xl border border-white/5 overflow-hidden">
                <div className="flex items-center justify-between p-4 border-b border-white/5">
                  <h3 className="font-display font-medium">Orbital Chat Visualization</h3>
                  <div className="flex items-center space-x-2">
                    <button className="p-1 rounded hover:bg-white/5">
                      <i className="ri-refresh-line"></i>
                    </button>
                    <button className="p-1 rounded hover:bg-white/5">
                      <i className="ri-more-2-fill"></i>
                    </button>
                  </div>
                </div>
                
                <div className="h-64">
                  {isLoadingMessages ? (
                    <div className="w-full h-full flex items-center justify-center">
                      <Skeleton className="w-4/5 h-4/5 rounded-lg" />
                    </div>
                  ) : (
                    <OrbitalChat messages={messages || []} />
                  )}
                </div>
              </div>
              
              {/* Recent Chatrooms */}
              <div className="glassmorphism rounded-xl border border-white/5 overflow-hidden">
                <div className="flex items-center justify-between p-4 border-b border-white/5">
                  <h3 className="font-display font-medium">Recent Chatrooms</h3>
                  <button className="text-sm text-[#00F0FF] hover:underline">View All</button>
                </div>
                
                <div className="p-4">
                  {isLoadingChatrooms ? (
                    <div className="space-y-3">
                      {[1, 2, 3].map(i => (
                        <Skeleton key={i} className="h-16 w-full" />
                      ))}
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {chatrooms?.map((chatroom: any) => (
                        <div 
                          key={chatroom.id}
                          className="flex items-center p-3 rounded-lg hover:bg-white/5 cursor-pointer border border-transparent hover:border-white/10"
                        >
                          <div 
                            className="w-10 h-10 rounded flex items-center justify-center mr-3"
                            style={{
                              backgroundColor: chatroom.type === 'multiverse' 
                                ? 'rgba(123,97,255,0.1)' 
                                : 'rgba(0,240,255,0.1)'
                            }}
                          >
                            <i className={`${
                              chatroom.type === 'multiverse' 
                                ? 'ri-space-ship-line text-[#7B61FF]' 
                                : 'ri-chat-3-line text-[#00F0FF]'
                            }`}></i>
                          </div>
                          <div className="flex-1 min-w-0">
                            <h4 className="text-sm font-medium truncate">{chatroom.name}</h4>
                            <p className="text-xs text-text-secondary">
                              {chatroom.type === 'multiverse' ? 'Multiverse Room' : 'Standard Chat'}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
            
            {/* Right Column - AI Assistant and Web3 Features */}
            <div className="space-y-6">
              {/* AI Assistant */}
              <AIAssistant />
              
              {/* Web3 Features */}
              <div className="glassmorphism rounded-xl border border-white/5 overflow-hidden">
                <div className="flex items-center justify-between p-4 border-b border-white/5">
                  <h3 className="font-display font-medium">Web3 Features</h3>
                  <div className="text-xs px-2 py-0.5 rounded bg-[rgba(255,214,0,0.1)] text-[#FFD600] flex items-center">
                    <i className="ri-wallet-3-line mr-1"></i> Wallet Required
                  </div>
                </div>
                
                <div className="p-4 space-y-4">
                  <WalletConnect />
                  <NFTBadges />
                  <TokenRewards />
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

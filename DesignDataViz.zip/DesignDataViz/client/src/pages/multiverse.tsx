import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/layout/sidebar";
import TopBar from "@/components/layout/topbar";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";

interface MultiverseRoom {
  id: number;
  name: string;
  type: string;
  metadata: {
    dimension?: string;
    color?: string;
  };
}

export default function Multiverse() {
  const [activeTab, setActiveTab] = useState<"explore" | "create">("explore");
  
  const { data: chatrooms, isLoading } = useQuery({
    queryKey: ['/api/chatrooms']
  });
  
  // Filter only multiverse chatrooms
  const multiverseRooms = chatrooms?.filter((room: MultiverseRoom) => room.type === 'multiverse') || [];
  
  return (
    <div className="flex flex-col lg:flex-row h-screen overflow-hidden">
      {/* Sidebar */}
      <Sidebar />
      
      {/* Main Content Area */}
      <main className="flex-1 flex flex-col overflow-hidden bg-space-dark">
        {/* Top Bar */}
        <TopBar title="Multiverse Chatrooms" />
        
        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
          {/* Banner */}
          <Card className="glassmorphism border-white/5 neon-border-purple animate-glow">
            <CardContent className="p-6">
              <div className="max-w-3xl">
                <h1 className="text-2xl font-display font-bold mb-3">
                  <span className="glow-text-purple">Multiverse</span> Chatrooms
                </h1>
                <p className="text-text-secondary mb-6">
                  Parallel chat dimensions where conversations can branch and evolve independently.
                  Each multiverse room creates a new timeline for your discussions.
                </p>
                
                <div className="flex space-x-4">
                  <Button
                    onClick={() => setActiveTab("explore")}
                    className={`${
                      activeTab === "explore"
                        ? "bg-[#7B61FF] text-white"
                        : "bg-[rgba(123,97,255,0.1)] text-[#7B61FF] border border-[rgba(123,97,255,0.3)]"
                    }`}
                  >
                    <i className="ri-space-ship-line mr-2"></i>
                    Explore Multiverses
                  </Button>
                  
                  <Button
                    onClick={() => setActiveTab("create")}
                    className={`${
                      activeTab === "create"
                        ? "bg-[#7B61FF] text-white"
                        : "bg-[rgba(123,97,255,0.1)] text-[#7B61FF] border border-[rgba(123,97,255,0.3)]"
                    }`}
                  >
                    <i className="ri-add-line mr-2"></i>
                    Create New Dimension
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Explore or Create Content */}
          {activeTab === "explore" ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {isLoading ? (
                Array(3).fill(0).map((_, i) => (
                  <Skeleton key={i} className="h-48 w-full rounded-xl" />
                ))
              ) : multiverseRooms.length > 0 ? (
                multiverseRooms.map((room: MultiverseRoom) => (
                  <Card 
                    key={room.id}
                    className="glassmorphism border-white/5 hover:neon-border-purple transition-all duration-300 overflow-hidden"
                  >
                    <div 
                      className="h-24 w-full"
                      style={{
                        background: `linear-gradient(to right, rgba(123,97,255,0.2), ${room.metadata?.color || '#7B61FF'}20)`
                      }}
                    >
                      <div className="w-full h-full flex items-center justify-center">
                        <div className="orbital-container w-[150px] h-[150px]">
                          <div className="orbital-center" style={{ width: '30px', height: '30px' }}></div>
                          <div className="orbital orbital-1" style={{ width: '70px', height: '70px' }}></div>
                          <div className="orbital orbital-2" style={{ width: '100px', height: '100px' }}></div>
                        </div>
                      </div>
                    </div>
                    
                    <CardContent className="p-4">
                      <h3 className="font-display font-medium text-lg mb-1">{room.name}</h3>
                      <p className="text-text-secondary text-sm mb-3">
                        Dimension: {room.metadata?.dimension || 'Alpha'}
                      </p>
                      
                      <Link href={`/chat/${room.id}`}>
                        <Button className="w-full bg-[rgba(123,97,255,0.1)] hover:bg-[rgba(123,97,255,0.2)] text-[#7B61FF] border border-[rgba(123,97,255,0.3)]">
                          <i className="ri-space-ship-line mr-2"></i>
                          Enter Dimension
                        </Button>
                      </Link>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <div className="col-span-full flex flex-col items-center justify-center p-8 glassmorphism rounded-xl border border-white/5">
                  <div className="w-16 h-16 rounded-full bg-[rgba(123,97,255,0.1)] flex items-center justify-center mb-4">
                    <i className="ri-planet-line text-2xl text-[#7B61FF]"></i>
                  </div>
                  <h3 className="text-xl font-display font-medium mb-2">No multiverse rooms found</h3>
                  <p className="text-text-secondary text-center mb-4">
                    Create your first multiverse dimension to start parallel conversations
                  </p>
                  <Button 
                    onClick={() => setActiveTab("create")}
                    className="bg-[#7B61FF] text-white"
                  >
                    <i className="ri-add-line mr-2"></i>
                    Create First Dimension
                  </Button>
                </div>
              )}
            </div>
          ) : (
            <Card className="glassmorphism border-white/5">
              <CardContent className="p-6">
                <h3 className="text-xl font-display font-medium mb-4">Create New Dimension</h3>
                
                <div className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Dimension Name</label>
                    <input 
                      type="text" 
                      className="w-full bg-[#161B22] rounded-lg px-4 py-2 border border-white/10 focus:outline-none focus:border-[rgba(123,97,255,0.5)]"
                      placeholder="Enter a name for your dimension"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Dimension Color</label>
                    <div className="flex space-x-2">
                      {["#7B61FF", "#FF00E5", "#00F0FF", "#FFD600", "#00FF9D"].map((color) => (
                        <div 
                          key={color}
                          className="w-8 h-8 rounded-full cursor-pointer"
                          style={{ 
                            backgroundColor: color,
                            boxShadow: `0 0 10px ${color}80`
                          }}
                        ></div>
                      ))}
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Visibility</label>
                    <div className="flex space-x-4">
                      <label className="flex items-center space-x-2 cursor-pointer">
                        <input type="radio" name="visibility" className="accent-[#7B61FF]" defaultChecked />
                        <span>Public</span>
                      </label>
                      <label className="flex items-center space-x-2 cursor-pointer">
                        <input type="radio" name="visibility" className="accent-[#7B61FF]" />
                        <span>Private</span>
                      </label>
                    </div>
                  </div>
                  
                  <Button className="w-full bg-[#7B61FF] text-white">
                    <i className="ri-space-ship-line mr-2"></i>
                    Create Dimension
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </div>
  );
}

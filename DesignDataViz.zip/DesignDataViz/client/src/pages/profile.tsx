import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import Sidebar from "@/components/layout/sidebar";
import TopBar from "@/components/layout/topbar";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import NFTBadges from "@/components/web3/nft-badges";
import TokenRewards from "@/components/web3/token-rewards";
import { useWeb3 } from "@/hooks/use-web3";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Tooltip, 
  TooltipContent, 
  TooltipProvider, 
  TooltipTrigger 
} from "@/components/ui/tooltip";
import { Progress } from "@/components/ui/progress";

export default function Profile() {
  const { toast } = useToast();
  const { isConnected, connectWallet, address } = useWeb3();
  const [isEditMode, setIsEditMode] = useState(false);
  const [activeTab, setActiveTab] = useState("profile");
  const [progress, setProgress] = useState(75);
  const [formData, setFormData] = useState({
    username: "",
    avatarUrl: "",
    bio: "",
    email: ""
  });
  
  // Holographic effects
  const [hologramAngle, setHologramAngle] = useState(0);
  
  // Update hologram effect
  useEffect(() => {
    const interval = setInterval(() => {
      setHologramAngle(prev => (prev + 1) % 360);
    }, 50);
    
    return () => clearInterval(interval);
  }, []);

  // Fetch user data
  const { data: user, isLoading } = useQuery({
    queryKey: ['/api/users/1']
  });

  // Initialize form data when user data is loaded
  useEffect(() => {
    if (user && !isEditMode) {
      setFormData({
        username: user.username || "",
        avatarUrl: user.avatarUrl || "",
        bio: user.bio || "Quantum Nexus explorer and digital nomad. Web3 enthusiast and crypto native.",
        email: user.email || "user@quantum-nexus.io"
      });
    }
  }, [user, isEditMode]);

  // Update user profile mutation
  const updateProfileMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest('PATCH', '/api/users/1', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ['/api/users/1']
      });
      setIsEditMode(false);
      toast({
        title: "Profile Updated",
        description: "Your profile has been successfully updated",
        variant: "default"
      });
    }
  });

  const handleSave = () => {
    updateProfileMutation.mutate(formData);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  // Level calculation
  const userLevel = Math.floor((user?.reputation || 0) / 100) + 1;
  const levelProgress = ((user?.reputation || 0) % 100);
  
  // Mock feature toggle
  const handleFeatureToggle = (feature: string) => {
    toast({
      title: `${feature} Toggled`,
      description: `${feature} has been updated`,
      variant: "default"
    });
  };

  return (
    <div className="flex flex-col lg:flex-row h-screen overflow-hidden">
      {/* Sidebar */}
      <Sidebar />
      
      {/* Main Content Area */}
      <main className="flex-1 flex flex-col overflow-hidden bg-space-dark">
        {/* Top Bar */}
        <TopBar title="User Profile" />
        
        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
          {/* Holographic Profile Banner */}
          <motion.div 
            className="relative overflow-hidden rounded-xl"
            style={{
              background: `linear-gradient(${hologramAngle}deg, rgba(0,240,255,0.1), rgba(123,97,255,0.1), rgba(255,0,229,0.1))`,
              boxShadow: '0 0 20px rgba(123,97,255,0.3)'
            }}
          >
            <div className="absolute inset-0 bg-[#0D1117]/60 backdrop-blur-sm"></div>
            <div className="relative p-6 z-10">
              <div className="max-w-3xl">
                <div className="flex items-center mb-4">
                  <div className="h-10 w-10 rounded-full bg-[rgba(123,97,255,0.2)] border border-[#7B61FF] flex items-center justify-center mr-4">
                    <i className="ri-user-3-line text-[#7B61FF]"></i>
                  </div>
                  <div>
                    <h1 className="text-2xl font-display font-bold">
                      <span className="glow-text-purple">Quantum Identity Profile</span>
                    </h1>
                    <div className="flex items-center gap-2 text-sm">
                      <span className="text-text-secondary">Level {userLevel}</span>
                      <div className="w-24 h-1.5 bg-black/20 rounded-full overflow-hidden">
                        <div 
                          className="h-full rounded-full bg-gradient-to-r from-[#7B61FF] to-[#FF00E5]" 
                          style={{ width: `${levelProgress}%` }}
                        />
                      </div>
                      <span className="text-xs text-text-secondary">{levelProgress}%</span>
                    </div>
                  </div>
                  
                  {/* Connection Status */}
                  <div className="ml-auto">
                    {isConnected ? (
                      <div className="flex items-center px-3 py-1.5 rounded-full bg-[rgba(0,240,255,0.1)] border border-[rgba(0,240,255,0.3)]">
                        <div className="w-2 h-2 rounded-full bg-[#00F0FF] mr-2 animate-pulse"></div>
                        <span className="text-xs text-[#00F0FF]">Connected to MetaMask</span>
                      </div>
                    ) : (
                      <Button onClick={connectWallet} className="bg-[rgba(123,97,255,0.1)] text-[#7B61FF] border border-[#7B61FF]/30 hover:bg-[rgba(123,97,255,0.2)]">
                        <i className="ri-wallet-3-line mr-2"></i>
                        Connect Wallet
                      </Button>
                    )}
                  </div>
                </div>
                
                <div className="flex flex-wrap gap-4 mt-2">
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <div className="bg-[rgba(123,97,255,0.1)] text-[#7B61FF] border border-[#7B61FF]/30 rounded-full px-3 py-1 text-xs flex items-center gap-1">
                          <i className="ri-flash-line"></i>
                          <span>{user?.tokenBalance || 0} $MASH</span>
                        </div>
                      </TooltipTrigger>
                      <TooltipContent className="bg-black/80 border-[#7B61FF]/20">
                        <p className="text-xs">$MASH Tokens</p>
                        <p className="text-[10px] text-text-secondary">Earned from activity</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                  
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <div className="bg-[rgba(0,240,255,0.1)] text-[#00F0FF] border border-[#00F0FF]/30 rounded-full px-3 py-1 text-xs flex items-center gap-1">
                          <i className="ri-shield-star-line"></i>
                          <span>Verified Account</span>
                        </div>
                      </TooltipTrigger>
                      <TooltipContent className="bg-black/80 border-[#00F0FF]/20">
                        <p className="text-xs">Verified Quantum Identity</p>
                        <p className="text-[10px] text-text-secondary">Enhanced trust level</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
              </div>
            </div>
          </motion.div>
          
          {/* Main Tabs Navigation */}
          <Tabs defaultValue="profile" className="w-full" onValueChange={value => setActiveTab(value)}>
            <TabsList className="w-full bg-black/30 backdrop-blur-sm border border-white/5 rounded-lg p-1">
              <TabsTrigger 
                value="profile" 
                className="data-[state=active]:bg-[rgba(123,97,255,0.1)] data-[state=active]:text-[#7B61FF] rounded-md flex-1"
              >
                <i className="ri-user-3-line mr-2"></i>
                Profile
              </TabsTrigger>
              <TabsTrigger 
                value="security" 
                className="data-[state=active]:bg-[rgba(0,240,255,0.1)] data-[state=active]:text-[#00F0FF] rounded-md flex-1"
              >
                <i className="ri-lock-2-line mr-2"></i>
                Security
              </TabsTrigger>
              <TabsTrigger 
                value="web3" 
                className="data-[state=active]:bg-[rgba(255,0,229,0.1)] data-[state=active]:text-[#FF00E5] rounded-md flex-1"
              >
                <i className="ri-currency-ethereum-line mr-2"></i>
                Web3
              </TabsTrigger>
              <TabsTrigger 
                value="settings" 
                className="data-[state=active]:bg-[rgba(255,214,0,0.1)] data-[state=active]:text-[#FFD600] rounded-md flex-1"
              >
                <i className="ri-settings-4-line mr-2"></i>
                Settings
              </TabsTrigger>
            </TabsList>
            
            {/* Profile Tab Content */}
            <TabsContent value="profile" className="mt-4">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 space-y-6">
                  {/* User Profile Card */}
                  <Card className="glassmorphism border-white/5 overflow-hidden">
                    <CardContent className="p-6 relative">
                      {/* Holographic Element */}
                      <div className="absolute -top-6 -right-6 w-24 h-24 rounded-full bg-gradient-to-br from-[#7B61FF]/20 to-[#FF00E5]/20 blur-xl"></div>
                      
                      {isLoading ? (
                        <div className="space-y-4">
                          <Skeleton className="h-24 w-24 rounded-full" />
                          <Skeleton className="h-8 w-48" />
                          <Skeleton className="h-4 w-64" />
                        </div>
                      ) : (
                        <div className="flex flex-col md:flex-row gap-6">
                          {/* Avatar */}
                          <div className="flex flex-col items-center space-y-2">
                            <motion.div 
                              className="w-28 h-28 rounded-full bg-[rgba(123,97,255,0.1)] border-2 border-[#7B61FF]/50 flex items-center justify-center overflow-hidden relative"
                              whileHover={{ scale: 1.05, borderColor: 'rgba(123,97,255,0.8)' }}
                            >
                              {user?.avatarUrl ? (
                                <img src={user.avatarUrl} alt="User Avatar" className="w-full h-full object-cover" />
                              ) : (
                                <i className="ri-user-3-line text-5xl text-[#7B61FF]"></i>
                              )}
                              
                              {/* Holographic overlay */}
                              <div className="absolute inset-0 bg-gradient-to-br from-transparent via-[#7B61FF]/10 to-transparent opacity-50"></div>
                              <div className="absolute -inset-1 bg-gradient-to-r from-[#7B61FF]/0 via-[#7B61FF]/20 to-[#7B61FF]/0" 
                                style={{ 
                                  transform: `translateX(${Math.sin(hologramAngle * Math.PI / 180) * 100}%)`,
                                  transition: 'transform 0.5s ease-out'
                                }} 
                              />
                            </motion.div>
                            
                            {isEditMode && (
                              <div className="text-xs text-text-secondary">
                                Upload avatar feature coming soon
                              </div>
                            )}
                          </div>
                          
                          {/* Profile Details */}
                          <div className="flex-1 space-y-4">
                            {isEditMode ? (
                              <div className="space-y-4">
                                <div>
                                  <label className="text-sm text-text-secondary mb-1 block">Username</label>
                                  <input 
                                    type="text" 
                                    name="username"
                                    value={formData.username}
                                    onChange={handleInputChange}
                                    className="w-full bg-[#161B22] rounded-lg px-4 py-2 border border-white/10 focus:outline-none focus:border-[rgba(123,97,255,0.5)]"
                                  />
                                </div>
                                
                                <div>
                                  <label className="text-sm text-text-secondary mb-1 block">Bio</label>
                                  <textarea 
                                    name="bio"
                                    value={formData.bio}
                                    onChange={handleInputChange}
                                    className="w-full bg-[#161B22] rounded-lg px-4 py-2 border border-white/10 focus:outline-none focus:border-[rgba(123,97,255,0.5)] min-h-[80px]"
                                  />
                                </div>
                                
                                <div>
                                  <label className="text-sm text-text-secondary mb-1 block">Email</label>
                                  <input 
                                    type="email" 
                                    name="email"
                                    value={formData.email}
                                    onChange={handleInputChange}
                                    className="w-full bg-[#161B22] rounded-lg px-4 py-2 border border-white/10 focus:outline-none focus:border-[rgba(123,97,255,0.5)]"
                                  />
                                </div>
                                
                                <div className="flex space-x-2">
                                  <Button onClick={handleSave} className="bg-[#7B61FF] hover:bg-[#6b50ff]">
                                    <i className="ri-save-line mr-2"></i>
                                    Save Changes
                                  </Button>
                                  <Button variant="outline" onClick={() => setIsEditMode(false)}>
                                    Cancel
                                  </Button>
                                </div>
                              </div>
                            ) : (
                              <div>
                                <h2 className="text-3xl font-display font-bold mb-1 text-white">
                                  {user?.username || "Anonymous User"}
                                </h2>
                                
                                <div className="flex flex-wrap gap-2 mb-3">
                                  <div className="text-xs px-2 py-1 rounded-full bg-[rgba(0,240,255,0.1)] border border-[rgba(0,240,255,0.3)] text-[#00F0FF] flex items-center">
                                    <i className="ri-medal-line mr-1"></i>
                                    Level {userLevel}
                                  </div>
                                  <div className="text-xs px-2 py-1 rounded-full bg-[rgba(255,0,229,0.1)] border border-[rgba(255,0,229,0.3)] text-[#FF00E5] flex items-center">
                                    <i className="ri-award-line mr-1"></i>
                                    NFT Badges: {user?.nftBadges?.length || 0}
                                  </div>
                                </div>
                                
                                <p className="text-text-secondary mb-4">
                                  {formData.bio}
                                </p>
                                
                                <div className="space-y-2">
                                  <div className="flex items-center">
                                    <i className="ri-mail-line text-text-secondary mr-2"></i>
                                    <span className="text-sm">
                                      {formData.email}
                                    </span>
                                  </div>
                                  
                                  <div className="flex items-center">
                                    <i className="ri-wallet-3-line text-text-secondary mr-2"></i>
                                    <span className="text-sm font-mono">
                                      {isConnected ? `${address?.substring(0, 6)}...${address?.substring(address.length - 4)}` : "Not connected to wallet"}
                                    </span>
                                  </div>
                                  
                                  <div className="flex items-center">
                                    <i className="ri-calendar-line text-text-secondary mr-2"></i>
                                    <span className="text-sm">
                                      Joined: {user?.createdAt ? new Date(user.createdAt).toLocaleDateString() : "Unknown"}
                                    </span>
                                  </div>
                                </div>
                                
                                <Button 
                                  onClick={() => setIsEditMode(true)} 
                                  className="mt-4 bg-[rgba(123,97,255,0.1)] hover:bg-[rgba(123,97,255,0.2)] text-[#7B61FF] border border-[rgba(123,97,255,0.3)]"
                                >
                                  <i className="ri-edit-line mr-2"></i>
                                  Edit Profile
                                </Button>
                              </div>
                            )}
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                  
                  {/* Recent Activity */}
                  <Card className="glassmorphism border-white/5 overflow-hidden">
                    <CardHeader className="pb-0">
                      <h3 className="text-xl font-display font-medium">Recent Activity</h3>
                    </CardHeader>
                    <CardContent className="p-6">
                      <div className="space-y-4">
                        <div className="flex gap-3 items-start border-b border-white/5 pb-4">
                          <div className="w-10 h-10 rounded-full bg-[rgba(0,240,255,0.1)] flex items-center justify-center flex-shrink-0">
                            <i className="ri-message-3-line text-[#00F0FF]"></i>
                          </div>
                          <div className="flex-1">
                            <div className="flex justify-between">
                              <h4 className="font-medium">Sent a quantum-encrypted message</h4>
                              <span className="text-xs text-text-secondary">2h ago</span>
                            </div>
                            <p className="text-sm text-text-secondary">You earned 5 $MASH tokens for active participation</p>
                          </div>
                        </div>
                        
                        <div className="flex gap-3 items-start border-b border-white/5 pb-4">
                          <div className="w-10 h-10 rounded-full bg-[rgba(255,0,229,0.1)] flex items-center justify-center flex-shrink-0">
                            <i className="ri-nft-line text-[#FF00E5]"></i>
                          </div>
                          <div className="flex-1">
                            <div className="flex justify-between">
                              <h4 className="font-medium">Received "Glitchmaster" NFT badge</h4>
                              <span className="text-xs text-text-secondary">Yesterday</span>
                            </div>
                            <p className="text-sm text-text-secondary">Awarded for being an active community member</p>
                          </div>
                        </div>
                        
                        <div className="flex gap-3 items-start">
                          <div className="w-10 h-10 rounded-full bg-[rgba(123,97,255,0.1)] flex items-center justify-center flex-shrink-0">
                            <i className="ri-wallet-3-line text-[#7B61FF]"></i>
                          </div>
                          <div className="flex-1">
                            <div className="flex justify-between">
                              <h4 className="font-medium">Connected MetaMask wallet</h4>
                              <span className="text-xs text-text-secondary">3 days ago</span>
                            </div>
                            <p className="text-sm text-text-secondary">Unlocked Web3 features in Quantum Nexus</p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
                
                {/* Right Column */}
                <div className="space-y-6">
                  {/* User Statistics */}
                  <Card className="glassmorphism border-white/5 overflow-hidden">
                    <CardHeader className="pb-0">
                      <h3 className="text-lg font-display font-medium">User Stats</h3>
                    </CardHeader>
                    <CardContent className="p-6">
                      <div className="space-y-4">
                        <div>
                          <div className="flex justify-between mb-1">
                            <span className="text-sm">Reputation</span>
                            <span className="text-sm text-[#00F0FF]">{user?.reputation || 0}/1000</span>
                          </div>
                          <Progress value={(user?.reputation || 0) / 10} className="h-2 bg-white/5">
                            <div className="h-full bg-gradient-to-r from-[#00F0FF] to-[#00b8ff] rounded-full" />
                          </Progress>
                        </div>
                        
                        <div>
                          <div className="flex justify-between mb-1">
                            <span className="text-sm">Messages Sent</span>
                            <span className="text-sm text-[#FF00E5]">142</span>
                          </div>
                          <Progress value={14.2} className="h-2 bg-white/5">
                            <div className="h-full bg-gradient-to-r from-[#FF00E5] to-[#7B61FF] rounded-full" />
                          </Progress>
                        </div>
                        
                        <div>
                          <div className="flex justify-between mb-1">
                            <span className="text-sm">$MASH Tokens</span>
                            <span className="text-sm text-[#7B61FF]">{user?.tokenBalance || 0}</span>
                          </div>
                          <Progress value={(user?.tokenBalance || 0) / 5} className="h-2 bg-white/5" max={100}>
                            <div className="h-full bg-gradient-to-r from-[#7B61FF] to-[#9C1AFF] rounded-full" />
                          </Progress>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  {/* NFT Badges */}
                  <NFTBadges />
                  
                  {/* Token Rewards */}
                  <TokenRewards />
                </div>
              </div>
            </TabsContent>
            
            {/* Security Tab Content */}
            <TabsContent value="security" className="mt-4">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 space-y-6">
                  {/* Security Overview */}
                  <Card className="glassmorphism border-white/5 overflow-hidden">
                    <CardHeader className="pb-0">
                      <h3 className="text-xl font-display font-medium">Security Overview</h3>
                    </CardHeader>
                    <CardContent className="p-6">
                      <div className="flex items-center gap-4 mb-6">
                        <div className="w-16 h-16 rounded-full flex items-center justify-center bg-gradient-to-br from-[#00F0FF]/20 to-[#00F0FF]/5 border border-[#00F0FF]/30">
                          <span className="text-2xl text-[#00F0FF] font-bold">A+</span>
                        </div>
                        <div>
                          <h4 className="font-bold">Excellent Security</h4>
                          <p className="text-sm text-text-secondary">Your account has post-quantum encryption enabled</p>
                        </div>
                      </div>
                      
                      <div className="space-y-4">
                        <div className="flex justify-between items-center py-2 border-b border-white/5">
                          <div>
                            <h4 className="font-medium">Post-Quantum Encryption</h4>
                            <p className="text-sm text-text-secondary">Enhanced security for your messages</p>
                          </div>
                          <div onClick={() => handleFeatureToggle("Post-Quantum Encryption")} className="flex items-center cursor-pointer">
                            <div className="w-12 h-6 rounded-full bg-[rgba(0,240,255,0.2)] flex items-center px-1">
                              <div className="w-4 h-4 rounded-full bg-[#00F0FF] ml-auto"></div>
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex justify-between items-center py-2 border-b border-white/5">
                          <div>
                            <h4 className="font-medium">Biometric Authentication</h4>
                            <p className="text-sm text-text-secondary">Use fingerprint or face recognition</p>
                          </div>
                          <div onClick={() => handleFeatureToggle("Biometric Authentication")} className="flex items-center cursor-pointer">
                            <div className="w-12 h-6 rounded-full bg-white/5 flex items-center px-1">
                              <div className="w-4 h-4 rounded-full bg-white/20"></div>
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex justify-between items-center py-2 border-b border-white/5">
                          <div>
                            <h4 className="font-medium">Two-Factor Authentication</h4>
                            <p className="text-sm text-text-secondary">Add an extra layer of security</p>
                          </div>
                          <div onClick={() => handleFeatureToggle("Two-Factor Authentication")} className="flex items-center cursor-pointer">
                            <div className="w-12 h-6 rounded-full bg-white/5 flex items-center px-1">
                              <div className="w-4 h-4 rounded-full bg-white/20"></div>
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex justify-between items-center py-2 border-b border-white/5">
                          <div>
                            <h4 className="font-medium">Emergency SOS Mode</h4>
                            <p className="text-sm text-text-secondary">Quick data purge in emergency situations</p>
                          </div>
                          <Button 
                            onClick={() => handleFeatureToggle("Emergency SOS")}
                            className="bg-[rgba(255,69,69,0.1)] hover:bg-[rgba(255,69,69,0.2)] text-[#FF4545] border border-[rgba(255,69,69,0.3)]"
                          >
                            Configure
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  {/* Privacy Settings */}
                  <Card className="glassmorphism border-white/5 overflow-hidden">
                    <CardHeader className="pb-0">
                      <h3 className="text-xl font-display font-medium">Privacy Settings</h3>
                    </CardHeader>
                    <CardContent className="p-6">
                      <div className="space-y-4">
                        <div className="flex justify-between items-center py-2 border-b border-white/5">
                          <div>
                            <h4 className="font-medium">Anonymous Mode</h4>
                            <p className="text-sm text-text-secondary">Hide your identity in public rooms</p>
                          </div>
                          <div onClick={() => handleFeatureToggle("Anonymous Mode")} className="flex items-center cursor-pointer">
                            <div className="w-12 h-6 rounded-full bg-[rgba(123,97,255,0.2)] flex items-center px-1">
                              <div className="w-4 h-4 rounded-full bg-[#7B61FF] ml-auto"></div>
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex justify-between items-center py-2 border-b border-white/5">
                          <div>
                            <h4 className="font-medium">Darknet Whisper Mode</h4>
                            <p className="text-sm text-text-secondary">Ultra-secure messaging channel</p>
                          </div>
                          <div onClick={() => handleFeatureToggle("Darknet Whisper Mode")} className="flex items-center cursor-pointer">
                            <div className="w-12 h-6 rounded-full bg-white/5 flex items-center px-1">
                              <div className="w-4 h-4 rounded-full bg-white/20"></div>
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex justify-between items-center py-2 border-b border-white/5">
                          <div>
                            <h4 className="font-medium">Geo-Location Sharing</h4>
                            <p className="text-sm text-text-secondary">Allow others to see your location</p>
                          </div>
                          <div onClick={() => handleFeatureToggle("Geo-Location Sharing")} className="flex items-center cursor-pointer">
                            <div className="w-12 h-6 rounded-full bg-white/5 flex items-center px-1">
                              <div className="w-4 h-4 rounded-full bg-white/20"></div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
                
                {/* Right Column */}
                <div className="space-y-6">
                  {/* Security Features */}
                  <Card className="glassmorphism border-white/5 overflow-hidden">
                    <CardHeader className="pb-0">
                      <h3 className="text-lg font-display font-medium">Advanced Security</h3>
                    </CardHeader>
                    <CardContent className="p-6">
                      <div className="space-y-4">
                        {/* Time Capsule */}
                        <div 
                          className="flex items-center justify-between cursor-pointer p-3 rounded-lg bg-[rgba(255,0,229,0.05)] border border-[rgba(255,0,229,0.1)] hover:bg-[rgba(255,0,229,0.1)] transition-all duration-300"
                          onClick={() => handleFeatureToggle("Time Capsule")}
                        >
                          <div className="flex items-center">
                            <div className="w-10 h-10 rounded-lg bg-[rgba(255,0,229,0.1)] flex items-center justify-center mr-3">
                              <i className="ri-time-line text-xl text-[#FF00E5]"></i>
                            </div>
                            <div>
                              <h4 className="text-sm font-medium">Time Capsule</h4>
                              <p className="text-xs text-text-secondary">Schedule future messages</p>
                            </div>
                          </div>
                          <i className="ri-arrow-right-line text-text-secondary"></i>
                        </div>
                        
                        {/* Geo-Fencing */}
                        <div 
                          className="flex items-center justify-between cursor-pointer p-3 rounded-lg bg-[rgba(0,240,255,0.05)] border border-[rgba(0,240,255,0.1)] hover:bg-[rgba(0,240,255,0.1)] transition-all duration-300"
                          onClick={() => handleFeatureToggle("Geo-Fencing")}
                        >
                          <div className="flex items-center">
                            <div className="w-10 h-10 rounded-lg bg-[rgba(0,240,255,0.1)] flex items-center justify-center mr-3">
                              <i className="ri-map-pin-line text-xl text-[#00F0FF]"></i>
                            </div>
                            <div>
                              <h4 className="text-sm font-medium">Geo-Fencing</h4>
                              <p className="text-xs text-text-secondary">Location-based security</p>
                            </div>
                          </div>
                          <i className="ri-arrow-right-line text-text-secondary"></i>
                        </div>
                        
                        {/* Emergency Contacts */}
                        <div 
                          className="flex items-center justify-between cursor-pointer p-3 rounded-lg bg-[rgba(255,69,69,0.05)] border border-[rgba(255,69,69,0.1)] hover:bg-[rgba(255,69,69,0.1)] transition-all duration-300"
                          onClick={() => handleFeatureToggle("Emergency Contacts")}
                        >
                          <div className="flex items-center">
                            <div className="w-10 h-10 rounded-lg bg-[rgba(255,69,69,0.1)] flex items-center justify-center mr-3">
                              <i className="ri-contacts-line text-xl text-[#FF4545]"></i>
                            </div>
                            <div>
                              <h4 className="text-sm font-medium">Emergency Contacts</h4>
                              <p className="text-xs text-text-secondary">Set up your safety network</p>
                            </div>
                          </div>
                          <i className="ri-arrow-right-line text-text-secondary"></i>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  {/* Security Log */}
                  <Card className="glassmorphism border-white/5 overflow-hidden">
                    <CardHeader className="pb-0">
                      <h3 className="text-lg font-display font-medium">Security Log</h3>
                    </CardHeader>
                    <CardContent className="p-6">
                      <div className="space-y-3">
                        <div className="flex justify-between items-start">
                          <div>
                            <h4 className="text-sm font-medium">Login from new device</h4>
                            <p className="text-xs text-text-secondary">Desktop - Chrome - New York</p>
                          </div>
                          <span className="text-xs text-text-secondary">1d ago</span>
                        </div>
                        
                        <div className="flex justify-between items-start">
                          <div>
                            <h4 className="text-sm font-medium">Password changed</h4>
                            <p className="text-xs text-text-secondary">Security update</p>
                          </div>
                          <span className="text-xs text-text-secondary">7d ago</span>
                        </div>
                        
                        <div className="flex justify-between items-start">
                          <div>
                            <h4 className="text-sm font-medium">Account created</h4>
                            <p className="text-xs text-text-secondary">Welcome to Quantum Nexus</p>
                          </div>
                          <span className="text-xs text-text-secondary">14d ago</span>
                        </div>
                      </div>
                      
                      <Button 
                        className="mt-4 w-full bg-[rgba(255,255,255,0.05)] hover:bg-[rgba(255,255,255,0.1)] text-text-secondary"
                        variant="outline"
                      >
                        View Full Log
                      </Button>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>
            
            {/* Web3 Tab Content */}
            <TabsContent value="web3" className="mt-4">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 space-y-6">
                  {/* Web3 Identity */}
                  <Card className="glassmorphism border-white/5 overflow-hidden">
                    <CardHeader className="pb-0">
                      <h3 className="text-xl font-display font-medium">Web3 Identity</h3>
                    </CardHeader>
                    <CardContent className="p-6">
                      <div className="flex flex-col md:flex-row gap-6">
                        {isConnected ? (
                          <div className="w-full space-y-4">
                            <div className="flex flex-col md:flex-row gap-4 p-4 rounded-lg bg-[rgba(123,97,255,0.05)] border border-[rgba(123,97,255,0.1)]">
                              <div className="w-16 h-16 rounded-full bg-[rgba(123,97,255,0.1)] flex items-center justify-center">
                                <i className="ri-wallet-3-fill text-3xl text-[#7B61FF]"></i>
                              </div>
                              <div className="flex-1">
                                <h4 className="font-medium">Connected Wallet</h4>
                                <p className="text-sm text-text-secondary mb-2">Your Ethereum wallet is connected</p>
                                <div className="p-2 bg-[#161B22] rounded-md text-xs font-mono text-text-secondary mb-3">
                                  {address || "0x0000000000000000000000000000000000000000"}
                                </div>
                                <div className="flex flex-wrap gap-2">
                                  <Button 
                                    className="text-xs h-8 bg-[rgba(123,97,255,0.1)] hover:bg-[rgba(123,97,255,0.2)] text-[#7B61FF] border border-[rgba(123,97,255,0.3)]"
                                    onClick={() => toast({
                                      title: "Wallet Copied",
                                      description: "Wallet address copied to clipboard",
                                      variant: "default"
                                    })}
                                  >
                                    <i className="ri-file-copy-line mr-1"></i>
                                    Copy Address
                                  </Button>
                                  
                                  <Button 
                                    className="text-xs h-8 bg-[rgba(255,69,69,0.1)] hover:bg-[rgba(255,69,69,0.2)] text-[#FF4545] border border-[rgba(255,69,69,0.3)]"
                                    onClick={() => toast({
                                      title: "Wallet Disconnected",
                                      description: "Your wallet has been disconnected",
                                      variant: "default"
                                    })}
                                  >
                                    <i className="ri-logout-box-line mr-1"></i>
                                    Disconnect
                                  </Button>
                                </div>
                              </div>
                            </div>
                            
                            <div className="p-4 rounded-lg bg-[rgba(0,240,255,0.05)] border border-[rgba(0,240,255,0.1)]">
                              <h4 className="font-medium mb-3">Token Balance</h4>
                              <div className="flex justify-between items-center">
                                <div className="flex items-center gap-2">
                                  <div className="w-8 h-8 rounded-full bg-[rgba(123,97,255,0.1)] flex items-center justify-center">
                                    <i className="ri-currency-line text-[#7B61FF]"></i>
                                  </div>
                                  <span>$MASH Token</span>
                                </div>
                                <span className="text-lg font-bold">{user?.tokenBalance || 0}</span>
                              </div>
                            </div>
                          </div>
                        ) : (
                          <div className="w-full flex flex-col items-center justify-center gap-6 p-8">
                            <div className="w-24 h-24 rounded-full bg-[rgba(123,97,255,0.05)] flex items-center justify-center">
                              <i className="ri-wallet-3-line text-4xl text-[#7B61FF]"></i>
                            </div>
                            <div className="text-center">
                              <h3 className="text-lg font-medium mb-2">Connect Your Wallet</h3>
                              <p className="text-text-secondary mb-4">Connect your Ethereum wallet to access Web3 features</p>
                              <Button onClick={connectWallet} className="bg-[#7B61FF] hover:bg-[#6b50ff]">
                                <i className="ri-wallet-3-line mr-2"></i>
                                Connect MetaMask
                              </Button>
                            </div>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                  
                  {/* NFT Showcase */}
                  <Card className="glassmorphism border-white/5 overflow-hidden">
                    <CardHeader className="pb-0">
                      <div className="flex justify-between items-center">
                        <h3 className="text-xl font-display font-medium">NFT Badges</h3>
                        <Button variant="ghost" className="text-[#7B61FF]">View All</Button>
                      </div>
                    </CardHeader>
                    <CardContent className="p-6">
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                        <div className="bg-[rgba(123,97,255,0.05)] rounded-lg border border-[rgba(123,97,255,0.1)] p-4 flex flex-col items-center">
                          <div className="w-20 h-20 bg-[rgba(123,97,255,0.1)] rounded-lg mb-3 flex items-center justify-center">
                            <i className="ri-code-box-line text-3xl text-[#7B61FF]"></i>
                          </div>
                          <h4 className="text-sm font-medium">Glitchmaster</h4>
                          <p className="text-xs text-text-secondary text-center">Master of digital anomalies</p>
                        </div>
                        
                        <div className="bg-[rgba(0,240,255,0.05)] rounded-lg border border-[rgba(0,240,255,0.1)] p-4 flex flex-col items-center">
                          <div className="w-20 h-20 bg-[rgba(0,240,255,0.1)] rounded-lg mb-3 flex items-center justify-center">
                            <i className="ri-shield-star-line text-3xl text-[#00F0FF]"></i>
                          </div>
                          <h4 className="text-sm font-medium">Mesh Lord</h4>
                          <p className="text-xs text-text-secondary text-center">Network routing expert</p>
                        </div>
                        
                        <div className="bg-[rgba(255,0,229,0.05)] rounded-lg border border-[rgba(255,0,229,0.1)] p-4 flex flex-col items-center">
                          <div className="w-20 h-20 bg-[rgba(255,0,229,0.1)] rounded-lg mb-3 flex items-center justify-center">
                            <i className="ri-vip-crown-line text-3xl text-[#FF00E5]"></i>
                          </div>
                          <h4 className="text-sm font-medium">Quantum Pioneer</h4>
                          <p className="text-xs text-text-secondary text-center">Early adopter</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
                
                {/* Right Column */}
                <div className="space-y-6">
                  {/* Token Rewards */}
                  <TokenRewards />
                  
                  {/* IPFS Stats */}
                  <Card className="glassmorphism border-white/5 overflow-hidden">
                    <CardHeader className="pb-0">
                      <h3 className="text-lg font-display font-medium">IPFS Storage</h3>
                    </CardHeader>
                    <CardContent className="p-6">
                      <div className="flex flex-col gap-4">
                        <div className="flex items-center gap-3 mb-2">
                          <div className="w-10 h-10 rounded-lg bg-[rgba(0,240,255,0.1)] flex items-center justify-center">
                            <i className="ri-hard-drive-line text-[#00F0FF]"></i>
                          </div>
                          <div>
                            <h4 className="text-sm font-medium">Decentralized Storage</h4>
                            <p className="text-xs text-text-secondary">Via InterPlanetary File System</p>
                          </div>
                        </div>
                        
                        <div className="space-y-3">
                          <div className="flex justify-between items-center">
                            <span className="text-xs text-text-secondary">Storage Used</span>
                            <span className="text-xs">12.3 MB / 1 GB</span>
                          </div>
                          <Progress value={1.23} className="h-1.5 bg-white/5">
                            <div className="h-full bg-gradient-to-r from-[#00F0FF] to-[#00b8ff] rounded-full" />
                          </Progress>
                        </div>
                        
                        <div className="flex justify-between items-center text-sm">
                          <span>Files Stored</span>
                          <span>16 files</span>
                        </div>
                        
                        <div className="flex justify-between items-center text-sm">
                          <span>Connected Peers</span>
                          <span>8 peers</span>
                        </div>
                        
                        <Button 
                          className="mt-2 w-full bg-[rgba(0,240,255,0.1)] hover:bg-[rgba(0,240,255,0.2)] text-[#00F0FF] border border-[rgba(0,240,255,0.3)]"
                        >
                          <i className="ri-hard-drive-line mr-2"></i>
                          Manage IPFS
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                  
                  {/* Anonymous Confessions */}
                  <Card className="glassmorphism border-white/5 overflow-hidden hover:neon-border-cyan transition-all duration-300">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between cursor-pointer">
                        <div className="flex items-center">
                          <div className="w-10 h-10 rounded-lg bg-[rgba(0,240,255,0.1)] flex items-center justify-center mr-3">
                            <i className="ri-ghost-line text-xl text-[#00F0FF]"></i>
                          </div>
                          <div>
                            <h4 className="text-sm font-medium">Anonymous Booth</h4>
                            <p className="text-xs text-text-secondary">Send anonymous messages</p>
                          </div>
                        </div>
                        <div className="text-xs px-2 py-0.5 rounded-full bg-[rgba(255,214,0,0.1)] text-[#FFD600]">
                          Coming Soon
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>
            
            {/* Settings Tab Content */}
            <TabsContent value="settings" className="mt-4">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 space-y-6">
                  {/* App Settings */}
                  <Card className="glassmorphism border-white/5 overflow-hidden">
                    <CardHeader className="pb-0">
                      <h3 className="text-xl font-display font-medium">App Settings</h3>
                    </CardHeader>
                    <CardContent className="p-6">
                      <div className="space-y-4">
                        <div className="flex justify-between items-center py-2 border-b border-white/5">
                          <div>
                            <h4 className="font-medium">Dark Mode</h4>
                            <p className="text-sm text-text-secondary">Quantum dark theme</p>
                          </div>
                          <div className="flex items-center">
                            <div className="w-12 h-6 rounded-full bg-[rgba(123,97,255,0.2)] flex items-center px-1 cursor-pointer" onClick={() => handleFeatureToggle("Dark Mode")}>
                              <div className="w-4 h-4 rounded-full bg-[#7B61FF] ml-auto"></div>
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex justify-between items-center py-2 border-b border-white/5">
                          <div>
                            <h4 className="font-medium">Notifications</h4>
                            <p className="text-sm text-text-secondary">Get alerts for new messages</p>
                          </div>
                          <div className="flex items-center">
                            <div className="w-12 h-6 rounded-full bg-[rgba(0,240,255,0.2)] flex items-center px-1 cursor-pointer" onClick={() => handleFeatureToggle("Notifications")}>
                              <div className="w-4 h-4 rounded-full bg-[#00F0FF] ml-auto"></div>
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex justify-between items-center py-2 border-b border-white/5">
                          <div>
                            <h4 className="font-medium">Voice Commands</h4>
                            <p className="text-sm text-text-secondary">Control app with your voice</p>
                          </div>
                          <div className="flex items-center">
                            <div className="w-12 h-6 rounded-full bg-white/5 flex items-center px-1 cursor-pointer" onClick={() => handleFeatureToggle("Voice Commands")}>
                              <div className="w-4 h-4 rounded-full bg-white/20"></div>
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex justify-between items-center py-2 border-b border-white/5">
                          <div>
                            <h4 className="font-medium">3D Orbital UI</h4>
                            <p className="text-sm text-text-secondary">Enable immersive 3D interface</p>
                          </div>
                          <div className="flex items-center">
                            <div className="w-12 h-6 rounded-full bg-[rgba(255,0,229,0.2)] flex items-center px-1 cursor-pointer" onClick={() => handleFeatureToggle("3D Orbital UI")}>
                              <div className="w-4 h-4 rounded-full bg-[#FF00E5] ml-auto"></div>
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex justify-between items-center py-2 border-b border-white/5">
                          <div>
                            <h4 className="font-medium">Hive Mind AI Mode</h4>
                            <p className="text-sm text-text-secondary">AI-powered group suggestions</p>
                          </div>
                          <div className="flex items-center">
                            <div className="w-12 h-6 rounded-full bg-white/5 flex items-center px-1 cursor-pointer" onClick={() => handleFeatureToggle("Hive Mind AI")}>
                              <div className="w-4 h-4 rounded-full bg-white/20"></div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  {/* Language & Accessibility */}
                  <Card className="glassmorphism border-white/5 overflow-hidden">
                    <CardHeader className="pb-0">
                      <h3 className="text-xl font-display font-medium">Language & Accessibility</h3>
                    </CardHeader>
                    <CardContent className="p-6">
                      <div className="space-y-4">
                        <div className="flex justify-between items-center py-2 border-b border-white/5">
                          <div>
                            <h4 className="font-medium">Language</h4>
                            <p className="text-sm text-text-secondary">Choose your preferred language</p>
                          </div>
                          <select className="bg-[#161B22] text-sm rounded-md border border-white/10 p-1.5 focus:outline-none focus:border-[rgba(123,97,255,0.5)]">
                            <option>English</option>
                            <option>Spanish</option>
                            <option>Japanese</option>
                            <option>German</option>
                            <option>French</option>
                          </select>
                        </div>
                        
                        <div className="flex justify-between items-center py-2 border-b border-white/5">
                          <div>
                            <h4 className="font-medium">Font Size</h4>
                            <p className="text-sm text-text-secondary">Adjust text display size</p>
                          </div>
                          <select className="bg-[#161B22] text-sm rounded-md border border-white/10 p-1.5 focus:outline-none focus:border-[rgba(123,97,255,0.5)]">
                            <option>Small</option>
                            <option selected>Medium</option>
                            <option>Large</option>
                            <option>Extra Large</option>
                          </select>
                        </div>
                        
                        <div className="flex justify-between items-center py-2 border-b border-white/5">
                          <div>
                            <h4 className="font-medium">Reduced Motion</h4>
                            <p className="text-sm text-text-secondary">Limit animations for accessibility</p>
                          </div>
                          <div className="flex items-center">
                            <div className="w-12 h-6 rounded-full bg-white/5 flex items-center px-1 cursor-pointer" onClick={() => handleFeatureToggle("Reduced Motion")}>
                              <div className="w-4 h-4 rounded-full bg-white/20"></div>
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex justify-between items-center py-2 border-b border-white/5">
                          <div>
                            <h4 className="font-medium">High Contrast</h4>
                            <p className="text-sm text-text-secondary">Improve visual accessibility</p>
                          </div>
                          <div className="flex items-center">
                            <div className="w-12 h-6 rounded-full bg-white/5 flex items-center px-1 cursor-pointer" onClick={() => handleFeatureToggle("High Contrast")}>
                              <div className="w-4 h-4 rounded-full bg-white/20"></div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
                
                {/* Right Column */}
                <div className="space-y-6">
                  {/* Account Management */}
                  <Card className="glassmorphism border-white/5 overflow-hidden">
                    <CardHeader className="pb-0">
                      <h3 className="text-lg font-display font-medium">Account Management</h3>
                    </CardHeader>
                    <CardContent className="p-6">
                      <div className="space-y-3">
                        <Button className="w-full justify-start bg-[rgba(123,97,255,0.1)] hover:bg-[rgba(123,97,255,0.2)] text-[#7B61FF] border border-[rgba(123,97,255,0.3)]">
                          <i className="ri-lock-password-line mr-2"></i>
                          Change Password
                        </Button>
                        
                        <Button className="w-full justify-start bg-[rgba(0,240,255,0.1)] hover:bg-[rgba(0,240,255,0.2)] text-[#00F0FF] border border-[rgba(0,240,255,0.3)]">
                          <i className="ri-download-2-line mr-2"></i>
                          Export Data
                        </Button>
                        
                        <Button className="w-full justify-start bg-[rgba(255,0,229,0.1)] hover:bg-[rgba(255,0,229,0.2)] text-[#FF00E5] border border-[rgba(255,0,229,0.3)]">
                          <i className="ri-delete-bin-2-line mr-2"></i>
                          Delete Cache
                        </Button>
                        
                        <Button className="w-full justify-start bg-[rgba(255,69,69,0.1)] hover:bg-[rgba(255,69,69,0.2)] text-[#FF4545] border border-[rgba(255,69,69,0.3)]">
                          <i className="ri-logout-box-r-line mr-2"></i>
                          Log Out
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                  
                  {/* About & Support */}
                  <Card className="glassmorphism border-white/5 overflow-hidden">
                    <CardHeader className="pb-0">
                      <h3 className="text-lg font-display font-medium">About & Support</h3>
                    </CardHeader>
                    <CardContent className="p-6">
                      <div className="space-y-4">
                        <div className="flex flex-col items-center mb-4">
                          <h4 className="text-xl font-bold glow-text">Quantum Nexus 3.0</h4>
                          <p className="text-xs text-text-secondary">Version 0.9.5 Beta</p>
                        </div>
                        
                        <div className="flex justify-between items-center text-sm">
                          <span>Check for Updates</span>
                          <Button variant="ghost" size="sm" className="h-8 px-2">
                            <i className="ri-refresh-line text-[#7B61FF]"></i>
                          </Button>
                        </div>
                        
                        <div className="flex justify-between items-center text-sm">
                          <span>Support</span>
                          <Button variant="ghost" size="sm" className="h-8 px-2">
                            <i className="ri-question-line text-[#00F0FF]"></i>
                          </Button>
                        </div>
                        
                        <div className="flex justify-between items-center text-sm">
                          <span>Privacy Policy</span>
                          <Button variant="ghost" size="sm" className="h-8 px-2">
                            <i className="ri-file-list-line text-[#FF00E5]"></i>
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  );
}

import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/layout/sidebar";
import TopBar from "@/components/layout/topbar";
import ChatInterface from "@/components/chat/chat-interface";

export default function Chat() {
  const { id } = useParams<{ id: string }>();
  const chatroomId = parseInt(id || "1");
  
  const { data: chatroom, isLoading } = useQuery({
    queryKey: [`/api/chatrooms/${chatroomId}`],
    enabled: !!chatroomId
  });
  
  return (
    <div className="flex flex-col lg:flex-row h-screen overflow-hidden">
      {/* Sidebar */}
      <Sidebar />
      
      {/* Main Content Area */}
      <main className="flex-1 flex flex-col overflow-hidden bg-space-dark">
        {/* Top Bar */}
        <TopBar title={isLoading ? "Loading..." : `${chatroom?.name || 'Chat'}`} />
        
        {/* Chat Interface */}
        <ChatInterface />
      </main>
    </div>
  );
}

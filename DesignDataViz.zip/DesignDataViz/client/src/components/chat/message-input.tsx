import { useState, useRef, useEffect } from "react";

interface MessageInputProps {
  onSendMessage: (content: string) => void;
  isEncrypted: boolean;
  isPending: boolean;
  isP2PEnabled?: boolean;
}

export default function MessageInput({ onSendMessage, isEncrypted, isPending, isP2PEnabled = false }: MessageInputProps) {
  const [message, setMessage] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  
  // Simulated voice recognition
  const toggleVoiceRecognition = () => {
    if (!isListening) {
      setIsListening(true);
      setIsRecording(true);
      
      // Simulate processing for 2 seconds
      setTimeout(() => {
        setIsRecording(false);
        // Simulate voice recognition result
        setMessage(prev => prev + (prev ? " " : "") + "Voice message simulation");
        setIsListening(false);
      }, 2000);
    } else {
      setIsListening(false);
      setIsRecording(false);
    }
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim() && !isPending) {
      onSendMessage(message);
      setMessage("");
    }
  };
  
  // Focus input on mount
  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.focus();
    }
  }, []);
  
  return (
    <form onSubmit={handleSubmit} className="flex items-center space-x-2">
      <div className="flex-1 relative">
        <input
          ref={inputRef}
          type="text"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          disabled={isPending}
          className="w-full bg-[#161B22] rounded-lg px-4 py-2 border border-white/10 focus:outline-none focus:border-[rgba(123,97,255,0.5)] text-sm"
          placeholder={`Type a message${isEncrypted ? ' (Quantum encrypted)' : ''}${isP2PEnabled ? ' (P2P MashNet)' : ''}...`}
        />
        <button 
          type="button"
          onClick={toggleVoiceRecognition}
          className={`absolute right-2 top-1/2 transform -translate-y-1/2 p-1 rounded-full ${
            isListening 
              ? 'bg-[rgba(255,0,229,0.2)]' 
              : 'hover:bg-[rgba(123,97,255,0.1)]'
          }`}
        >
          <i className={`${isRecording ? 'ri-record-circle-line text-[#FF00E5]' : 'ri-mic-line text-[#7B61FF]'}`}></i>
        </button>
      </div>
      
      <button 
        type="submit" 
        disabled={!message.trim() || isPending}
        className={`p-2 rounded-lg ${
          !message.trim() || isPending
            ? 'bg-[rgba(123,97,255,0.3)]'
            : 'bg-[#7B61FF] hover:bg-[rgba(123,97,255,0.8)]'
        } transition-colors duration-200`}
      >
        {isPending ? (
          <i className="ri-loader-4-line animate-spin text-white"></i>
        ) : (
          <i className="ri-send-plane-fill text-white"></i>
        )}
      </button>
    </form>
  );
}

import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useParams } from "wouter";
import { queryClient, apiRequest } from "@/lib/queryClient";
import MessageBubble from "./message-bubble";
import MessageInput from "./message-input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { useChat } from "@/hooks/use-chat";
import { useIPFS } from "@/hooks/use-ipfs";
import { Skeleton } from "@/components/ui/skeleton";
import OrbitalChat from "../visualizations/orbital-chat";
import QuantumParticles from "../visualizations/quantum-particles";
import VideoCall from "../call/video-call";

interface Message {
  id: number;
  senderId: number;
  chatroomId: number;
  content: string;
  isEncrypted: boolean;
  metadata: Record<string, any>;
  disappearAt: Date | null;
  createdAt: Date;
}

interface ChatUser {
  id: number;
  username: string;
  avatarUrl: string | null;
}

export default function ChatInterface() {
  const { id } = useParams<{ id: string }>();
  const chatroomId = parseInt(id || "1");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Chat state
  const [view, setView] = useState<"standard" | "orbital" | "quantum">("standard");
  const [isVideoCallActive, setIsVideoCallActive] = useState(false);
  const [isChatSettingsOpen, setIsChatSettingsOpen] = useState(false);
  const [scheduledMessage, setScheduledMessage] = useState("");
  const [deliveryDate, setDeliveryDate] = useState<Date | null>(null);
  const [hoverMessage, setHoverMessage] = useState<Message | null>(null);
  
  // Modal states
  const [showEncryptionInfo, setShowEncryptionInfo] = useState(false);
  const [showMultiverseModal, setShowMultiverseModal] = useState(false);
  
  // Enhanced chat features
  const { 
    // Basic features
    isQuantumEnabled, toggleQuantumMode,
    isP2PEnabled, initiateP2PConnection, p2pPeers,
    isConnected, isTyping,
    
    // Video call
    initiateVideoCall, endVideoCall,
    
    // Security features
    encryptionLevel, toggleEncryptionLevel,
    disappearTime, changeDisappearTime,
    biometricEnabled, toggleBiometricAuth,
    isWhisperModeActive, toggleWhisperMode,
    
    // Localization features
    emergencyMode, toggleEmergencyMode,
    geoFencing, toggleGeoFencing,
    locationData,
    
    // Multiverse
    multiverseMode, toggleMultiverseMode,
    activeMultiverseFork,
    
    // Offline features
    offlineMode, toggleOfflineMode,
    
    // Time features
    timeCapsulesEnabled, toggleTimeCapsules,
    scheduleTimeCapsule,
    
    // AI features
    hiveMindEnabled, toggleHiveBrain,
    activeHiveBrainSuggestions,
    translationActive, toggleTranslation,
    aiMoodDetection,
    
    // IPFS
    ipfs,
    
    // WebRTC
    webrtc
  } = useChat({
    initialQuantumMode: false,
    initialP2PMode: false,
    initialEncryptionLevel: 'standard',
    initialDisappearTime: 60,
    initialMultiverseMode: 'standard'
  });
  
  // Query chat data
  const { data: messages = [], isLoading: isLoadingMessages } = useQuery<Message[]>({
    queryKey: [`/api/chatrooms/${chatroomId}/messages`],
    enabled: !!chatroomId
  });

  const { data: chatroom, isLoading: isLoadingChatroom } = useQuery<{
    id: number;
    name: string;
    type: string;
  }>({
    queryKey: [`/api/chatrooms/${chatroomId}`],
    enabled: !!chatroomId
  });

  const { data: participants = [], isLoading: isLoadingParticipants } = useQuery<ChatUser[]>({
    queryKey: [`/api/chatrooms/${chatroomId}/participants`],
    enabled: !!chatroomId
  });

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      // If IPFS is enabled, store message in IPFS first
      let messageCid = null;
      if (ipfs.isConnected && isP2PEnabled) {
        messageCid = await ipfs.addContent(JSON.stringify({
          content,
          timestamp: new Date().toISOString(),
          encryptionLevel
        }));
      }
      
      // Send message to API
      return apiRequest('POST', '/api/messages', {
        chatroomId,
        senderId: 1, // Using default user ID
        content: messageCid ? `ipfs://${messageCid}` : content,
        isEncrypted: isQuantumEnabled,
        disappearAt: isQuantumEnabled ? new Date(Date.now() + disappearTime * 1000) : null,
        metadata: {
          isP2P: isP2PEnabled,
          p2pProtocol: isP2PEnabled ? "MashNet_v1.0" : null,
          routingNodes: isP2PEnabled ? p2pPeers.slice(0, 3) : [],
          hops: isP2PEnabled ? Math.floor(Math.random() * 3) + 1 : 0,
          encryptionLevel,
          multiverseFork: activeMultiverseFork,
          hiveMindEnhanced: hiveMindEnabled,
          offlineDelivery: offlineMode,
          geofenced: geoFencing,
          language: translationActive ? 'en' : undefined,
          whisperMode: isWhisperModeActive,
          ipfsCid: messageCid
        }
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: [`/api/chatrooms/${chatroomId}/messages`]
      });
    }
  });

  // Handle sending messages
  const handleSendMessage = (content: string) => {
    if (content.trim()) {
      sendMessageMutation.mutate(content);
    }
  };
  
  // Handle scheduling time capsule messages
  const handleScheduleMessage = () => {
    if (!scheduledMessage.trim() || !deliveryDate || deliveryDate <= new Date()) {
      return;
    }
    
    const capsuleId = scheduleTimeCapsule(scheduledMessage, deliveryDate);
    if (capsuleId) {
      setScheduledMessage('');
      setDeliveryDate(null);
    }
  };
  
  // Handle start video call
  const handleStartVideoCall = () => {
    initiateVideoCall();
    setIsVideoCallActive(true);
  };
  
  // Handle end video call
  const handleEndVideoCall = () => {
    endVideoCall();
    setIsVideoCallActive(false);
  };

  // Scroll to bottom when new messages arrive
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);
  
  // Set up IPFS if P2P is enabled
  useEffect(() => {
    if (isP2PEnabled && !ipfs.isConnected && !ipfs.isConnecting) {
      ipfs.connect();
    }
  }, [isP2PEnabled, ipfs]);

  // Loading state
  if (isLoadingChatroom) {
    return (
      <div className="flex-1 flex flex-col h-full">
        <div className="p-4 border-b border-white/5">
          <Skeleton className="h-6 w-48" />
        </div>
        <div className="flex-1 p-4 space-y-4 overflow-y-auto">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-16 w-full" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col h-full">
      {/* Chat Header */}
      <div className="p-3 border-b border-white/5 glassmorphism flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 rounded-full bg-[rgba(0,240,255,0.1)] neon-border flex items-center justify-center">
            <i className="ri-chat-3-line text-[#00F0FF]"></i>
          </div>
          <div>
            <div className="flex items-center">
              <h3 className="font-medium">{chatroom?.name || 'Chat'}</h3>
              {activeMultiverseFork && (
                <Badge className="ml-2 bg-[rgba(123,97,255,0.2)] text-[#7B61FF] text-xs">
                  Fork: {activeMultiverseFork.split('-')[1]}
                </Badge>
              )}
            </div>
            <div className="flex items-center space-x-2">
              <p className="text-xs text-text-secondary">
                {isLoadingParticipants ? 'Loading...' : `${participants?.length || 0} participants`}
              </p>
              
              {/* Status indicators */}
              <div className="flex items-center space-x-1">
                {isP2PEnabled && (
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Badge className="h-4 px-1 bg-[rgba(123,97,255,0.2)] text-[#7B61FF] text-[10px]">
                          <i className="ri-share-line mr-0.5 text-[10px]"></i>P2P
                        </Badge>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p className="text-xs">P2P MashNet: {p2pPeers.length} peers</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                )}
                
                {isQuantumEnabled && (
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Badge className="h-4 px-1 bg-[rgba(255,0,229,0.2)] text-[#FF00E5] text-[10px]">
                          <i className="ri-lock-line mr-0.5 text-[10px]"></i>Q
                        </Badge>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p className="text-xs">Quantum Encryption: {encryptionLevel}</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                )}
                
                {offlineMode && (
                  <Badge className="h-4 px-1 bg-[rgba(255,105,0,0.2)] text-[#FF6900] text-[10px]">
                    <i className="ri-wifi-off-line mr-0.5 text-[10px]"></i>Offline
                  </Badge>
                )}
                
                {geoFencing && locationData && (
                  <Badge className="h-4 px-1 bg-[rgba(0,240,255,0.2)] text-[#00F0FF] text-[10px]">
                    <i className="ri-map-pin-line mr-0.5 text-[10px]"></i>Geo
                  </Badge>
                )}
              </div>
            </div>
          </div>
        </div>
        
        <div className="flex items-center space-x-1">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={toggleQuantumMode}
                  className={`px-2 py-1 text-xs rounded-full ${isQuantumEnabled ? 'bg-[rgba(255,0,229,0.2)] text-[#FF00E5]' : 'hover:bg-white/5'}`}
                >
                  <i className={`ri-${isQuantumEnabled ? 'lock' : 'lock-unlock'}-line mr-1`}></i>
                  {isQuantumEnabled ? 'Quantum' : 'Standard'}
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p className="text-xs">{isQuantumEnabled ? 'Quantum mode enables message encryption and auto-delete' : 'Standard mode with no encryption'}</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
          
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={initiateP2PConnection}
                  className={`px-2 py-1 text-xs rounded-full ${isP2PEnabled ? 'bg-[rgba(123,97,255,0.2)] text-[#7B61FF]' : 'hover:bg-white/5'}`}
                >
                  <i className={`ri-share-${isP2PEnabled ? 'fill' : 'line'} mr-1`}></i>
                  {isP2PEnabled ? 'MashNet' : 'P2P'}
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p className="text-xs">{isP2PEnabled ? 'Connected to decentralized MashNet P2P network' : 'Enable peer-to-peer messaging'}</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
          
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className="px-2 py-1 text-xs rounded-full hover:bg-white/5"
              >
                <i className="ri-more-2-line"></i>
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-56 p-2 bg-[#0a0a0a] border-white/10">
              <div className="grid grid-cols-2 gap-1">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setView(view === "standard" ? "quantum" : "standard")}
                  className="justify-start text-xs h-8"
                >
                  <i className={`${view === "standard" ? 'ri-3d-cube-sphere-line' : 'ri-chat-1-line'} mr-1.5`}></i>
                  {view === "standard" ? '3D View' : '2D View'}
                </Button>
                
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleStartVideoCall}
                  className="justify-start text-xs h-8"
                >
                  <i className="ri-video-chat-line mr-1.5"></i>
                  Video Call
                </Button>
                
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={toggleTimeCapsules}
                  className={`justify-start text-xs h-8 ${timeCapsulesEnabled ? 'text-[#FF00E5]' : ''}`}
                >
                  <i className="ri-time-line mr-1.5"></i>
                  Time Capsule
                </Button>
                
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={toggleHiveBrain}
                  className={`justify-start text-xs h-8 ${hiveMindEnabled ? 'text-[#FF00E5]' : ''}`}
                >
                  <i className="ri-brain-line mr-1.5"></i>
                  Hive Brain
                </Button>
                
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => toggleMultiverseMode(multiverseMode === 'standard' ? 'fork' : 'standard')}
                  className={`justify-start text-xs h-8 ${multiverseMode !== 'standard' ? 'text-[#7B61FF]' : ''}`}
                >
                  <i className="ri-git-branch-line mr-1.5"></i>
                  {multiverseMode === 'standard' ? 'Fork Chat' : 'Main Timeline'}
                </Button>
                
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={toggleOfflineMode}
                  className={`justify-start text-xs h-8 ${offlineMode ? 'text-[#FF6900]' : ''}`}
                >
                  <i className={`ri-wifi-${offlineMode ? 'off-' : ''}line mr-1.5`}></i>
                  {offlineMode ? 'Go Online' : 'Offline Mode'}
                </Button>
                
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={toggleGeoFencing}
                  className={`justify-start text-xs h-8 ${geoFencing ? 'text-[#00F0FF]' : ''}`}
                >
                  <i className="ri-map-pin-line mr-1.5"></i>
                  {geoFencing ? 'Global Chat' : 'Geo-Fence'}
                </Button>
                
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={toggleEmergencyMode}
                  className={`justify-start text-xs h-8 ${emergencyMode ? 'text-red-500' : ''}`}
                >
                  <i className="ri-alarm-warning-line mr-1.5"></i>
                  {emergencyMode ? 'End SOS' : 'Emergency SOS'}
                </Button>
              </div>
            </PopoverContent>
          </Popover>
        </div>
      </div>
      
      {/* Advanced Settings Notification */}
      {(isQuantumEnabled || isP2PEnabled || hiveMindEnabled || timeCapsulesEnabled || multiverseMode !== 'standard') && (
        <div className="px-3 py-1.5 border-b border-white/5 bg-black/20 flex items-center justify-between">
          <div className="flex items-center space-x-1 text-xs">
            <i className="ri-information-line text-[#00F0FF]"></i>
            <span>
              {isQuantumEnabled && 'Quantum encryption active. '}
              {isP2PEnabled && 'P2P relay enabled. '}
              {hiveMindEnabled && 'Collective intelligence active. '}
              {timeCapsulesEnabled && 'Time capsule messaging available. '}
              {multiverseMode !== 'standard' && `Multiverse mode: ${multiverseMode}. `}
            </span>
          </div>
          {isQuantumEnabled && encryptionLevel !== 'standard' && (
            <Select
              value={encryptionLevel}
              onValueChange={(value) => toggleEncryptionLevel()}
            >
              <SelectTrigger className="h-6 w-auto text-xs bg-[rgba(255,0,229,0.1)] border-[#FF00E5]/20">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-[#0a0a0a] border-white/10">
                <SelectItem value="standard">Standard Encryption</SelectItem>
                <SelectItem value="quantum">Quantum Encryption</SelectItem>
                <SelectItem value="post-quantum">Post-Quantum</SelectItem>
              </SelectContent>
            </Select>
          )}
        </div>
      )}
      
      {/* Hive Mind Suggestions */}
      {hiveMindEnabled && activeHiveBrainSuggestions.length > 0 && (
        <div className="px-3 py-2 border-b border-white/5 bg-[rgba(123,97,255,0.05)]">
          <div className="flex items-center space-x-2 mb-1.5">
            <Badge className="bg-[rgba(123,97,255,0.2)] text-[#7B61FF] text-xs">
              <i className="ri-brain-line mr-1"></i>
              Hive Brain
            </Badge>
            <span className="text-xs text-text-secondary">Collective intelligence suggestions</span>
          </div>
          <div className="space-y-1.5">
            {activeHiveBrainSuggestions.map((suggestion, index) => (
              <div 
                key={index} 
                className="text-sm p-2 rounded bg-[rgba(123,97,255,0.1)] border border-[#7B61FF]/20"
              >
                {suggestion}
              </div>
            ))}
          </div>
        </div>
      )}
      
      {/* Emergency Mode Banner */}
      {emergencyMode && (
        <div className="px-3 py-2 border-b border-red-500/20 bg-red-500/10 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Badge className="bg-red-500/20 text-red-400 text-xs animate-pulse">
              <i className="ri-alarm-warning-line mr-1"></i>
              EMERGENCY MODE
            </Badge>
            {locationData && (
              <span className="text-xs text-text-secondary">
                Location: {locationData.lat.toFixed(4)}, {locationData.lng.toFixed(4)}
              </span>
            )}
          </div>
          <Button
            variant="destructive"
            size="sm"
            className="h-7 text-xs"
            onClick={toggleEmergencyMode}
          >
            End Emergency
          </Button>
        </div>
      )}
      
      {/* Chat Content Based on View Type */}
      {view === "standard" ? (
        <div className="flex-1 p-4 space-y-4 overflow-y-auto">
          {isLoadingMessages ? (
            Array(3).fill(0).map((_, i) => (
              <Skeleton key={i} className="h-16 w-3/4" />
            ))
          ) : messages?.length > 0 ? (
            messages.map((message: Message) => (
              <MessageBubble
                key={message.id}
                message={message}
                isOwn={message.senderId === 1}
                isAI={message.senderId === 2}
                isEncrypted={message.isEncrypted}
                disappearAt={message.disappearAt}
              />
            ))
          ) : (
            <div className="flex flex-col items-center justify-center h-full text-text-secondary">
              <i className="ri-chat-3-line text-4xl mb-2"></i>
              <p>No messages yet. Start the conversation!</p>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      ) : view === "orbital" ? (
        <div className="flex-1 relative">
          <OrbitalChat messages={messages || []} />
        </div>
      ) : (
        <div className="flex-1 relative">
          <QuantumParticles messages={messages || []} />
        </div>
      )}
      
      {/* Time Capsule Message Scheduling Panel */}
      {timeCapsulesEnabled && (
        <div className="p-3 border-t border-b border-white/5 glassmorphism">
          <div className="flex items-center">
            <div className="flex-1 mr-2">
              <input
                type="text"
                placeholder="Type a time capsule message..."
                value={scheduledMessage}
                onChange={(e) => setScheduledMessage(e.target.value)}
                className="w-full h-8 text-sm px-2 py-1 rounded-md bg-white/5 border border-white/10 focus:outline-none focus:ring-1 focus:ring-[#FF00E5]/50"
              />
            </div>
            <input
              type="datetime-local"
              value={deliveryDate ? deliveryDate.toISOString().slice(0, 16) : ''}
              onChange={(e) => setDeliveryDate(e.target.valueAsDate)}
              className="h-8 text-sm px-2 py-1 mr-2 rounded-md bg-white/5 border border-white/10 focus:outline-none focus:ring-1 focus:ring-[#FF00E5]/50"
            />
            <Button
              size="sm"
              className="h-8 bg-[rgba(255,0,229,0.2)] text-[#FF00E5] hover:bg-[rgba(255,0,229,0.3)]"
              onClick={handleScheduleMessage}
              disabled={!scheduledMessage.trim() || !deliveryDate}
            >
              <i className="ri-time-line mr-1"></i>
              Schedule
            </Button>
          </div>
        </div>
      )}
      
      {/* Message Input */}
      <div className={`p-3 border-t border-white/5 glassmorphism ${offlineMode ? 'bg-opacity-10 opacity-80' : ''}`}>
        <MessageInput 
          onSendMessage={handleSendMessage} 
          isEncrypted={isQuantumEnabled}
          isPending={sendMessageMutation.isPending}
          isP2PEnabled={isP2PEnabled}
        />
      </div>
      
      {/* Video Call Component */}
      <VideoCall 
        isActive={isVideoCallActive}
        onClose={handleEndVideoCall}
        peerId="user-456"
        peerName="Alice"
      />
    </div>
  );
}

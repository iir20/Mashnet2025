import { useState, useEffect, useRef } from "react";
import { format } from "date-fns";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Tooltip, 
  TooltipContent, 
  TooltipProvider, 
  TooltipTrigger 
} from "@/components/ui/tooltip";
import { 
  Popover, 
  PopoverContent, 
  PopoverTrigger
} from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface MessageProps {
  message: {
    id: number;
    content: string;
    createdAt: Date;
    metadata?: {
      isP2P?: boolean;
      p2pProtocol?: string;
      routingNodes?: string[];
      hops?: number;
      encryptionLevel?: 'standard' | 'quantum' | 'post-quantum';
      multiverseFork?: string | null;
      hiveMindEnhanced?: boolean;
      offlineDelivery?: boolean;
      geofenced?: boolean;
      language?: string;
      whisperMode?: boolean;
      ipfsCid?: string | null;
    };
  };
  isOwn: boolean;
  isAI: boolean;
  isEncrypted: boolean;
  disappearAt: Date | null;
}

export default function MessageBubble({ message, isOwn, isAI, isEncrypted, disappearAt }: MessageProps) {
  const [timeLeft, setTimeLeft] = useState<number | null>(null);
  const [isVisible, setIsVisible] = useState(true);
  const [isHovered, setIsHovered] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const [isUnlocked, setIsUnlocked] = useState(false);
  
  // For encrypted message glitch effect
  const encryptedTextRef = useRef<HTMLSpanElement>(null);
  const glitchIntervalRef = useRef<NodeJS.Timeout | null>(null);
  
  // Calculate time left for disappearing messages
  useEffect(() => {
    if (disappearAt) {
      const calculateTimeLeft = () => {
        const now = new Date();
        const difference = new Date(disappearAt).getTime() - now.getTime();
        
        if (difference <= 0) {
          setIsVisible(false);
          return null;
        }
        
        return Math.round(difference / 1000);
      };
      
      setTimeLeft(calculateTimeLeft());
      
      const timer = setInterval(() => {
        const remaining = calculateTimeLeft();
        setTimeLeft(remaining);
        
        if (remaining === null) {
          clearInterval(timer);
        }
      }, 1000);
      
      return () => clearInterval(timer);
    }
    
    return undefined;
  }, [disappearAt]);
  
  // Create glitch effect for encrypted messages
  useEffect(() => {
    if (isEncrypted && !isUnlocked && encryptedTextRef.current) {
      const generateGlitchText = () => {
        if (!encryptedTextRef.current) return;
        
        const length = message.content.length;
        const chars = "■□●○*&#%@!?¥€£$¢∞§¶•ªº⌐¬÷×±–—≠≈≤≥";
        let glitchText = "";
        
        for (let i = 0; i < length; i++) {
          glitchText += chars[Math.floor(Math.random() * chars.length)];
        }
        
        encryptedTextRef.current.textContent = glitchText;
      };
      
      // Initial glitch effect
      generateGlitchText();
      
      // Periodic glitch effect
      glitchIntervalRef.current = setInterval(generateGlitchText, 500);
      
      return () => {
        if (glitchIntervalRef.current) {
          clearInterval(glitchIntervalRef.current);
        }
      };
    }
  }, [isEncrypted, isUnlocked, message.content]);
  
  // Disappeared message display
  if (!isVisible) {
    return (
      <motion.div 
        initial={{ opacity: 0, height: "auto" }}
        animate={{ opacity: 1, height: "auto" }}
        exit={{ opacity: 0, height: 0 }}
        className="flex items-center justify-center py-2 text-xs text-text-secondary italic"
      >
        <i className="ri-ghost-line mr-1"></i> This quantum-encrypted message has vanished
      </motion.div>
    );
  }
  
  // Format time for display
  const formatTimeLeft = (seconds: number): string => {
    if (seconds < 60) return `${seconds}s`;
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes}m ${seconds % 60}s`;
    const hours = Math.floor(minutes / 60);
    return `${hours}h ${minutes % 60}m`;
  };
  
  // Get message style based on sender type
  const getMessageStyle = () => {
    if (isOwn) {
      return 'bg-[rgba(0,240,255,0.1)] border border-[rgba(0,240,255,0.2)] rounded-tr-none';
    } else if (isAI) {
      return 'bg-[rgba(123,97,255,0.1)] border border-[rgba(123,97,255,0.2)] rounded-tl-none';
    } else if (message.metadata?.hiveMindEnhanced) {
      return 'bg-[rgba(255,0,229,0.1)] border border-[rgba(255,0,229,0.2)] rounded-tl-none';
    } else {
      return 'bg-[rgba(22,27,34,0.8)] border border-white/5 rounded-tl-none';
    }
  };
  
  // Get encryption color based on level
  const getEncryptionColor = () => {
    const encLevel = message.metadata?.encryptionLevel || 'standard';
    if (encLevel === 'post-quantum') return 'text-[#FF00E5]';
    if (encLevel === 'quantum') return 'text-[#FF00E5]';
    return 'text-yellow-400';
  };
  
  // Toggle locked/unlocked state
  const toggleUnlock = () => {
    setIsUnlocked(!isUnlocked);
    
    // Clean up glitch effect if unlocking
    if (!isUnlocked && glitchIntervalRef.current) {
      clearInterval(glitchIntervalRef.current);
    }
  };
  
  return (
    <motion.div
      className={`flex items-start space-x-2 my-3 ${isOwn ? 'justify-end' : ''}`}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2 }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {!isOwn && (
        <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
          isAI 
            ? 'bg-[rgba(123,97,255,0.2)]' 
            : 'bg-[#161B22] border border-white/10'
        }`}>
          <i className={isAI ? 'ri-robot-line text-[#7B61FF]' : 'ri-user-3-line'}></i>
        </div>
      )}
      
      <div 
        className={`p-3 rounded-xl ${getMessageStyle()} relative text-sm max-w-[85%] space-y-1`}
      >
        {/* Message content */}
        <div>
          {isEncrypted && !isUnlocked ? (
            <div className={`font-mono ${getEncryptionColor()} blur-[0.5px]`}>
              <span ref={encryptedTextRef} className={message.metadata?.encryptionLevel === 'post-quantum' ? 'text-glitch' : ''}>
                {/* Content populated by useEffect */}
              </span>
            </div>
          ) : (
            <div>
              {message.content.startsWith('ipfs://') ? (
                <div className="flex items-center">
                  <i className="ri-hard-drive-line mr-1 text-[#00F0FF]"></i>
                  <span>Decentralized content: {message.content.substring(7, 15)}...</span>
                </div>
              ) : (
                message.content
              )}
            </div>
          )}
        </div>
        
        {/* Feature badges */}
        {(message.metadata?.isP2P || message.metadata?.ipfsCid || message.metadata?.multiverseFork || message.metadata?.offlineDelivery) && (
          <div className="flex flex-wrap gap-1 mt-2">
            {message.metadata?.isP2P && (
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Badge variant="outline" className="text-[#7B61FF] border-[#7B61FF]/30 text-xs py-0">
                      <i className="ri-share-fill mr-1 text-[10px]"></i>
                      P2P
                      {message.metadata?.hops && message.metadata.hops > 0 ? 
                        <span className="ml-1 text-[10px]">({message.metadata.hops})</span> : 
                        ''}
                    </Badge>
                  </TooltipTrigger>
                  <TooltipContent side="bottom" className="bg-black/80 border-[#7B61FF]/20">
                    <p className="text-xs">MashNet P2P protocol</p>
                    {message.metadata.routingNodes && (
                      <p className="text-[10px] font-mono mt-1">Via: {message.metadata.routingNodes.join(' → ')}</p>
                    )}
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            )}
            
            {message.metadata?.ipfsCid && (
              <Badge variant="outline" className="text-[#00F0FF] border-[#00F0FF]/30 text-xs py-0">
                <i className="ri-hard-drive-line mr-1 text-[10px]"></i>
                IPFS
              </Badge>
            )}
            
            {message.metadata?.multiverseFork && (
              <Badge variant="outline" className="text-[#7B61FF] border-[#7B61FF]/30 text-xs py-0">
                <i className="ri-git-branch-line mr-1 text-[10px]"></i>
                Fork
              </Badge>
            )}
            
            {message.metadata?.offlineDelivery && (
              <Badge variant="outline" className="text-orange-400 border-orange-400/30 text-xs py-0">
                <i className="ri-wifi-off-line mr-1 text-[10px]"></i>
                Offline
              </Badge>
            )}
          </div>
        )}
        
        {/* Message footer */}
        <div className="flex items-center justify-between text-xs text-text-secondary">
          <div className="flex items-center gap-2">
            <span>
              {format(new Date(message.createdAt), 'h:mm a')}
            </span>
          </div>
          
          {isEncrypted && timeLeft !== null && (
            <span className="flex items-center text-[#FF00E5]">
              <i className="ri-time-line mr-1"></i> {formatTimeLeft(timeLeft)}
            </span>
          )}
        </div>
        
        {/* Hover actions */}
        <AnimatePresence>
          {isHovered && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="absolute -top-4 right-2 flex gap-1"
            >
              {isEncrypted && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={toggleUnlock}
                  className="h-8 w-8 p-0 rounded-full bg-black/60 hover:bg-black/80"
                >
                  <i className={`ri-${isUnlocked ? 'lock' : 'key'}-line text-xs text-[#FF00E5]`}></i>
                </Button>
              )}
              
              <Popover open={showDetails} onOpenChange={setShowDetails}>
                <PopoverTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-8 w-8 p-0 rounded-full bg-black/60 hover:bg-black/80"
                  >
                    <i className="ri-information-line text-xs"></i>
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-72 p-3 bg-[#0a0a0a] border-white/10">
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium flex items-center">
                      <i className="ri-information-line mr-2 text-[#00F0FF]"></i>
                      Message Details
                    </h3>
                    
                    <div className="grid grid-cols-2 gap-1 text-xs">
                      <span className="text-text-secondary">Message ID:</span>
                      <span className="font-mono">{message.id}</span>
                      
                      <span className="text-text-secondary">Sent:</span>
                      <span>{format(new Date(message.createdAt), 'PPp')}</span>
                      
                      <span className="text-text-secondary">Sender:</span>
                      <span>{isOwn ? 'You' : (isAI ? 'AI Assistant' : 'Other User')}</span>
                      
                      {isEncrypted && (
                        <>
                          <span className="text-text-secondary">Encryption:</span>
                          <span className={getEncryptionColor()}>
                            {message.metadata?.encryptionLevel || 'Standard'}
                          </span>
                          
                          <span className="text-text-secondary">Disappears in:</span>
                          <span className="text-[#FF00E5]">
                            {timeLeft ? formatTimeLeft(timeLeft) : 'Never'}
                          </span>
                        </>
                      )}
                      
                      {message.metadata?.isP2P && (
                        <>
                          <span className="text-text-secondary">P2P Protocol:</span>
                          <span className="text-[#7B61FF]">
                            {message.metadata.p2pProtocol || 'MashNet'}
                          </span>
                          
                          <span className="text-text-secondary">Network Hops:</span>
                          <span>{message.metadata.hops || '0'}</span>
                        </>
                      )}
                      
                      {message.metadata?.ipfsCid && (
                        <>
                          <span className="text-text-secondary">IPFS CID:</span>
                          <span className="font-mono text-[#00F0FF] truncate">
                            {message.metadata.ipfsCid.substring(0, 15)}...
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                </PopoverContent>
              </Popover>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
      
      {isOwn && (
        <div className="w-8 h-8 rounded-full bg-[rgba(0,240,255,0.1)] border border-[rgba(0,240,255,0.3)] flex items-center justify-center flex-shrink-0">
          <i className="ri-user-3-line text-[#00F0FF]"></i>
        </div>
      )}
    </motion.div>
  );
}

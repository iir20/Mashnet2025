import { useWeb3 } from "@/hooks/use-web3";

interface TopBarProps {
  title: string;
}

export default function TopBar({ title }: TopBarProps) {
  const { connect, isConnected } = useWeb3();
  
  return (
    <header className="glassmorphism h-16 flex items-center justify-between px-4 border-b border-white/5 z-10">
      <div className="flex items-center">
        <h2 className="text-lg font-display font-medium ml-2">{title}</h2>
      </div>
      
      {/* Right side actions */}
      <div className="flex items-center space-x-4">
        {/* Connected Badge */}
        {isConnected && (
          <div className="hidden md:flex items-center px-3 py-1 rounded-full bg-[rgba(0,255,157,0.1)] border border-[rgba(0,255,157,0.3)]">
            <span className="w-2 h-2 rounded-full bg-[#00FF9D] animate-pulse mr-2"></span>
            <span className="text-xs font-medium text-[#00FF9D]">Decentralized</span>
          </div>
        )}
        
        {/* Notifications */}
        <button className="relative p-1 rounded-full hover:bg-white/5">
          <i className="ri-notification-3-line text-xl"></i>
          <span className="absolute top-0 right-0 w-2 h-2 rounded-full bg-[#FF00E5]"></span>
        </button>
        
        {/* Settings */}
        <button className="p-1 rounded-full hover:bg-white/5">
          <i className="ri-settings-3-line text-xl"></i>
        </button>
        
        {/* Connect Wallet */}
        {!isConnected ? (
          <button 
            onClick={connect}
            className="hidden md:flex items-center px-3 py-1.5 rounded-lg bg-[rgba(0,240,255,0.1)] text-[#00F0FF] border border-[rgba(0,240,255,0.3)] neon-border"
          >
            <i className="ri-wallet-3-line mr-2"></i>
            <span className="text-sm font-medium">Connect Wallet</span>
          </button>
        ) : (
          <button className="hidden md:flex items-center px-3 py-1.5 rounded-lg bg-[rgba(0,240,255,0.1)] text-[#00F0FF] border border-[rgba(0,240,255,0.3)] neon-border">
            <i className="ri-wallet-3-line mr-2"></i>
            <span className="text-sm font-medium truncate max-w-[100px]">0x742d...f44e</span>
          </button>
        )}
      </div>
    </header>
  );
}

import { useState } from "react";
import { Link, useLocation } from "wouter";

type NavItem = {
  label: string;
  href: string;
  icon: string;
};

type NavSection = {
  title: string;
  items: NavItem[];
};

const navSections: NavSection[] = [
  {
    title: "Workspace",
    items: [
      { label: "Dashboard", href: "/", icon: "ri-dashboard-line" },
      { label: "Chat", href: "/chat/1", icon: "ri-chat-3-line" },
      { label: "Contacts", href: "/contacts", icon: "ri-user-line" },
      { label: "Visualizations", href: "/visualizations", icon: "ri-bar-chart-grouped-line" }
    ]
  },
  {
    title: "Web3 Features",
    items: [
      { label: "Connect Wallet", href: "/wallet", icon: "ri-wallet-3-line" },
      { label: "NFT Gallery", href: "/nft", icon: "ri-nft-line" },
      { label: "Multiverse Rooms", href: "/multiverse", icon: "ri-space-ship-line" },
      { label: "Token Rewards", href: "/tokens", icon: "ri-coins-line" }
    ]
  }
];

export default function Sidebar() {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };
  
  return (
    <aside className="glassmorphism w-full lg:w-64 lg:flex-shrink-0 border-b lg:border-b-0 lg:border-r border-white/5 z-20">
      <div className="flex lg:flex-col h-16 lg:h-full">
        {/* Logo */}
        <div className="flex items-center justify-between px-4 py-3 lg:py-6 border-b border-white/5 w-full">
          <div className="flex items-center">
            <div className="flex items-center justify-center w-8 h-8 rounded-full bg-[rgba(0,240,255,0.1)] neon-border mr-3">
              <i className="ri-bubble-chart-fill text-[#00F0FF]"></i>
            </div>
            <h1 className="font-display font-bold text-xl tracking-tight">
              <span className="glow-text">Nexus</span>
              <span className="text-[#FF00E5] glow-text-magenta">Viz</span>
            </h1>
          </div>
          {/* Mobile menu toggle */}
          <button 
            onClick={toggleMobileMenu} 
            className="lg:hidden text-white"
          >
            <i className={`${isMobileMenuOpen ? 'ri-close-line' : 'ri-menu-line'} text-xl`}></i>
          </button>
        </div>
        
        {/* Navigation Links - Hidden on mobile unless toggled */}
        <nav className={`${isMobileMenuOpen ? 'flex' : 'hidden'} lg:flex flex-col w-full overflow-y-auto`}>
          <div className="px-3 py-4 space-y-4">
            {navSections.map((section, index) => (
              <div key={index}>
                <h3 className="text-xs font-semibold text-text-secondary uppercase tracking-wider px-3 mb-2">
                  {section.title}
                </h3>
                <div className="space-y-1">
                  {section.items.map((item, itemIndex) => (
                    <Link key={itemIndex} href={item.href}>
                      <div className={`flex items-center px-3 py-2 text-sm font-medium rounded-lg cursor-pointer ${location === item.href ? 'bg-[rgba(0,240,255,0.1)] text-[#00F0FF]' : 'hover:bg-white/5'}`}>
                        <i className={`${item.icon} mr-3`}></i>
                        {item.label}
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </nav>
        
        {/* User Profile - Mobile */}
        <div className="lg:hidden flex items-center ml-auto px-4">
          <div className="flex items-center">
            <div className="w-8 h-8 rounded-full bg-[rgba(123,97,255,0.2)] neon-border-purple flex items-center justify-center">
              <i className="ri-user-3-line text-[#7B61FF]"></i>
            </div>
          </div>
        </div>
      </div>
      
      {/* User Profile - Desktop */}
      <div className="hidden lg:flex items-center px-4 py-3 mt-auto border-t border-white/5">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded-full bg-[rgba(123,97,255,0.2)] neon-border-purple flex items-center justify-center">
            <i className="ri-user-3-line text-[#7B61FF]"></i>
          </div>
          <div>
            <p className="text-sm font-medium">Anon User</p>
            <p className="text-xs text-text-secondary">2 NFT Badges</p>
          </div>
        </div>
      </div>
    </aside>
  );
}

import { useState, useEffect } from 'react';
import { useIPFS } from '@/hooks/use-ipfs';
import { useToast } from '@/hooks/use-toast';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';

interface IPFSFile {
  cid: string;
  name: string;
  size: number;
  type: string;
  lastModified: number;
}

export default function IPFSExplorer() {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedTab, setSelectedTab] = useState<'upload' | 'browse'>('browse');
  const [uploadText, setUploadText] = useState('');
  const [uploadName, setUploadName] = useState('');
  const [recentCids, setRecentCids] = useState<string[]>([]);
  const [retrievedContent, setRetrievedContent] = useState<string | null>(null);
  const [isRetrieving, setIsRetrieving] = useState(false);
  const [retrievedContentName, setRetrievedContentName] = useState('');
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [files, setFiles] = useState<IPFSFile[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  const { isConnected, isConnecting, nodeId, peerCount, connect, disconnect, addContent, getContent } = useIPFS();
  const { toast } = useToast();

  // Load mock files on component mount
  useEffect(() => {
    if (isOpen && isConnected) {
      setIsLoading(true);
      
      // Simulate loading delay
      setTimeout(() => {
        const mockFiles: IPFSFile[] = [
          {
            cid: 'QmX7vgzWxY4KfugfRKQjYr3G56mMQdYfL5vhJ8EE4Yg3YS',
            name: 'quantum-message-backup.json',
            size: 1345,
            type: 'application/json',
            lastModified: Date.now() - 3600000 * 2 // 2 hours ago
          },
          {
            cid: 'QmYbHwVA9d4qMMk7M8FGr9vGfJL3mCKnvpbBeGT6hdwxQu',
            name: 'chat-encryption-keys.bin',
            size: 2048,
            type: 'application/octet-stream',
            lastModified: Date.now() - 86400000 // 1 day ago
          },
          {
            cid: 'QmZ3u4zUYFChxNc1aQzwgJ6bxDTfvJ8jJANpGAy5gzk2Y3',
            name: 'distributed-profile.jpg',
            size: 124500,
            type: 'image/jpeg',
            lastModified: Date.now() - 3600000 * 5 // 5 hours ago
          },
          {
            cid: 'QmS9dX2RrQNc9hYzvCRNxGE1m66kqJjBwUX6MiKK5TfBTm',
            name: 'web3-credentials.dat',
            size: 890,
            type: 'application/octet-stream',
            lastModified: Date.now() - 3600000 * 12 // 12 hours ago
          },
          {
            cid: 'QmUYrWGbxDXUNYgtXXFsCG2MZJqWVVgj1mfEWkd9YzLsBF',
            name: 'distributed-network-nodes.csv',
            size: 3501,
            type: 'text/csv',
            lastModified: Date.now() - 86400000 * 3 // 3 days ago
          }
        ];
        
        setFiles(mockFiles);
        setIsLoading(false);
      }, 1500);
    }
  }, [isOpen, isConnected]);

  // Handle connect/disconnect to IPFS
  const handleToggleConnection = async () => {
    if (isConnected) {
      disconnect();
    } else {
      const success = await connect();
      if (success) {
        setIsOpen(true);
      }
    }
  };

  // Handle file upload to IPFS
  const handleUpload = async () => {
    if (!uploadText.trim()) {
      toast({
        title: 'No Content',
        description: 'Please enter some content to upload',
        variant: 'destructive'
      });
      return;
    }
    
    if (!uploadName.trim()) {
      toast({
        title: 'No Filename',
        description: 'Please enter a name for your file',
        variant: 'destructive'
      });
      return;
    }
    
    const cid = await addContent(uploadText);
    if (cid) {
      // Add to recent CIDs
      setRecentCids(prev => [cid, ...prev.slice(0, 4)]);
      
      // Add to files list
      const newFile: IPFSFile = {
        cid,
        name: uploadName,
        size: uploadText.length,
        type: 'text/plain',
        lastModified: Date.now()
      };
      
      setFiles(prev => [newFile, ...prev]);
      
      // Reset form
      setUploadText('');
      setUploadName('');
      
      // Switch to browse tab
      setSelectedTab('browse');
    }
  };

  // Handle file retrieval from IPFS
  const handleRetrieve = async (cid: string, name: string) => {
    setIsRetrieving(true);
    setRetrievedContent(null);
    
    try {
      const content = await getContent(cid);
      if (content) {
        setRetrievedContent(content);
        setRetrievedContentName(name);
        setIsDetailOpen(true);
      }
    } catch (error) {
      toast({
        title: 'Retrieval Failed',
        description: 'Failed to retrieve content from IPFS',
        variant: 'destructive'
      });
    } finally {
      setIsRetrieving(false);
    }
  };

  // Format file size for display
  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  // Format time for display
  const formatTime = (timestamp: number): string => {
    const diff = Date.now() - timestamp;
    if (diff < 60000) return 'just now';
    if (diff < 3600000) return Math.floor(diff / 60000) + ' minutes ago';
    if (diff < 86400000) return Math.floor(diff / 3600000) + ' hours ago';
    return Math.floor(diff / 86400000) + ' days ago';
  };

  // Determine file icon based on type
  const getFileIcon = (type: string): string => {
    if (type.includes('image')) return 'ri-image-line';
    if (type.includes('json')) return 'ri-code-line';
    if (type.includes('text') || type.includes('csv')) return 'ri-file-text-line';
    if (type.includes('application')) return 'ri-file-code-line';
    return 'ri-file-line';
  };

  return (
    <>
      <Card className="glassmorphism border-white/5">
        <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
          <CardTitle className="text-sm font-medium flex items-center">
            <i className="ri-hard-drive-2-line mr-2 text-[#00F0FF]"></i>
            Decentralized Storage
          </CardTitle>
          <Button 
            variant="ghost" 
            size="sm" 
            className={`px-2 py-1 h-7 text-xs ${isConnected ? 'bg-[rgba(0,240,255,0.1)] text-[#00F0FF]' : 'hover:bg-white/5'}`}
            onClick={handleToggleConnection}
            disabled={isConnecting}
          >
            {isConnecting ? (
              <>
                <i className="ri-loader-4-line animate-spin mr-1"></i>
                Connecting...
              </>
            ) : isConnected ? (
              <>
                <i className="ri-link-line mr-1"></i>
                Connected
              </>
            ) : (
              <>
                <i className="ri-link-unlink-line mr-1"></i>
                Connect IPFS
              </>
            )}
          </Button>
        </CardHeader>
        <CardContent className="pb-2">
          {isConnected ? (
            <div className="glassmorphism bg-opacity-30 rounded-md p-2 text-xs space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-text-secondary">Node ID:</span>
                <span className="font-mono truncate max-w-[120px]">{nodeId ? nodeId.substring(0, 12) + '...' : 'Not connected'}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-text-secondary">Peers:</span>
                <Badge variant="outline" className="border-[#00F0FF]/30 text-[#00F0FF] px-1 h-5">
                  <i className="ri-group-line mr-1 text-xs"></i>
                  {peerCount}
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-text-secondary">Network:</span>
                <span className="text-green-400">Active</span>
              </div>
            </div>
          ) : (
            <div className="text-xs text-text-secondary py-2">
              Connect to the IPFS network to access decentralized storage
            </div>
          )}
        </CardContent>
        <CardFooter className="pt-0">
          <Button 
            variant="ghost" 
            size="sm" 
            className="w-full border border-white/5 hover:bg-white/5"
            onClick={() => setIsOpen(true)}
            disabled={!isConnected}
          >
            <i className="ri-folder-open-line mr-1"></i>
            Open IPFS Explorer
          </Button>
        </CardFooter>
      </Card>

      {/* IPFS Explorer Dialog */}
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="sm:max-w-[600px] p-0 overflow-hidden bg-[#0a0a0a] border-white/10">
          <DialogHeader className="px-6 pt-6 pb-2">
            <DialogTitle className="flex items-center">
              <i className="ri-hard-drive-2-line mr-2 text-[#00F0FF]"></i>
              IPFS Decentralized Storage
            </DialogTitle>
          </DialogHeader>
          
          {/* Tabs */}
          <div className="flex border-b border-white/10">
            <button
              className={`flex-1 py-2 text-sm font-medium ${selectedTab === 'browse' ? 'text-[#00F0FF] border-b-2 border-[#00F0FF]' : 'text-text-secondary hover:text-white'}`}
              onClick={() => setSelectedTab('browse')}
            >
              <i className="ri-folder-open-line mr-1"></i>
              Browse Files
            </button>
            <button
              className={`flex-1 py-2 text-sm font-medium ${selectedTab === 'upload' ? 'text-[#00F0FF] border-b-2 border-[#00F0FF]' : 'text-text-secondary hover:text-white'}`}
              onClick={() => setSelectedTab('upload')}
            >
              <i className="ri-upload-cloud-line mr-1"></i>
              Upload to IPFS
            </button>
          </div>
          
          <div className="p-6">
            {/* Browse Tab */}
            {selectedTab === 'browse' && (
              <div className="space-y-4">
                {/* Network Info */}
                <div className="flex items-center justify-between mb-4 bg-black/20 p-3 rounded-md">
                  <div className="flex items-center space-x-4">
                    <div className="flex flex-col">
                      <span className="text-xs text-text-secondary">Node ID</span>
                      <span className="text-sm font-mono truncate max-w-[180px]">
                        {nodeId ? nodeId.substring(0, 14) + '...' : 'Not connected'}
                      </span>
                    </div>
                    <div className="flex flex-col">
                      <span className="text-xs text-text-secondary">Connected Peers</span>
                      <span className="text-sm">{peerCount} peers</span>
                    </div>
                  </div>
                  <Badge 
                    variant="outline" 
                    className="border-green-500/30 text-green-400"
                  >
                    <i className="ri-wifi-line mr-1"></i>
                    Connected
                  </Badge>
                </div>
                
                {/* Files List */}
                <div className="space-y-2 max-h-[300px] overflow-y-auto pr-2">
                  <div className="flex items-center justify-between text-xs text-text-secondary mb-2 px-2">
                    <span className="w-[40%]">Name</span>
                    <span className="w-[25%]">CID</span>
                    <span className="w-[15%]">Size</span>
                    <span className="w-[20%]">Added</span>
                    <span className="w-[5%]"></span>
                  </div>
                  
                  {isLoading ? (
                    // Loading skeletons
                    Array(5).fill(0).map((_, i) => (
                      <div key={i} className="flex items-center py-2 px-2 rounded-md">
                        <Skeleton className="h-4 w-[40%] rounded mr-2" />
                        <Skeleton className="h-4 w-[25%] rounded mx-2" />
                        <Skeleton className="h-4 w-[15%] rounded mx-2" />
                        <Skeleton className="h-4 w-[15%] rounded ml-2" />
                      </div>
                    ))
                  ) : files.length > 0 ? (
                    // Files list
                    files.map((file) => (
                      <motion.div
                        key={file.cid}
                        initial={{ opacity: 0, y: 5 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.2 }}
                        className="flex items-center py-2 px-2 rounded-md hover:bg-white/5 cursor-pointer"
                        onClick={() => handleRetrieve(file.cid, file.name)}
                      >
                        <div className="w-[40%] flex items-center">
                          <i className={`${getFileIcon(file.type)} text-[#00F0FF] mr-2`}></i>
                          <span className="truncate text-sm">{file.name}</span>
                        </div>
                        <div className="w-[25%] font-mono text-xs text-text-secondary truncate">
                          {file.cid.substring(0, 10)}...
                        </div>
                        <div className="w-[15%] text-xs text-text-secondary">
                          {formatFileSize(file.size)}
                        </div>
                        <div className="w-[20%] text-xs text-text-secondary">
                          {formatTime(file.lastModified)}
                        </div>
                        <div className="w-[5%] flex justify-end">
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-6 w-6"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleRetrieve(file.cid, file.name);
                            }}
                          >
                            <i className="ri-download-line text-xs"></i>
                          </Button>
                        </div>
                      </motion.div>
                    ))
                  ) : (
                    // Empty state
                    <div className="flex flex-col items-center justify-center py-10 text-text-secondary">
                      <i className="ri-folder-open-line text-3xl mb-2"></i>
                      <p>No files found in your IPFS node</p>
                      <Button 
                        variant="link" 
                        size="sm" 
                        className="mt-2"
                        onClick={() => setSelectedTab('upload')}
                      >
                        Upload a file
                      </Button>
                    </div>
                  )}
                </div>
                
                {/* Recent CIDs */}
                {recentCids.length > 0 && (
                  <div className="mt-4">
                    <h4 className="text-xs text-text-secondary mb-2">Recent CIDs:</h4>
                    <div className="flex flex-wrap gap-2">
                      {recentCids.map((cid) => (
                        <Badge 
                          key={cid}
                          variant="outline" 
                          className="font-mono border-[#00F0FF]/20 text-[#00F0FF]"
                        >
                          {cid.substring(0, 12)}...
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
            
            {/* Upload Tab */}
            {selectedTab === 'upload' && (
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">File Name</label>
                  <Input
                    placeholder="Enter file name"
                    value={uploadName}
                    onChange={(e) => setUploadName(e.target.value)}
                    className="bg-white/5 border-white/10"
                  />
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Content</label>
                  <textarea
                    placeholder="Enter content to store on IPFS"
                    value={uploadText}
                    onChange={(e) => setUploadText(e.target.value)}
                    className="w-full h-32 rounded-md bg-white/5 border border-white/10 p-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#00F0FF]/50 focus:border-transparent resize-none"
                  />
                </div>
                
                <Button 
                  className="w-full bg-[rgba(0,240,255,0.2)] text-[#00F0FF] hover:bg-[rgba(0,240,255,0.3)]"
                  onClick={handleUpload}
                >
                  <i className="ri-upload-cloud-line mr-2"></i>
                  Upload to IPFS Network
                </Button>
                
                <p className="text-xs text-text-secondary text-center">
                  Content will be stored across distributed nodes in the IPFS network
                </p>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
      
      {/* File Detail Dialog */}
      <Dialog open={isDetailOpen} onOpenChange={setIsDetailOpen}>
        <DialogContent className="sm:max-w-[500px] p-0 overflow-hidden bg-[#0a0a0a] border-white/10">
          <DialogHeader className="px-6 pt-6 pb-2">
            <DialogTitle className="flex items-center">
              <i className="ri-file-text-line mr-2 text-[#00F0FF]"></i>
              {retrievedContentName || 'File Content'}
            </DialogTitle>
          </DialogHeader>
          
          <div className="p-6">
            {isRetrieving ? (
              <div className="flex flex-col items-center justify-center py-10">
                <div className="w-10 h-10 rounded-full border-2 border-[#00F0FF] border-t-transparent animate-spin mb-4"></div>
                <p className="text-text-secondary">Retrieving from IPFS network...</p>
              </div>
            ) : retrievedContent ? (
              <div className="bg-black/20 p-4 rounded-md font-mono text-sm overflow-auto max-h-[300px] whitespace-pre-wrap">
                {retrievedContent}
              </div>
            ) : (
              <p className="text-text-secondary text-center py-6">No content to display</p>
            )}
          </div>
          
          <DialogFooter className="px-6 pb-6">
            <Button 
              variant="outline"
              onClick={() => setIsDetailOpen(false)}
            >
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
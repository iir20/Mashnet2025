import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent } from "@/components/ui/card";

interface NFTBadge {
  id: number;
  name: string;
  image: string;
}

export default function NFTBadges() {
  const { data: badges, isLoading } = useQuery({
    queryKey: ['/api/web3/nft/1']
  });
  
  return (
    <Card className="glassmorphism border-white/5 overflow-hidden hover:neon-border-magenta transition-all duration-300">
      <CardContent className="p-4">
        <div className="flex items-center justify-between cursor-pointer">
          <div className="flex items-center">
            <div className="w-10 h-10 rounded-lg bg-[rgba(255,0,229,0.1)] flex items-center justify-center mr-3">
              <i className="ri-nft-line text-xl text-[#FF00E5]"></i>
            </div>
            <div>
              <h4 className="text-sm font-medium">NFT Badges</h4>
              <p className="text-xs text-text-secondary">Earn badges for contributions</p>
            </div>
          </div>
          
          {isLoading ? (
            <Skeleton className="w-12 h-6 rounded-full" />
          ) : (
            <div className="flex -space-x-2">
              {badges && badges.length > 0 ? (
                badges.map((badge: NFTBadge) => (
                  <div 
                    key={badge.id}
                    className="w-6 h-6 rounded-full flex items-center justify-center text-xs"
                    style={{
                      backgroundColor: badge.id === 1 ? 'rgba(0,240,255,0.2)' : 'rgba(255,0,229,0.2)',
                      borderColor: badge.id === 1 ? 'rgba(0,240,255,0.3)' : 'rgba(255,0,229,0.3)',
                      borderWidth: '1px'
                    }}
                  >
                    <i className={badge.id === 1 ? 'ri-verified-badge-line text-[#00F0FF]' : 'ri-medal-line text-[#FF00E5]'}></i>
                  </div>
                ))
              ) : (
                <div className="text-xs px-2 py-0.5 rounded-full bg-[rgba(255,214,0,0.1)] text-[#FFD600]">
                  No badges
                </div>
              )}
            </div>
          )}
        </div>
        
        {/* Badge details - conditionally shown */}
        {badges && badges.length > 0 && (
          <div className="mt-4 pt-4 border-t border-white/5 grid grid-cols-2 gap-3">
            {badges.map((badge: NFTBadge) => (
              <div 
                key={badge.id}
                className="glassmorphism p-3 rounded-lg border border-white/10 hover:border-[rgba(255,0,229,0.3)]"
              >
                <div className="flex items-center space-x-2">
                  <div 
                    className="w-8 h-8 rounded-full flex items-center justify-center"
                    style={{
                      backgroundColor: badge.id === 1 ? 'rgba(0,240,255,0.2)' : 'rgba(255,0,229,0.2)'
                    }}
                  >
                    <i className={badge.id === 1 ? 'ri-verified-badge-line text-[#00F0FF]' : 'ri-medal-line text-[#FF00E5]'}></i>
                  </div>
                  <div>
                    <p className="text-xs font-medium">{badge.name}</p>
                    <p className="text-xs text-text-secondary">NFT #{badge.id}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

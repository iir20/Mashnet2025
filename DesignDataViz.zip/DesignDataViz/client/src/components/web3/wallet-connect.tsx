import { useState } from "react";
import { useWeb3 } from "@/hooks/use-web3";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function WalletConnect() {
  const { connect, disconnect, isConnected, address, balance, network } = useWeb3();
  const [isConnecting, setIsConnecting] = useState(false);
  
  const handleConnect = async () => {
    setIsConnecting(true);
    try {
      await connect();
    } catch (error) {
      console.error("Failed to connect wallet:", error);
    } finally {
      setIsConnecting(false);
    }
  };
  
  return (
    <Card className="glassmorphism border-white/5 overflow-hidden hover:neon-border transition-all duration-300">
      <CardContent className="p-4">
        {!isConnected ? (
          <div 
            onClick={handleConnect}
            className="flex items-center justify-between cursor-pointer"
          >
            <div className="flex items-center">
              <div className="w-10 h-10 rounded-lg bg-[rgba(0,240,255,0.1)] flex items-center justify-center mr-3">
                <i className="ri-wallet-3-line text-xl text-[#00F0FF]"></i>
              </div>
              <div>
                <h4 className="text-sm font-medium">Connect Metamask</h4>
                <p className="text-xs text-text-secondary">Enable Web3 features</p>
              </div>
            </div>
            {isConnecting ? (
              <i className="ri-loader-4-line animate-spin text-text-secondary"></i>
            ) : (
              <i className="ri-arrow-right-line text-text-secondary"></i>
            )}
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="w-10 h-10 rounded-lg bg-[rgba(0,240,255,0.1)] flex items-center justify-center mr-3">
                  <i className="ri-wallet-3-line text-xl text-[#00F0FF]"></i>
                </div>
                <div>
                  <h4 className="text-sm font-medium">Wallet Connected</h4>
                  <p className="text-xs text-text-secondary">{network}</p>
                </div>
              </div>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={disconnect}
                className="text-xs border border-white/10 hover:bg-white/5"
              >
                Disconnect
              </Button>
            </div>
            
            <div className="glassmorphism p-3 rounded-lg">
              <div className="flex justify-between items-center mb-1">
                <span className="text-xs text-text-secondary">Address:</span>
                <span className="text-xs font-mono">{address}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-xs text-text-secondary">Balance:</span>
                <span className="text-xs font-medium">{balance}</span>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

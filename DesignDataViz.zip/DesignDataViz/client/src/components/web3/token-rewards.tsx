import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

export default function TokenRewards() {
  const [currentTokens, setCurrentTokens] = useState(250);
  const { toast } = useToast();
  
  const claimTokensMutation = useMutation({
    mutationFn: async () => {
      return apiRequest('POST', '/api/web3/tokens/1/reward', {
        amount: 50
      });
    },
    onSuccess: (data) => {
      const responseData = data.json();
      setCurrentTokens(responseData.tokenBalance);
      toast({
        title: "Tokens Claimed",
        description: "You have earned 50 NexusTokens for your contribution!",
        variant: "success"
      });
      queryClient.invalidateQueries({
        queryKey: ['/api/users/1']
      });
    }
  });
  
  const handleClaimTokens = () => {
    claimTokensMutation.mutate();
  };
  
  return (
    <Card className="glassmorphism border-white/5 overflow-hidden hover:neon-border-cyan transition-all duration-300">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className="w-10 h-10 rounded-lg bg-[rgba(0,240,255,0.1)] flex items-center justify-center mr-3">
              <i className="ri-coins-line text-xl text-[#00F0FF]"></i>
            </div>
            <div>
              <h4 className="text-sm font-medium">Token Rewards</h4>
              <p className="text-xs text-text-secondary">Earn by contributing</p>
            </div>
          </div>
          <div className="text-sm font-medium">
            {claimTokensMutation.isPending ? (
              <div className="flex items-center">
                <i className="ri-loader-4-line animate-spin mr-1"></i>
                Loading...
              </div>
            ) : (
              <span>
                {currentTokens} <span className="text-text-secondary">NXV</span>
              </span>
            )}
          </div>
        </div>
        
        {/* Token details */}
        <div className="mt-4 space-y-4">
          <div className="glassmorphism p-3 rounded-lg border border-white/10">
            <div className="flex justify-between items-center mb-2">
              <span className="text-xs text-text-secondary">Available to claim:</span>
              <span className="text-xs font-medium text-[#00FF9D]">50 NXV</span>
            </div>
            
            <div className="w-full bg-white/5 rounded-full h-1.5 mb-3">
              <div className="bg-[#00F0FF] h-1.5 rounded-full" style={{ width: '20%' }}></div>
            </div>
            
            <div className="flex items-center justify-between text-xs text-text-secondary">
              <span>Weekly progress</span>
              <span>20%</span>
            </div>
          </div>
          
          <Button 
            onClick={handleClaimTokens}
            disabled={claimTokensMutation.isPending}
            className="w-full bg-[rgba(0,240,255,0.1)] hover:bg-[rgba(0,240,255,0.2)] text-[#00F0FF] border border-[rgba(0,240,255,0.3)]"
          >
            {claimTokensMutation.isPending ? (
              <i className="ri-loader-4-line animate-spin mr-2"></i>
            ) : (
              <i className="ri-coin-line mr-2"></i>
            )}
            Claim 50 NXV Tokens
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

import { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';

interface Message {
  id: number;
  senderId: number;
  content: string;
  isEncrypted: boolean;
}

interface OrbitalChatProps {
  messages: Message[];
}

// Fallback component for the orbital visualization
const OrbitalFallback = ({ messages }: OrbitalChatProps) => {
  return (
    <div className="w-full h-full relative bg-space-dark rounded-xl p-6 overflow-hidden">
      <div className="orbital-center"></div>
      
      <div className="orbital orbital-1">
        <div className="orbital-particle orbital-particle-1"></div>
      </div>
      
      <div className="orbital orbital-2">
        <div className="orbital-particle orbital-particle-2"></div>
      </div>
      
      <div className="absolute inset-0 flex flex-col items-center justify-center text-text-primary z-10">
        <h3 className="text-xl font-bold mb-3 glow-text">Quantum Message Visualization</h3>
        <p className="text-text-secondary text-center max-w-md">
          {messages.length} messages in the quantum orbital network
        </p>
        <div className="mt-6 grid grid-cols-3 gap-3">
          {messages.slice(0, 6).map((message) => {
            const isAI = message.senderId === 2;
            const isUser = message.senderId === 1;
            const color = isAI ? "bg-neon-purple" : isUser ? "bg-neon-cyan" : "bg-neon-magenta";
            const glowClass = isAI ? "glow-text-purple" : isUser ? "glow-text" : "glow-text-magenta";
            
            return (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className={`p-3 rounded-lg glassmorphism ${color === "bg-neon-cyan" ? "border-neon-cyan" : color === "bg-neon-purple" ? "border-neon-purple" : "border-neon-magenta"} border-opacity-30 border`}
              >
                <div className={`text-sm ${glowClass}`}>
                  {message.isEncrypted 
                    ? "🔒 Encrypted" 
                    : message.content.substring(0, 20) + (message.content.length > 20 ? "..." : "")}
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default function OrbitalChat({ messages }: OrbitalChatProps) {
  const [isFallback, setIsFallback] = useState(true);
  
  // Use CSS animations instead of Three.js for better compatibility
  return (
    <div className="w-full h-full">
      <OrbitalFallback messages={messages} />
    </div>
  );
}

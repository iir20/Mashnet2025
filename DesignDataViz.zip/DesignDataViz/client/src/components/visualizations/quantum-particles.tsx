import { useState, useRef, useEffect } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls, Text, Billboard } from '@react-three/drei';
import * as THREE from 'three';
import { motion } from 'framer-motion-3d';
import { EffectComposer, Bloom, Noise } from '@react-three/postprocessing';

interface Message {
  id: number;
  content: string;
  isAI?: boolean;
  isEncrypted?: boolean;
  senderId: number;
}

interface QuantumParticlesProps {
  messages: Message[];
  isActive?: boolean;
}

// Simplified version for now
export default function QuantumParticles({ messages, isActive = true }: QuantumParticlesProps) {
  // For performance, limit the number of messages rendered
  const displayMessages = isActive ? messages.slice(-15) : messages.slice(-5);
  
  return (
    <div className="w-full h-full bg-black rounded-xl overflow-hidden relative">
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="text-center">
          <h3 className="text-xl font-bold mb-3 text-[#00F0FF] glow-text">Quantum Network Visualization</h3>
          <p className="text-text-secondary text-center max-w-md mb-6">
            {displayMessages.length} messages in the quantum network
          </p>
          <div className="flex items-center justify-center gap-1 text-xs text-text-secondary mb-4">
            <span>Processing nodes:</span>
            <div className="flex space-x-1">
              <div className="h-2 w-2 rounded-full bg-[#00F0FF]/40 animate-pulse"></div>
              <div className="h-2 w-2 rounded-full bg-[#FF00E5]/40 animate-pulse delay-100"></div>
              <div className="h-2 w-2 rounded-full bg-[#7B61FF]/40 animate-pulse delay-200"></div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Center point */}
      <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2">
        <div className="w-8 h-8 rounded-full bg-[#FF00E5]/30 animate-ping"></div>
        <div className="w-4 h-4 rounded-full bg-[#FF00E5] absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2"></div>
      </div>
      
      {/* Message particles */}
      <div className="absolute inset-0">
        {displayMessages.map((message, index) => {
          // Generate a deterministic position based on message ID
          const angle = (message.id * 137.5) % 360; // Golden angle for nice distribution
          const distance = 100 + (index * 10);
          const delay = index * 0.2;
          const duration = 15 + (index % 5);
          
          const color = message.isAI ? '#9C1AFF' : 
                       (message.isEncrypted ? '#00F0FF' : '#FF00E5');
          
          // Calculate position
          const left = `calc(50% + ${Math.cos(angle * Math.PI / 180) * distance}px)`;
          const top = `calc(50% + ${Math.sin(angle * Math.PI / 180) * distance}px)`;
          
          return (
            <div 
              key={message.id}
              className="absolute w-3 h-3 transform -translate-x-1/2 -translate-y-1/2"
              style={{
                left,
                top,
                backgroundColor: color,
                borderRadius: '50%',
                boxShadow: `0 0 ${8 + (index % 5)}px ${color}`,
                animation: `orbitAnimation${index % 5} ${duration}s linear infinite`
              }}
            ></div>
          );
        })}
      </div>
      
      {/* Message preview on hover */}
      <div className="grid grid-cols-3 gap-2 absolute bottom-4 left-0 right-0 px-4">
        {displayMessages.slice(-6).map((message) => {
          const isAI = message.isAI;
          const isEncrypted = message.isEncrypted;
          
          const color = isAI ? "bg-[rgba(123,97,255,0.1)] border-[#7B61FF]/30" : 
                      isEncrypted ? "bg-[rgba(0,240,255,0.1)] border-[#00F0FF]/30" : 
                      "bg-[rgba(255,0,229,0.1)] border-[#FF00E5]/30";
          
          return (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className={`p-2 rounded-lg glassmorphism border ${color} text-xs`}
            >
              <div>
                {isEncrypted 
                  ? <span className="text-xs font-mono blur-[0.5px]">■■■■■■■■■</span>
                  : message.content.substring(0, 20) + (message.content.length > 20 ? "..." : "")}
              </div>
            </motion.div>
          );
        })}
      </div>
      
      {/* Orbit animations are defined in CSS */}
    </div>
  );
}
import { useState, useRef, useEffect } from 'react';
import { useAIAssistant } from '@/hooks/use-ai-assistant';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { motion, AnimatePresence } from 'framer-motion';

interface Message {
  id: string;
  content: string;
  isAI: boolean;
  timestamp: Date;
}

export default function AIAssistant() {
  const [input, setInput] = useState('');
  const [isExpanded, setIsExpanded] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const { 
    messages, 
    isTyping, 
    sendMessage, 
    clearConversation,
    aiCapabilities,
    aiPersonality,
    setAIPersonality,
    summarizeConversation,
    isProcessingImage,
    processImage,
    detectSentiment,
    translateMessage,
    lastSentiment
  } = useAIAssistant({
    enableShadowClone: true
  });
  
  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim()) {
      sendMessage(input);
      setInput('');
    }
  };
  
  const personalityTypes = [
    { id: 'helpful', name: 'Helpful', icon: 'ri-service-line', color: 'bg-blue-400/10 text-blue-400' },
    { id: 'creative', name: 'Creative', icon: 'ri-palette-line', color: 'bg-purple-400/10 text-purple-400' },
    { id: 'analytical', name: 'Analytical', icon: 'ri-line-chart-line', color: 'bg-green-400/10 text-green-400' },
    { id: 'friendly', name: 'Friendly', icon: 'ri-emotion-happy-line', color: 'bg-amber-400/10 text-amber-400' },
    { id: 'concise', name: 'Concise', icon: 'ri-scissors-cut-line', color: 'bg-red-400/10 text-red-400' },
    { id: 'quantum', name: 'Quantum', icon: 'ri-atom-line', color: 'bg-[rgba(0,240,255,0.1)] text-[#00F0FF]' }
  ];
  
  return (
    <Card className={`overflow-hidden transition-all duration-300 ease-in-out glassmorphism border-white/5 ${isExpanded ? 'fixed inset-4 z-50' : ''}`}>
      <CardHeader className="p-4 flex flex-row items-center justify-between border-b border-white/5 bg-[rgba(0,0,0,0.2)]">
        <div className="flex items-center">
          <div className="relative">
            <Avatar className="h-10 w-10 border border-white/10">
              <AvatarImage src="/ai-assistant-avatar.png" />
              <AvatarFallback className="bg-[rgba(0,240,255,0.1)] text-[#00F0FF]">
                <i className="ri-robot-line"></i>
              </AvatarFallback>
            </Avatar>
            {isTyping && (
              <span className="absolute bottom-0 right-0 h-3 w-3 rounded-full bg-green-400 border border-background"></span>
            )}
          </div>
          <div className="ml-3">
            <h4 className="text-sm font-medium">Quantum AI Assistant</h4>
            <div className="flex items-center space-x-2">
              <p className="text-xs text-text-secondary">v3.0</p>
              <Badge variant="outline" className="text-xs px-1 py-0 h-4 text-[#00F0FF] border-[#00F0FF]/30">
                {aiPersonality || 'helpful'}
              </Badge>
            </div>
          </div>
        </div>
        <div className="flex space-x-1">
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-8 w-8 rounded-full hover:bg-white/5"
            onClick={() => setIsExpanded(!isExpanded)}
          >
            <i className={`ri-${isExpanded ? 'contract' : 'expand'}-line text-sm`}></i>
          </Button>
          <Button 
            variant="ghost" 
            size="icon"
            className="h-8 w-8 rounded-full hover:bg-white/5"
            onClick={clearConversation}
          >
            <i className="ri-delete-bin-line text-sm"></i>
          </Button>
        </div>
      </CardHeader>
      
      <CardContent className={`p-0 ${isExpanded ? 'max-h-[calc(100vh-150px)]' : 'max-h-[300px]'} overflow-y-auto`}>
        <div className="p-4 space-y-4">
          {messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-6 text-center">
              <div className="w-16 h-16 rounded-full bg-[rgba(0,240,255,0.1)] flex items-center justify-center mb-4">
                <i className="ri-robot-line text-2xl text-[#00F0FF]"></i>
              </div>
              <h3 className="text-sm font-medium mb-1">Quantum Neural Network Assistant</h3>
              <p className="text-xs text-text-secondary max-w-xs">
                Powered by advanced quantum algorithms to provide futuristic insights and assistance.
              </p>
              
              <div className="mt-6 grid grid-cols-3 gap-2 w-full max-w-md">
                {personalityTypes.map(personality => (
                  <Button
                    key={personality.id}
                    variant="ghost"
                    className={`flex flex-col items-center justify-center h-auto py-3 px-1 ${personality.color} rounded-lg border border-white/5`}
                    onClick={() => setAIPersonality(personality.id)}
                  >
                    <i className={`${personality.icon} text-lg mb-1`}></i>
                    <span className="text-xs">{personality.name}</span>
                  </Button>
                ))}
              </div>
            </div>
          ) : (
            messages.map((message: Message) => (
              <AnimatePresence key={message.id} mode="popLayout">
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                  className={`flex ${message.isAI ? 'justify-start' : 'justify-end'}`}
                >
                  <div className={`flex items-start max-w-[85%] ${message.isAI ? '' : 'flex-row-reverse'}`}>
                    {message.isAI && (
                      <Avatar className="h-8 w-8 mt-1 mr-2">
                        <AvatarFallback className="bg-[rgba(0,240,255,0.1)] text-[#00F0FF]">
                          <i className="ri-robot-line"></i>
                        </AvatarFallback>
                      </Avatar>
                    )}
                    
                    <div className={`rounded-lg px-3 py-2 ${
                      message.isAI 
                        ? 'bg-[rgba(0,240,255,0.1)] border border-[rgba(0,240,255,0.2)]' 
                        : 'bg-[rgba(255,255,255,0.1)] border border-white/10'
                    }`}>
                      <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                      <p className="text-[10px] text-text-secondary mt-1 text-right">
                        {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </div>
                    
                    {!message.isAI && (
                      <Avatar className="h-8 w-8 mt-1 ml-2">
                        <AvatarImage src="/user-avatar.png" />
                        <AvatarFallback className="bg-[rgba(255,0,229,0.1)] text-[#FF00E5]">
                          <i className="ri-user-line"></i>
                        </AvatarFallback>
                      </Avatar>
                    )}
                  </div>
                </motion.div>
              </AnimatePresence>
            ))
          )}
          
          {isTyping && (
            <div className="flex justify-start">
              <div className="flex items-start max-w-[85%]">
                <Avatar className="h-8 w-8 mt-1 mr-2">
                  <AvatarFallback className="bg-[rgba(0,240,255,0.1)] text-[#00F0FF]">
                    <i className="ri-robot-line"></i>
                  </AvatarFallback>
                </Avatar>
                
                <div className="rounded-lg px-3 py-2 bg-[rgba(0,240,255,0.1)] border border-[rgba(0,240,255,0.2)]">
                  <div className="flex space-x-1">
                    <div className="h-2 w-2 rounded-full bg-[#00F0FF]/40 animate-bounce" style={{ animationDelay: "0ms" }}></div>
                    <div className="h-2 w-2 rounded-full bg-[#00F0FF]/40 animate-bounce" style={{ animationDelay: "100ms" }}></div>
                    <div className="h-2 w-2 rounded-full bg-[#00F0FF]/40 animate-bounce" style={{ animationDelay: "200ms" }}></div>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>
      </CardContent>
      
      <CardFooter className="p-3 border-t border-white/5 bg-[rgba(0,0,0,0.2)]">
        <form onSubmit={handleSubmit} className="flex space-x-2 w-full">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask anything..."
            className="flex-1 bg-[rgba(255,255,255,0.05)] border-white/10"
          />
          
          <Button 
            type="button" 
            variant="ghost" 
            size="icon" 
            className="h-10 w-10 rounded-full hover:bg-[rgba(0,240,255,0.1)]"
            onClick={() => processImage('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+P+/HgAFfwI+QFyY5AAAAABJRU5ErkJggg==')}
          >
            <i className="ri-image-line text-[#00F0FF]"></i>
          </Button>
          
          <Button 
            type="submit" 
            size="icon" 
            className="h-10 w-10 rounded-full bg-[rgba(0,240,255,0.2)] text-[#00F0FF] hover:bg-[rgba(0,240,255,0.3)]"
          >
            <i className="ri-send-plane-line"></i>
          </Button>
        </form>
      </CardFooter>
      
      {messages.length > 0 && (
        <div className="absolute bottom-16 right-3 flex gap-1">
          <Button
            variant="ghost"
            size="sm"
            className="h-8 px-2 py-1 text-xs bg-black/20 hover:bg-black/40 rounded-full"
            onClick={() => summarizeConversation()}
          >
            <i className="ri-ai-generate text-xs mr-1"></i>
            Summarize
          </Button>
          
          <Button
            variant="ghost"
            size="sm"
            className="h-8 px-2 py-1 text-xs bg-black/20 hover:bg-black/40 rounded-full"
            onClick={() => translateMessage(messages[messages.length - 1].content, 'fr')}
          >
            <i className="ri-translate-2 text-xs mr-1"></i>
            Translate
          </Button>
          
          {lastSentiment && (
            <Badge 
              className={`rounded-full px-2 h-6 ${
                lastSentiment === 'positive' ? 'bg-green-500/20 text-green-400' :
                lastSentiment === 'negative' ? 'bg-red-500/20 text-red-400' :
                'bg-gray-500/20 text-gray-400'
              }`}
            >
              <i className={`${
                lastSentiment === 'positive' ? 'ri-emotion-happy-line' :
                lastSentiment === 'negative' ? 'ri-emotion-unhappy-line' :
                'ri-emotion-normal-line'
              } text-xs mr-1`}></i>
              {lastSentiment}
            </Badge>
          )}
        </div>
      )}
    </Card>
  );
}
import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Link } from "wouter";

interface ActionItem {
  icon: string;
  label: string;
  href: string;
  color: string;
}

const actions: ActionItem[] = [
  { 
    icon: "ri-chat-3-line", 
    label: "New Chat", 
    href: "/chat/1", 
    color: "#00F0FF" 
  },
  { 
    icon: "ri-robot-line", 
    label: "AI Assistant", 
    href: "/ai", 
    color: "#7B61FF" 
  },
  { 
    icon: "ri-space-ship-line", 
    label: "Multiverse", 
    href: "/multiverse", 
    color: "#FF00E5" 
  },
  { 
    icon: "ri-user-line", 
    label: "Profile", 
    href: "/profile", 
    color: "#FFD600" 
  }
];

export default function FloatingActionButton() {
  const [isOpen, setIsOpen] = useState(false);
  
  const toggleOpen = () => {
    setIsOpen(!isOpen);
  };
  
  return (
    <div className="fixed bottom-6 right-6 z-30">
      <AnimatePresence>
        {isOpen && (
          <div className="absolute bottom-16 right-0 space-y-2">
            {actions.map((action, index) => (
              <motion.div
                key={action.label}
                initial={{ opacity: 0, y: 20, scale: 0.8 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 20, scale: 0.8 }}
                transition={{ delay: index * 0.05 }}
                className="flex items-center justify-end space-x-2"
              >
                <div className="px-2 py-1 rounded-lg glassmorphism text-sm font-medium">
                  {action.label}
                </div>
                <Link href={action.href}>
                  <div 
                    className="w-10 h-10 rounded-full flex items-center justify-center shadow-lg cursor-pointer"
                    style={{
                      backgroundColor: action.color,
                      boxShadow: `0 0 10px ${action.color}80`
                    }}
                  >
                    <i className={`${action.icon} text-[#0D1117]`}></i>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        )}
      </AnimatePresence>
      
      <motion.button
        className="w-12 h-12 rounded-full bg-[#00F0FF] text-[#0D1117] flex items-center justify-center shadow-lg neon-border"
        onClick={toggleOpen}
        animate={{ rotate: isOpen ? 45 : 0 }}
        transition={{ duration: 0.2 }}
      >
        <i className={`${isOpen ? 'ri-close-line' : 'ri-add-line'} text-xl`}></i>
      </motion.button>
    </div>
  );
}

import { Card, CardContent } from "@/components/ui/card";

interface StatsCardProps {
  title: string;
  value: string | number;
  change?: string;
  icon: string;
  iconColor: string;
  iconBgColor: string;
  borderColor?: string;
}

export default function StatsCard({
  title,
  value,
  change,
  icon,
  iconColor,
  iconBgColor,
  borderColor = "neon-border"
}: StatsCardProps) {
  return (
    <Card className={`glassmorphism border-white/5 hover:${borderColor} transition-all duration-300`}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-text-secondary text-sm">{title}</p>
            <h3 className="text-2xl font-display font-bold mt-1">{value}</h3>
            {change && (
              <p className="text-[#00FF9D] text-xs mt-1 flex items-center">
                <i className="ri-arrow-up-line mr-1"></i> {change}
              </p>
            )}
          </div>
          <div 
            className="w-10 h-10 rounded-lg flex items-center justify-center"
            style={{ backgroundColor: iconBgColor }}
          >
            <i className={`${icon} text-xl`} style={{ color: iconColor }}></i>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

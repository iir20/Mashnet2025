import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "wouter";

interface WelcomeBannerProps {
  title: string;
  subtitle: string;
}

export default function WelcomeBanner({ title, subtitle }: WelcomeBannerProps) {
  return (
    <Card className="glassmorphism border-white/5 neon-border animate-glow relative overflow-hidden">
      <CardContent className="p-6 md:p-8">
        <div className="absolute top-0 right-0 opacity-20 pointer-events-none">
          {/* Background pattern - replaced with pure CSS */}
          <div className="w-48 h-48 rounded-full bg-gradient-to-br from-[rgba(123,97,255,0.2)] to-[rgba(0,240,255,0.1)]"></div>
        </div>
        
        <div className="relative z-10 max-w-3xl">
          <h1 className="text-2xl md:text-3xl font-display font-bold mb-3">
            {title} <span className="glow-text">NexusViz</span>
          </h1>
          <p className="text-text-secondary mb-6 md:pr-12">{subtitle}</p>
          
          <div className="flex flex-wrap gap-3">
            <Link href="/chat/1">
              <Button className="flex items-center px-4 py-2 rounded-lg bg-[#00F0FF] text-[#0D1117] font-medium">
                <i className="ri-chat-3-line mr-2"></i>
                New Chat
              </Button>
            </Link>
            
            <Link href="/multiverse">
              <Button variant="outline" className="flex items-center px-4 py-2 rounded-lg border border-[rgba(123,97,255,0.5)] text-[#7B61FF] neon-border-purple">
                <i className="ri-space-ship-line mr-2"></i>
                Multiverse
              </Button>
            </Link>
            
            <Button variant="ghost" className="flex items-center px-4 py-2 rounded-lg border border-white/10 hover:bg-white/5">
              <i className="ri-play-circle-line mr-2"></i>
              Take Tour
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

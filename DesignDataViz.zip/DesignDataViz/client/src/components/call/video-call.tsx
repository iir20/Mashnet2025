import { useState, useEffect, useRef } from 'react';
import { useWebRTC } from '@/hooks/use-webrtc';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { motion, AnimatePresence } from 'framer-motion';

interface VideoCallProps {
  isActive: boolean;
  onClose: () => void;
  peerId?: string;
  peerName?: string;
}

export default function VideoCall({ isActive, onClose, peerId = 'user-123', peerName = 'Remote User' }: VideoCallProps) {
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [filterIndex, setFilterIndex] = useState(0);
  const [volume, setVolume] = useState(75);
  const [connection, setConnection] = useState<{quality: number, latency: number, encryption: string}>({
    quality: 0,
    latency: 0,
    encryption: 'initializing'
  });
  
  const {
    localStream,
    remoteStreams,
    callStatus,
    isMuted,
    isVideoOff,
    isP2P,
    toggleMute,
    toggleVideo,
    toggleP2PMode,
    endCall,
  } = useWebRTC();
  
  const videoFilters = [
    { name: 'None', css: '' },
    { name: 'Quantum', css: 'hue-rotate(180deg) saturate(1.5)' },
    { name: 'Cyberpunk', css: 'sepia(0.5) hue-rotate(310deg) saturate(1.8)' },
    { name: 'Blueprint', css: 'sepia(1) brightness(0.8) hue-rotate(180deg) saturate(5) contrast(0.8)' },
    { name: 'Neon', css: 'brightness(1.1) contrast(1.1) saturate(1.5) hue-rotate(340deg)' },
    { name: 'Matrix', css: 'hue-rotate(90deg) saturate(1.6) brightness(0.8) contrast(1.2)' },
  ];
  
  // Simulate connection quality updates
  useEffect(() => {
    if (!isActive) return;
    
    const connectionInterval = setInterval(() => {
      // Random fluctuations to simulate real network conditions
      setConnection(prev => ({
        quality: Math.min(100, Math.max(40, prev.quality + (Math.random() * 6) - 3)),
        latency: Math.min(200, Math.max(20, prev.latency + (Math.random() * 10) - 5)),
        encryption: callStatus === 'connected' ? (isP2P ? 'E2E Quantum' : 'E2E Standard') : 'initializing'
      }));
    }, 2000);
    
    return () => clearInterval(connectionInterval);
  }, [isActive, callStatus, isP2P]);
  
  // Initialize the call
  useEffect(() => {
    if (isActive && peerId) {
      // Set up initial connection values
      setConnection({
        quality: 75,
        latency: 65,
        encryption: 'initializing'
      });
      
      // Simulate connecting to remote peer
      const timer = setTimeout(() => {
        if (localVideoRef.current) {
          // Create a mock video element for demonstration
          const canvas = document.createElement('canvas');
          canvas.width = 640;
          canvas.height = 480;
          const ctx = canvas.getContext('2d');
          
          if (ctx) {
            // Animation function to create a "live" effect for the mock video
            const drawVideoPlaceholder = () => {
              if (!ctx) return;
              
              // Clear canvas
              ctx.fillStyle = '#111';
              ctx.fillRect(0, 0, canvas.width, canvas.height);
              
              // Draw moving particles
              const time = Date.now() * 0.001;
              ctx.fillStyle = '#00F0FF';
              
              for (let i = 0; i < 50; i++) {
                const x = Math.sin(time + i * 0.3) * canvas.width / 2 + canvas.width / 2;
                const y = Math.cos(time + i * 0.2) * canvas.height / 2 + canvas.height / 2;
                const size = (Math.sin(time + i) + 1) * 4 + 1;
                
                ctx.beginPath();
                ctx.arc(x, y, size, 0, Math.PI * 2);
                ctx.fill();
              }
              
              // Draw connecting text
              ctx.fillStyle = 'white';
              ctx.font = '20px sans-serif';
              ctx.textAlign = 'center';
              ctx.fillText('Quantum Neural Stream', canvas.width / 2, canvas.height / 2 - 20);
              
              // Request next frame
              requestAnimationFrame(drawVideoPlaceholder);
            };
            
            // Start animation
            drawVideoPlaceholder();
            
            // Convert canvas to video stream
            // @ts-ignore - This is non-standard but works in modern browsers
            const stream = canvas.captureStream(30);
            if (localVideoRef.current) {
              localVideoRef.current.srcObject = stream;
            }
            
            if (remoteVideoRef.current) {
              // Create a different pattern for remote video
              const remoteCanvas = document.createElement('canvas');
              remoteCanvas.width = 640;
              remoteCanvas.height = 480;
              const remoteCtx = remoteCanvas.getContext('2d');
              
              if (remoteCtx) {
                const drawRemoteVideoPlaceholder = () => {
                  if (!remoteCtx) return;
                  
                  // Clear canvas
                  remoteCtx.fillStyle = '#111';
                  remoteCtx.fillRect(0, 0, remoteCanvas.width, remoteCanvas.height);
                  
                  // Draw moving shapes
                  const time = Date.now() * 0.001;
                  
                  for (let i = 0; i < 5; i++) {
                    const hue = (time * 20 + i * 60) % 360;
                    remoteCtx.fillStyle = `hsla(${hue}, 100%, 60%, 0.5)`;
                    
                    const x = Math.sin(time * 0.5 + i) * remoteCanvas.width / 3 + remoteCanvas.width / 2;
                    const y = Math.cos(time * 0.3 + i) * remoteCanvas.height / 3 + remoteCanvas.height / 2;
                    const size = 100 + Math.sin(time + i) * 50;
                    
                    remoteCtx.beginPath();
                    remoteCtx.arc(x, y, size, 0, Math.PI * 2);
                    remoteCtx.fill();
                  }
                  
                  // Overlay grid pattern
                  remoteCtx.strokeStyle = 'rgba(0, 240, 255, 0.3)';
                  remoteCtx.lineWidth = 1;
                  const gridSize = 40;
                  
                  for (let x = 0; x < remoteCanvas.width; x += gridSize) {
                    remoteCtx.beginPath();
                    remoteCtx.moveTo(x, 0);
                    remoteCtx.lineTo(x, remoteCanvas.height);
                    remoteCtx.stroke();
                  }
                  
                  for (let y = 0; y < remoteCanvas.height; y += gridSize) {
                    remoteCtx.beginPath();
                    remoteCtx.moveTo(0, y);
                    remoteCtx.lineTo(remoteCanvas.width, y);
                    remoteCtx.stroke();
                  }
                  
                  // Draw connecting text
                  remoteCtx.fillStyle = 'white';
                  remoteCtx.font = '20px sans-serif';
                  remoteCtx.textAlign = 'center';
                  remoteCtx.fillText(peerName, remoteCanvas.width / 2, remoteCanvas.height / 2 - 20);
                  
                  // Request next frame
                  requestAnimationFrame(drawRemoteVideoPlaceholder);
                };
                
                // Start animation
                drawRemoteVideoPlaceholder();
                
                // @ts-ignore - This is non-standard but works in modern browsers
                const remoteStream = remoteCanvas.captureStream(30);
                remoteVideoRef.current.srcObject = remoteStream;
              }
            }
          }
        }
      }, 1500);
      
      return () => clearTimeout(timer);
    }
  }, [isActive, peerId, peerName, isP2P]);
  
  // Toggle fullscreen mode
  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };
  
  // Cycle through video filters
  const cycleFilters = () => {
    setFilterIndex((filterIndex + 1) % videoFilters.length);
  };
  
  if (!isActive) return null;
  
  const currentFilter = videoFilters[filterIndex];
  
  return (
    <AnimatePresence>
      {isActive && (
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.9 }}
          transition={{ duration: 0.3 }}
          className={`fixed ${isFullscreen ? 'inset-0 z-50' : 'bottom-24 right-5 w-96 h-72 z-40'}`}
        >
          <Card className="w-full h-full overflow-hidden relative border-[#00F0FF]/30 shadow-[0_0_15px_rgba(0,240,255,0.3)] glassmorphism">
            <CardContent className="p-0 relative h-full">
              {/* Remote Video (Larger) */}
              <div className="absolute inset-0 bg-black">
                <video
                  ref={remoteVideoRef}
                  autoPlay
                  playsInline
                  className="w-full h-full object-cover"
                  style={{ filter: currentFilter.css }}
                />
              </div>
              
              {/* Local Video (Picture-in-Picture) */}
              <div className="absolute bottom-4 right-4 w-32 h-24 rounded-lg overflow-hidden border-2 border-[#00F0FF]/50 shadow-[0_0_10px_rgba(0,240,255,0.3)]">
                <video
                  ref={localVideoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full h-full object-cover"
                  style={{ filter: currentFilter.css }}
                />
              </div>
              
              {/* Call Controls */}
              <div className="absolute bottom-0 left-0 right-0 bg-black/60 backdrop-blur-sm p-3 flex items-center justify-between">
                <div className="flex space-x-2">
                  <Button
                    variant="ghost"
                    size="icon"
                    className={`rounded-full ${isMuted ? 'bg-red-500/20 text-red-400' : 'bg-white/10'}`}
                    onClick={toggleMute}
                  >
                    <i className={`ri-${isMuted ? 'mic-off' : 'mic'}-line`}></i>
                  </Button>
                  
                  <Button
                    variant="ghost"
                    size="icon"
                    className={`rounded-full ${isVideoOff ? 'bg-red-500/20 text-red-400' : 'bg-white/10'}`}
                    onClick={toggleVideo}
                  >
                    <i className={`ri-${isVideoOff ? 'camera-off' : 'camera'}-line`}></i>
                  </Button>
                  
                  <Button
                    variant="ghost"
                    size="icon"
                    className="rounded-full bg-white/10"
                    onClick={cycleFilters}
                  >
                    <i className="ri-image-edit-line"></i>
                  </Button>
                </div>
                
                <Button
                  variant="destructive"
                  size="sm"
                  className="rounded-full"
                  onClick={onClose}
                >
                  <i className="ri-phone-off-line mr-1"></i>
                  End
                </Button>
                
                <div className="flex space-x-2">
                  <Button
                    variant="ghost"
                    size="icon"
                    className={`rounded-full ${isP2P ? 'bg-[rgba(0,240,255,0.3)] text-[#00F0FF]' : 'bg-white/10'}`}
                    onClick={toggleP2PMode}
                  >
                    <i className="ri-share-line"></i>
                  </Button>
                  
                  <Button
                    variant="ghost"
                    size="icon"
                    className="rounded-full bg-white/10"
                    onClick={toggleFullscreen}
                  >
                    <i className={`ri-${isFullscreen ? 'fullscreen-exit' : 'fullscreen'}-line`}></i>
                  </Button>
                </div>
              </div>
              
              {/* Call Status Bar */}
              <div className="absolute top-0 left-0 right-0 bg-black/60 backdrop-blur-sm p-2 flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Badge variant="outline" className="bg-black/50 text-xs border-[#00F0FF]/30 text-[#00F0FF] px-2 py-0">
                    <i className="ri-user-line mr-1 text-xs"></i> {peerName}
                  </Badge>
                  
                  <Badge variant="outline" className="bg-black/50 text-xs border-[#00F0FF]/30 text-[#00F0FF] px-2 py-0">
                    <i className="ri-time-line mr-1 text-xs"></i>
                    <span className="call-timer">00:00</span>
                  </Badge>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Badge 
                    variant="outline" 
                    className={`bg-black/50 text-xs px-2 py-0 ${
                      connection.quality > 70 ? 'border-green-500/30 text-green-400' :
                      connection.quality > 40 ? 'border-yellow-500/30 text-yellow-400' :
                      'border-red-500/30 text-red-400'
                    }`}
                  >
                    <i className={`ri-wifi-${
                      connection.quality > 70 ? '4' :
                      connection.quality > 40 ? '2' : '1'
                    }-line mr-1 text-xs`}></i>
                    {Math.round(connection.quality)}%
                  </Badge>
                  
                  <Badge 
                    variant="outline" 
                    className="bg-black/50 text-xs border-purple-500/30 text-purple-400 px-2 py-0"
                  >
                    <i className="ri-lock-line mr-1 text-xs"></i>
                    {connection.encryption}
                  </Badge>
                </div>
              </div>
              
              {/* Filter Name Badge */}
              {currentFilter.name !== 'None' && (
                <Badge className="absolute top-12 right-4 bg-black/50 border-[#00F0FF]/30 text-xs">
                  <i className="ri-magic-line mr-1 text-xs"></i>
                  {currentFilter.name} Filter
                </Badge>
              )}
              
              {/* Volume Control */}
              {isFullscreen && (
                <div className="absolute left-4 bottom-20 flex items-center space-x-2 bg-black/60 backdrop-blur-sm rounded-full px-3 py-1">
                  <i className={`ri-volume-${volume === 0 ? 'mute' : volume < 50 ? 'down' : 'up'}-line text-xs text-white/70`}></i>
                  <Slider
                    value={[volume]}
                    max={100}
                    step={1}
                    className="w-24"
                    onValueChange={([val]) => setVolume(val)}
                  />
                  <span className="text-xs text-white/70">{volume}%</span>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
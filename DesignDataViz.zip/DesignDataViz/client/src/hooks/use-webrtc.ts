import { useState, useCallback, useEffect, useRef } from "react";
import { useToast } from "@/hooks/use-toast";

type MediaType = 'audio' | 'video' | 'screen' | 'both';
type CallStatus = 'idle' | 'requesting' | 'connecting' | 'connected' | 'disconnected' | 'failed';

interface Peer {
  id: string;
  name: string;
  audio: boolean;
  video: boolean;
  stream?: MediaStream;
}

export function useWebRTC() {
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [remoteStreams, setRemoteStreams] = useState<Map<string, MediaStream>>(new Map());
  const [callStatus, setCallStatus] = useState<CallStatus>('idle');
  const [activeMediaType, setActiveMediaType] = useState<MediaType | null>(null);
  const [peers, setPeers] = useState<Peer[]>([]);
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [callId, setCallId] = useState<string | null>(null);
  const [isP2P, setIsP2P] = useState(true);
  const [isMeshNetwork, setIsMeshNetwork] = useState(false);
  
  const { toast } = useToast();
  
  // WebRTC connection references
  const peerConnectionsRef = useRef<Map<string, RTCPeerConnection>>(new Map());
  const dataChannelsRef = useRef<Map<string, RTCDataChannel>>(new Map());
  
  // Clean up function to stop all media tracks
  const stopMediaTracks = useCallback(() => {
    if (localStream) {
      localStream.getTracks().forEach(track => {
        track.stop();
      });
      setLocalStream(null);
    }
  }, [localStream]);
  
  // Get user media (audio/video)
  const getMedia = useCallback(async (type: MediaType = 'both') => {
    try {
      stopMediaTracks();
      
      const constraints: MediaStreamConstraints = {
        audio: type === 'audio' || type === 'both',
        video: type === 'video' || type === 'both'
      };
      
      // For screen sharing
      if (type === 'screen') {
        // @ts-ignore - TypeScript doesn't recognize getDisplayMedia yet
        const screenStream = await navigator.mediaDevices.getDisplayMedia({
          video: true,
          audio: true
        });
        setLocalStream(screenStream);
        setActiveMediaType('screen');
        return screenStream;
      }
      
      // Mock delay for getting media permissions
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Since we're mocking, just create a fake media stream
      const mockTracks: MediaStreamTrack[] = [];
      
      // Create mock audio track
      if (constraints.audio) {
        const mockAudioTrack = {
          kind: 'audio',
          enabled: true,
          id: 'mock-audio-track-' + Date.now(),
          label: 'Mock Audio Track',
          muted: false,
          readyState: 'live',
          stop: () => {},
          applyConstraints: () => Promise.resolve(),
          getCapabilities: () => ({}),
          getConstraints: () => ({}),
          getSettings: () => ({}),
          clone: function() { return this; },
          addEventListener: () => {},
          removeEventListener: () => {},
          dispatchEvent: () => true
        } as unknown as MediaStreamTrack;
        
        mockTracks.push(mockAudioTrack);
      }
      
      // Create mock video track
      if (constraints.video) {
        const mockVideoTrack = {
          kind: 'video',
          enabled: true,
          id: 'mock-video-track-' + Date.now(),
          label: 'Mock Video Track',
          muted: false,
          readyState: 'live',
          stop: () => {},
          applyConstraints: () => Promise.resolve(),
          getCapabilities: () => ({}),
          getConstraints: () => ({}),
          getSettings: () => ({}),
          clone: function() { return this; },
          addEventListener: () => {},
          removeEventListener: () => {},
          dispatchEvent: () => true
        } as unknown as MediaStreamTrack;
        
        mockTracks.push(mockVideoTrack);
      }
      
      // Create a mock MediaStream
      const mockStream = {
        id: 'mock-stream-' + Date.now(),
        active: true,
        getTracks: () => mockTracks,
        getAudioTracks: () => mockTracks.filter(track => track.kind === 'audio'),
        getVideoTracks: () => mockTracks.filter(track => track.kind === 'video'),
        addTrack: (track: MediaStreamTrack) => mockTracks.push(track),
        removeTrack: (track: MediaStreamTrack) => {
          const index = mockTracks.indexOf(track);
          if (index !== -1) mockTracks.splice(index, 1);
        },
        clone: function() { return this; },
        addEventListener: () => {},
        removeEventListener: () => {},
        dispatchEvent: () => true
      } as unknown as MediaStream;
      
      setLocalStream(mockStream);
      setActiveMediaType(type === 'both' ? 'both' : type);
      return mockStream;
    } catch (error) {
      console.error('Error getting user media:', error);
      toast({
        title: 'Media Access Failed',
        description: 'Could not access camera or microphone.',
        variant: 'destructive'
      });
      return null;
    }
  }, [stopMediaTracks, toast]);
  
  // Toggle mute audio
  const toggleMute = useCallback(() => {
    if (localStream) {
      const audioTracks = localStream.getAudioTracks();
      audioTracks.forEach(track => {
        track.enabled = !track.enabled;
      });
      setIsMuted(!isMuted);
    }
  }, [localStream, isMuted]);
  
  // Toggle video on/off
  const toggleVideo = useCallback(() => {
    if (localStream) {
      const videoTracks = localStream.getVideoTracks();
      videoTracks.forEach(track => {
        track.enabled = !track.enabled;
      });
      setIsVideoOff(!isVideoOff);
    }
  }, [localStream, isVideoOff]);
  
  // Initiate a call
  const initiateCall = useCallback(async (peerId: string, type: MediaType = 'both') => {
    try {
      setCallStatus('requesting');
      
      // Get user media first
      const stream = await getMedia(type);
      if (!stream) {
        setCallStatus('failed');
        return null;
      }
      
      // Generate a random call ID
      const newCallId = Math.random().toString(36).substring(2, 15);
      setCallId(newCallId);
      
      // Mock delay for connection establishment
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Add mock peer
      const peer: Peer = {
        id: peerId,
        name: "Remote User",
        audio: true,
        video: type === 'video' || type === 'both'
      };
      
      setPeers([peer]);
      setCallStatus('connected');
      
      // Create a mock remote stream for the peer
      const mockRemoteStream = {
        id: 'remote-stream-' + Date.now(),
        active: true,
        getTracks: () => [],
        getAudioTracks: () => [],
        getVideoTracks: () => [],
        addTrack: () => {},
        removeTrack: () => {},
        clone: () => mockRemoteStream,
        addEventListener: () => {},
        removeEventListener: () => {},
        dispatchEvent: () => true
      } as unknown as MediaStream;
      
      setRemoteStreams(prev => {
        const newMap = new Map(prev);
        newMap.set(peerId, mockRemoteStream);
        return newMap;
      });
      
      toast({
        title: 'Call Connected',
        description: 'You are now in a call with the remote peer.',
        variant: 'default'
      });
      
      return newCallId;
    } catch (error) {
      console.error('Error initiating call:', error);
      setCallStatus('failed');
      toast({
        title: 'Call Failed',
        description: 'Could not establish the call connection.',
        variant: 'destructive'
      });
      return null;
    }
  }, [getMedia, toast]);
  
  // Answer an incoming call
  const answerCall = useCallback(async (incomingCallId: string, type: MediaType = 'both') => {
    try {
      setCallStatus('connecting');
      setCallId(incomingCallId);
      
      // Get user media first
      const stream = await getMedia(type);
      if (!stream) {
        setCallStatus('failed');
        return false;
      }
      
      // Mock delay for connection establishment
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Add mock peer (the caller)
      const peer: Peer = {
        id: 'caller-' + Math.random().toString(36).substring(2, 9),
        name: "Caller",
        audio: true,
        video: type === 'video' || type === 'both'
      };
      
      setPeers([peer]);
      setCallStatus('connected');
      
      // Create a mock remote stream for the caller
      const mockRemoteStream = {
        id: 'remote-stream-' + Date.now(),
        active: true,
        getTracks: () => [],
        getAudioTracks: () => [],
        getVideoTracks: () => [],
        addTrack: () => {},
        removeTrack: () => {},
        clone: () => mockRemoteStream,
        addEventListener: () => {},
        removeEventListener: () => {},
        dispatchEvent: () => true
      } as unknown as MediaStream;
      
      setRemoteStreams(prev => {
        const newMap = new Map(prev);
        newMap.set(peer.id, mockRemoteStream);
        return newMap;
      });
      
      toast({
        title: 'Call Connected',
        description: 'You answered the call and are now connected.',
        variant: 'default'
      });
      
      return true;
    } catch (error) {
      console.error('Error answering call:', error);
      setCallStatus('failed');
      toast({
        title: 'Call Failed',
        description: 'Could not answer the incoming call.',
        variant: 'destructive'
      });
      return false;
    }
  }, [getMedia, toast]);
  
  // End the current call
  const endCall = useCallback(() => {
    // Stop all media tracks
    stopMediaTracks();
    
    // Close all peer connections
    peerConnectionsRef.current.forEach((pc) => {
      pc.close();
    });
    peerConnectionsRef.current.clear();
    
    // Close all data channels
    dataChannelsRef.current.forEach((dc) => {
      dc.close();
    });
    dataChannelsRef.current.clear();
    
    // Reset state
    setCallStatus('disconnected');
    setRemoteStreams(new Map());
    setPeers([]);
    setCallId(null);
    
    toast({
      title: 'Call Ended',
      description: 'The call has been disconnected.',
      variant: 'default'
    });
  }, [stopMediaTracks, toast]);
  
  // Toggle between P2P and server-relay mode
  const toggleP2PMode = useCallback(() => {
    setIsP2P(prevMode => !prevMode);
    
    toast({
      title: isP2P ? 'Server Relay Mode' : 'P2P Mode',
      description: isP2P 
        ? 'Switched to server-relayed connections for better reliability.'
        : 'Switched to peer-to-peer connections for enhanced privacy.',
      variant: 'default'
    });
  }, [isP2P, toast]);
  
  // Toggle mesh network mode (for multi-user calls)
  const toggleMeshNetwork = useCallback(() => {
    setIsMeshNetwork(prevMode => !prevMode);
    
    toast({
      title: isMeshNetwork ? 'Star Topology' : 'Mesh Network',
      description: isMeshNetwork 
        ? 'Using star topology for better performance with many users.'
        : 'Using mesh network for direct connections between all peers.',
      variant: 'default'
    });
  }, [isMeshNetwork, toast]);
  
  // Clean up when component unmounts
  useEffect(() => {
    return () => {
      stopMediaTracks();
    };
  }, [stopMediaTracks]);
  
  return {
    localStream,
    remoteStreams,
    callStatus,
    callId,
    peers,
    isMuted,
    isVideoOff,
    isP2P,
    isMeshNetwork,
    getMedia,
    initiateCall,
    answerCall,
    endCall,
    toggleMute,
    toggleVideo,
    toggleP2PMode,
    toggleMeshNetwork
  };
}
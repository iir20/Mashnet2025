import { useState, useCallback, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";

export function useWeb3() {
  const [isConnected, setIsConnected] = useState(false);
  const [address, setAddress] = useState<string | null>(null);
  const [balance, setBalance] = useState<string | null>(null);
  const [network, setNetwork] = useState<string | null>(null);
  const [isConnecting, setIsConnecting] = useState(false);
  const { toast } = useToast();

  // Alias for connect to match property name in profile.tsx
  const connectWallet = useCallback(async () => {
    return connect();
  }, []);

  // Mock wallet connection
  const connect = useCallback(async () => {
    setIsConnecting(true);
    
    // Simulate connection process
    try {
      // Simulate delay for realistic experience
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Mocked successful connection
      setIsConnected(true);
      setAddress("0x742d35Cc6634C0532925a3b844Bc454e4438f44e");
      setBalance("0.42 ETH");
      setNetwork("Ethereum Mainnet");
      
      toast({
        title: "Wallet Connected",
        description: "Successfully connected to your wallet",
        variant: "default"
      });
      
      return true;
    } catch (error) {
      toast({
        title: "Connection Failed",
        description: "Failed to connect to your wallet",
        variant: "destructive"
      });
      return false;
    } finally {
      setIsConnecting(false);
    }
  }, [toast]);

  // Mock wallet disconnection
  const disconnect = useCallback(() => {
    setIsConnected(false);
    setAddress(null);
    setBalance(null);
    setNetwork(null);
    
    toast({
      title: "Wallet Disconnected",
      description: "Your wallet has been disconnected",
      variant: "default"
    });
  }, [toast]);

  // Mock send transaction
  const sendTransaction = useCallback(async (to: string, amount: string) => {
    if (!isConnected) {
      toast({
        title: "Not Connected",
        description: "Please connect your wallet first",
        variant: "destructive"
      });
      return false;
    }
    
    try {
      // Simulate transaction processing
      toast({
        title: "Processing Transaction",
        description: `Sending ${amount} ETH to ${to.substring(0, 6)}...${to.substring(to.length - 4)}`,
        variant: "default"
      });
      
      // Simulate network delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Mocked successful transaction
      const txHash = "0x" + Array.from({length: 64}, () => Math.floor(Math.random() * 16).toString(16)).join('');
      
      toast({
        title: "Transaction Successful",
        description: `Transaction hash: ${txHash.substring(0, 10)}...`,
        variant: "default"
      });
      
      // Update balance after transaction
      setBalance(`${(parseFloat(balance!.split(' ')[0]) - parseFloat(amount)).toFixed(2)} ETH`);
      
      return txHash;
    } catch (error) {
      toast({
        title: "Transaction Failed",
        description: "Failed to send transaction",
        variant: "destructive"
      });
      return false;
    }
  }, [isConnected, balance, toast]);

  // Mock sign message
  const signMessage = useCallback(async (message: string) => {
    if (!isConnected) {
      toast({
        title: "Not Connected",
        description: "Please connect your wallet first",
        variant: "destructive"
      });
      return false;
    }
    
    try {
      // Simulate signing process
      toast({
        title: "Signing Message",
        description: "Please confirm in your wallet",
        variant: "default"
      });
      
      // Simulate wallet confirmation delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Mocked signature
      const signature = "0x" + Array.from({length: 130}, () => Math.floor(Math.random() * 16).toString(16)).join('');
      
      toast({
        title: "Message Signed",
        description: `Signature: ${signature.substring(0, 10)}...`,
        variant: "default"
      });
      
      return signature;
    } catch (error) {
      toast({
        title: "Signing Failed",
        description: "Failed to sign message",
        variant: "destructive"
      });
      return false;
    }
  }, [isConnected, toast]);

  // Simulate periodic network activity for realism
  useEffect(() => {
    if (!isConnected) return;
    
    const interval = setInterval(() => {
      // Simulate minor balance fluctuations (gas fees, small transactions, etc.)
      if (Math.random() < 0.3) {
        const currentBalance = parseFloat(balance!.split(' ')[0]);
        const fluctuation = (Math.random() * 0.01) * (Math.random() > 0.5 ? 1 : -1);
        const newBalance = Math.max(0, currentBalance + fluctuation).toFixed(2) + " ETH";
        setBalance(newBalance);
      }
    }, 60000); // Check every minute
    
    return () => clearInterval(interval);
  }, [isConnected, balance]);

  return {
    isConnected,
    isConnecting,
    address,
    balance,
    network,
    connect,
    connectWallet,
    disconnect,
    sendTransaction,
    signMessage
  };
}

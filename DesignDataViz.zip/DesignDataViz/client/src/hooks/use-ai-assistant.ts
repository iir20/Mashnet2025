import { useState, useCallback, useEffect, useRef } from 'react';
import { useToast } from '@/hooks/use-toast';
import { v4 as uuidv4 } from 'uuid';

interface Message {
  id: string;
  content: string;
  isAI: boolean;
  timestamp: Date;
}

interface AIAssistantOptions {
  initialMessages?: Message[];
  enableShadowClone?: boolean;
}

export function useAIAssistant(options: AIAssistantOptions = {}) {
  const { initialMessages = [], enableShadowClone = false } = options;
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [isTyping, setIsTyping] = useState(false);
  const [aiPersonality, setAIPersonality] = useState<string>('helpful');
  const [lastSentiment, setLastSentiment] = useState<string | null>(null);
  const [isProcessingImage, setIsProcessingImage] = useState(false);
  const lastMessageRef = useRef<string>('');
  const { toast } = useToast();

  // Define AI capabilities
  const aiCapabilities = [
    { id: 'conversation', name: 'Natural conversation', icon: 'ri-chat-3-line' },
    { id: 'image-understanding', name: 'Image understanding', icon: 'ri-image-line' },
    { id: 'sentiment-analysis', name: 'Sentiment analysis', icon: 'ri-emotion-line' },
    { id: 'translation', name: 'Real-time translation', icon: 'ri-translate-2' },
    { id: 'summarization', name: 'Content summarization', icon: 'ri-file-list-3-line' },
    { id: 'code-analysis', name: 'Code analysis', icon: 'ri-code-line' }
  ];

  // AI Response generator using the API
  const generateAIResponse = useCallback(async (userMessage: string): Promise<string> => {
    try {
      // Convert message history to the format expected by the API
      const formattedPreviousMessages = messages
        .slice(-5) // Use last 5 messages for context
        .map(msg => ({
          role: msg.isAI ? "assistant" : "user",
          content: msg.content
        }));
      
      // Call the API endpoint
      const response = await fetch('/api/ai/generate-response', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          prompt: userMessage,
          personality: aiPersonality,
          previousMessages: formattedPreviousMessages
        }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to generate AI response');
      }
      
      const data = await response.json();
      return data.response;
    } catch (error) {
      console.error('Error generating AI response:', error);
      
      // Fallback responses if the API call fails
      let fallbackResponse = "I'm having trouble connecting to my neural networks right now. Please try again in a moment.";
      
      if (aiPersonality === 'quantum') {
        fallbackResponse = "Quantum decoherence detected in my neural pathways. Attempting to stabilize connection across probability space...";
      } else if (aiPersonality === 'concise') {
        fallbackResponse = "Connection error. Will retry shortly.";
      }
      
      return fallbackResponse;
    }
  }, [messages, aiPersonality]);

  // Send a message to the AI assistant
  const sendMessage = useCallback(async (content: string) => {
    // Create and add user message
    const userMessage: Message = {
      id: uuidv4(),
      content,
      isAI: false,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    lastMessageRef.current = content;
    
    // Start AI typing indicator
    setIsTyping(true);
    
    try {
      // Get AI response
      const aiResponse = await generateAIResponse(content);
      
      // Create and add AI message
      const aiMessage: Message = {
        id: uuidv4(),
        content: aiResponse,
        isAI: true,
        timestamp: new Date()
      };
      
      // Add AI message after a short delay to simulate typing
      setTimeout(() => {
        setMessages(prev => [...prev, aiMessage]);
        setIsTyping(false);
        
        // Randomly determine if the AI should be proactive
        if (enableShadowClone && Math.random() < 0.2 && messages.length > 3) {
          // Add a slight delay before the proactive follow-up
          setTimeout(() => {
            setIsTyping(true);
            
            setTimeout(() => {
              const proactiveContent = getProactiveResponse(aiResponse);
              
              const proactiveMessage: Message = {
                id: uuidv4(),
                content: proactiveContent,
                isAI: true,
                timestamp: new Date()
              };
              
              setMessages(prev => [...prev, proactiveMessage]);
              setIsTyping(false);
            }, 1500);
          }, 3000);
        }
      }, aiResponse.length * 20);
    } catch (error) {
      console.error('Error generating AI response:', error);
      setIsTyping(false);
      
      toast({
        title: 'AI Processing Error',
        description: 'There was an error generating a response. Please try again.',
        variant: 'destructive'
      });
    }
  }, [messages, generateAIResponse, toast, enableShadowClone]);

  // Generate a proactive follow-up response
  const getProactiveResponse = (lastAIResponse: string): string => {
    const proactiveResponses = [
      "I just had another thought about this that might be helpful...",
      "Building on what I just mentioned, you might also want to consider...",
      "Additionally, I should point out that...",
      "I've analyzed this further and found something interesting...",
      "One more thing that could be relevant here..."
    ];
    
    const randomStarter = proactiveResponses[Math.floor(Math.random() * proactiveResponses.length)];
    let proactiveContent = "";
    
    if (lastAIResponse.includes("quantum") || lastAIResponse.includes("encryption")) {
      proactiveContent = " our quantum encryption uses post-quantum cryptographic algorithms that are resistant to attacks from both classical and quantum computers.";
    } else if (lastAIResponse.includes("token") || lastAIResponse.includes("reward")) {
      proactiveContent = " you can earn $MASH tokens through regular participation, community contributions, and completing specific challenges within the platform.";
    } else if (lastAIResponse.includes("message") || lastAIResponse.includes("chat")) {
      proactiveContent = " messages sent in quantum mode are automatically encrypted and can be set to disappear after being viewed.";
    } else {
      proactiveContent = " Quantum Nexus also offers features like multiverse mode for parallel conversations and time capsule messaging for scheduled future delivery.";
    }
    
    return randomStarter + proactiveContent;
  };

  // Clear the conversation
  const clearConversation = useCallback(() => {
    setMessages([]);
    
    toast({
      title: 'Conversation Cleared',
      description: 'All messages have been removed from this conversation',
      variant: 'default'
    });
  }, [toast]);

  // Summarize the conversation using the API
  const summarizeConversation = useCallback(async () => {
    if (messages.length < 2) {
      toast({
        title: 'Nothing to Summarize',
        description: 'Have a conversation first before requesting a summary',
        variant: 'destructive'
      });
      return;
    }
    
    setIsTyping(true);
    
    try {
      // Format the conversation as a string
      const conversationText = messages
        .map(msg => `${msg.isAI ? 'AI Assistant' : 'User'}: ${msg.content}`)
        .join('\n\n');
      
      // Call the API endpoint
      const response = await fetch('/api/ai/summarize', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ conversation: conversationText }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to summarize conversation');
      }
      
      const data = await response.json();
      
      const summaryMessage: Message = {
        id: uuidv4(),
        content: "📝 **Conversation Summary**\n\n" + data.summary,
        isAI: true,
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, summaryMessage]);
    } catch (error) {
      console.error('Error summarizing conversation:', error);
      
      toast({
        title: 'Summarization Error',
        description: 'There was an error summarizing the conversation. Please try again later.',
        variant: 'destructive'
      });
      
      // Simple fallback if the API fails
      const fallbackSummary = "Unable to generate a detailed summary at this time. The conversation covered " + 
        (messages.some(m => m.content.toLowerCase().includes('quantum')) ? "quantum technology, " : "") +
        (messages.some(m => m.content.toLowerCase().includes('web3')) ? "Web3 concepts, " : "") +
        (messages.some(m => m.content.toLowerCase().includes('token')) ? "token systems, " : "") +
        "and related topics.";
      
      const summaryMessage: Message = {
        id: uuidv4(),
        content: "📝 **Conversation Summary**\n\n" + fallbackSummary,
        isAI: true,
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, summaryMessage]);
    } finally {
      setIsTyping(false);
    }
  }, [messages, toast]);

  // Process an image using the OpenAI API
  const processImage = useCallback(async (base64Image: string) => {
    setIsProcessingImage(true);
    
    toast({
      title: 'Processing Image',
      description: 'Analyzing image content using quantum neural network...',
      variant: 'default'
    });
    
    try {
      // Call the image analysis API
      const response = await fetch('/api/ai/analyze-image', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ base64Image }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to analyze image');
      }
      
      const data = await response.json();
      
      const imageAnalysisMessage: Message = {
        id: uuidv4(),
        content: "🖼️ **Image Analysis**\n\n" + data.analysis,
        isAI: true,
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, imageAnalysisMessage]);
    } catch (error) {
      console.error('Error analyzing image:', error);
      
      toast({
        title: 'Image Analysis Error',
        description: 'There was an error analyzing the image. Please try again later.',
        variant: 'destructive'
      });
      
      // Fallback message if the API fails
      const fallbackAnalysisMessage: Message = {
        id: uuidv4(),
        content: "🖼️ **Image Analysis**\n\nI'm unable to analyze this image at the moment. The image processing service is currently unavailable. Please try again later.",
        isAI: true,
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, fallbackAnalysisMessage]);
    } finally {
      setIsProcessingImage(false);
    }
  }, [toast]);

  // Detect sentiment in text using the API
  const detectSentiment = useCallback(async (text: string) => {
    try {
      const response = await fetch('/api/ai/analyze-sentiment', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ text }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to analyze sentiment');
      }
      
      const analysis = await response.json();
      const sentiment = analysis.sentiment.toLowerCase();
      
      setLastSentiment(sentiment);
      return sentiment;
    } catch (error) {
      console.error('Error analyzing sentiment:', error);
      // Fallback to a simple analysis
      const lowerText = text.toLowerCase();
      let sentiment = 'neutral';
      
      const positiveWords = ['happy', 'good', 'great', 'excellent', 'love', 'like', 'best'];
      const negativeWords = ['sad', 'bad', 'terrible', 'hate', 'dislike', 'worst', 'awful'];
      
      const positiveCount = positiveWords.filter(word => lowerText.includes(word)).length;
      const negativeCount = negativeWords.filter(word => lowerText.includes(word)).length;
      
      if (positiveCount > negativeCount) {
        sentiment = 'positive';
      } else if (negativeCount > positiveCount) {
        sentiment = 'negative';
      }
      
      setLastSentiment(sentiment);
      return sentiment;
    }
  }, []);

  // Translate text to another language using the API
  const translateMessage = useCallback(async (text: string, targetLanguage: string = 'fr') => {
    if (!text) {
      toast({
        title: 'No Text to Translate',
        description: 'Please provide text for translation',
        variant: 'destructive'
      });
      return;
    }
    
    setIsTyping(true);
    
    try {
      // Call the translation API
      const response = await fetch('/api/ai/translate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          text, 
          targetLanguage 
        }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to translate text');
      }
      
      const data = await response.json();
      
      // Create language flag emoji based on target language
      let languageEmoji = '🌐';
      let languageName = targetLanguage.toUpperCase();
      
      switch (targetLanguage.toLowerCase()) {
        case 'fr':
          languageEmoji = '🇫🇷';
          languageName = 'French';
          break;
        case 'es':
          languageEmoji = '🇪🇸';
          languageName = 'Spanish';
          break;
        case 'de':
          languageEmoji = '🇩🇪';
          languageName = 'German';
          break;
        case 'ja':
          languageEmoji = '🇯🇵';
          languageName = 'Japanese';
          break;
        case 'zh':
          languageEmoji = '🇨🇳';
          languageName = 'Chinese';
          break;
        case 'ru':
          languageEmoji = '🇷🇺';
          languageName = 'Russian';
          break;
        case 'ar':
          languageEmoji = '🇸🇦';
          languageName = 'Arabic';
          break;
        case 'hi':
          languageEmoji = '🇮🇳';
          languageName = 'Hindi';
          break;
      }
      
      const translationMessage: Message = {
        id: uuidv4(),
        content: `${languageEmoji} **${languageName} Translation**\n\n${data.translation}`,
        isAI: true,
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, translationMessage]);
    } catch (error) {
      console.error('Error translating text:', error);
      
      toast({
        title: 'Translation Error',
        description: 'There was an error translating your text. Please try again later.',
        variant: 'destructive'
      });
      
      // Fallback message for failed translation
      const translationMessage: Message = {
        id: uuidv4(),
        content: `Translation service is currently unavailable. Please try again later.`,
        isAI: true,
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, translationMessage]);
    } finally {
      setIsTyping(false);
    }
  }, [toast, setMessages]);

  // Run sentiment analysis on user messages
  useEffect(() => {
    const lastMessage = messages[messages.length - 1];
    if (lastMessage && !lastMessage.isAI) {
      detectSentiment(lastMessage.content);
    }
  }, [messages, detectSentiment]);

  return {
    messages,
    isTyping,
    sendMessage,
    clearConversation,
    aiCapabilities,
    aiPersonality,
    setAIPersonality,
    summarizeConversation,
    isProcessingImage,
    processImage,
    detectSentiment,
    translateMessage,
    lastSentiment
  };
}
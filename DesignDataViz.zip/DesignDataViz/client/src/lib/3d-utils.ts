import { createRef, RefObject } from "react";
import { Object3D, Vector3, Quaternion, Euler, Color, MathUtils } from "three";

// Helper for managing orbital paths for 3D visualizations
export interface OrbitalConfig {
  radius: number;
  speed: number;
  offset: number;
  elevation: number;
  clockwise?: boolean;
}

export interface Particle3D {
  position: Vector3;
  rotation: Euler;
  color: Color | string;
  size: number;
  ref: RefObject<Object3D>;
}

// Create particles arranged in orbital paths
export function createOrbitalParticles(
  count: number,
  configs: OrbitalConfig[]
): Particle3D[] {
  const particles: Particle3D[] = [];

  for (let i = 0; i < count; i++) {
    // Select configuration based on index
    const configIndex = i % configs.length;
    const config = configs[configIndex];
    
    // Calculate position on orbital path
    const angle = (i / Math.max(1, count / configs.length)) * Math.PI * 2 + config.offset;
    const x = Math.sin(angle) * config.radius;
    const z = Math.cos(angle) * config.radius * (config.clockwise ? -1 : 1);
    const y = config.elevation;
    
    // Create color based on position
    const hue = (i / count) * 360;
    const colorString = `hsl(${hue}, 80%, 60%)`;
    
    // Create particle
    particles.push({
      position: new Vector3(x, y, z),
      rotation: new Euler(0, angle, 0),
      color: colorString,
      size: 0.1 + Math.random() * 0.2,
      ref: createRef<Object3D>()
    });
  }

  return particles;
}

// Animate orbital particles
export function animateParticle(
  ref: RefObject<Object3D>,
  config: OrbitalConfig,
  time: number
): void {
  if (!ref.current) return;
  
  const angle = time * config.speed + config.offset;
  const x = Math.sin(angle) * config.radius;
  const z = Math.cos(angle) * config.radius * (config.clockwise ? -1 : 1);
  
  ref.current.position.x = x;
  ref.current.position.z = z;
  ref.current.position.y = config.elevation;
  
  // Add slight rotation for visual interest
  ref.current.rotation.y = angle;
}

// Generate a random 3D position within bounds
export function randomPosition(bounds: number = 5): Vector3 {
  return new Vector3(
    (Math.random() - 0.5) * bounds,
    (Math.random() - 0.5) * bounds,
    (Math.random() - 0.5) * bounds
  );
}

// Generate a random 3D rotation
export function randomRotation(): Quaternion {
  return new Quaternion().setFromEuler(
    new Euler(
      Math.random() * Math.PI * 2,
      Math.random() * Math.PI * 2,
      Math.random() * Math.PI * 2
    )
  );
}

// Linear interpolation between two Vector3s
export function lerpVectors(
  start: Vector3,
  end: Vector3,
  alpha: number
): Vector3 {
  return new Vector3().lerpVectors(start, end, alpha);
}

// Create a path following a helix
export function createHelixPath(
  radius: number,
  height: number,
  turns: number,
  pointCount: number
): Vector3[] {
  const points: Vector3[] = [];
  
  for (let i = 0; i < pointCount; i++) {
    const t = i / (pointCount - 1);
    const angle = t * turns * Math.PI * 2;
    
    const x = Math.cos(angle) * radius;
    const y = t * height - height / 2; // Center vertically
    const z = Math.sin(angle) * radius;
    
    points.push(new Vector3(x, y, z));
  }
  
  return points;
}

// Convert chat messages to 3D visualization data
export function messagesTo3DData(
  messages: any[],
  radius: number = 3
): Particle3D[] {
  const particles: Particle3D[] = [];
  const messageCount = messages.length;
  
  // Default orbital configurations for different sender types
  const orbitalConfigs: Record<string, OrbitalConfig> = {
    user: {
      radius: radius * 0.7,
      speed: 0.1,
      offset: 0,
      elevation: 0.5,
      clockwise: true
    },
    ai: {
      radius: radius,
      speed: 0.05,
      offset: Math.PI / 2,
      elevation: 0,
      clockwise: false
    },
    system: {
      radius: radius * 1.3,
      speed: 0.03,
      offset: Math.PI,
      elevation: -0.5,
      clockwise: true
    }
  };
  
  messages.forEach((message, index) => {
    // Determine message type
    let type = "system";
    if (message.senderId === 1) type = "user";
    else if (message.senderId === 2) type = "ai";
    
    // Select configuration based on message type
    const config = orbitalConfigs[type];
    
    // Adjust position based on index to distribute messages
    const angleOffset = (index / messageCount) * Math.PI * 2;
    const individualConfig = {
      ...config,
      offset: config.offset + angleOffset
    };
    
    // Calculate color based on message type
    let color: string;
    if (type === "user") color = "#00F0FF"; // Cyan
    else if (type === "ai") color = "#7B61FF"; // Purple
    else color = "#FF00E5"; // Magenta
    
    // Adjust size based on message content length
    const size = 0.15 + Math.min(0.2, message.content.length / 500);
    
    // Create particle
    particles.push({
      position: new Vector3(
        Math.sin(angleOffset) * config.radius,
        config.elevation,
        Math.cos(angleOffset) * config.radius * (config.clockwise ? -1 : 1)
      ),
      rotation: new Euler(0, angleOffset, 0),
      color,
      size,
      ref: createRef<Object3D>()
    });
  });
  
  return particles;
}

// Function to create floating animation parameters
export function createFloatingAnimationParams(intensity: number = 1): {
  amplitude: Vector3;
  frequency: Vector3;
  offset: Vector3;
} {
  return {
    amplitude: new Vector3(
      0.1 * intensity * Math.random(),
      0.1 * intensity * Math.random(),
      0.1 * intensity * Math.random()
    ),
    frequency: new Vector3(
      0.5 + Math.random() * 0.5,
      0.5 + Math.random() * 0.5,
      0.5 + Math.random() * 0.5
    ),
    offset: new Vector3(
      Math.random() * Math.PI * 2,
      Math.random() * Math.PI * 2,
      Math.random() * Math.PI * 2
    )
  };
}

// Apply floating animation to object
export function applyFloatingAnimation(
  object: Object3D,
  originalPosition: Vector3,
  params: {
    amplitude: Vector3;
    frequency: Vector3;
    offset: Vector3;
  },
  time: number
): void {
  if (!object) return;
  
  object.position.x = originalPosition.x + 
    Math.sin(time * params.frequency.x + params.offset.x) * params.amplitude.x;
  
  object.position.y = originalPosition.y + 
    Math.sin(time * params.frequency.y + params.offset.y) * params.amplitude.y;
  
  object.position.z = originalPosition.z + 
    Math.sin(time * params.frequency.z + params.offset.z) * params.amplitude.z;
  
  // Add subtle rotation
  object.rotation.x = Math.sin(time * params.frequency.x * 0.5) * 0.05;
  object.rotation.y += 0.001; // Constant slow rotation
  object.rotation.z = Math.sin(time * params.frequency.z * 0.5) * 0.05;
}

// Create a glow effect material parameters
export interface GlowEffectParams {
  color: string;
  intensity: number;
  size: number;
  opacityPulse?: boolean;
}

// Convert HSL color values to string
export function hslToColorString(h: number, s: number, l: number): string {
  return `hsl(${h}, ${s}%, ${l}%)`;
}

// Generate pulsating value
export function pulsate(
  min: number,
  max: number,
  frequency: number,
  time: number,
  phaseOffset: number = 0
): number {
  return MathUtils.lerp(
    min,
    max,
    (Math.sin(time * frequency + phaseOffset) + 1) / 2
  );
}

// Convert RGB color to hex string
export function rgbToHex(r: number, g: number, b: number): string {
  return "#" + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
}

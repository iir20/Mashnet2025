import { Switch, Route } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";

import Home from "@/pages/home";
import Chat from "@/pages/chat";
import Multiverse from "@/pages/multiverse";
import Profile from "@/pages/profile";
import NotFound from "@/pages/not-found";
import { ThemeProvider } from "next-themes";
import FloatingActionButton from "./components/ui/floating-action-button";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/chat/:id" component={Chat} />
      <Route path="/multiverse" component={Multiverse} />
      <Route path="/profile" component={Profile} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ThemeProvider defaultTheme="dark" attribute="class">
      <TooltipProvider>
        <div className="bg-space-dark min-h-screen text-text-primary">
          <Toaster />
          <Router />
          <FloatingActionButton />
        </div>
      </TooltipProvider>
    </ThemeProvider>
  );
}

export default App;

import { 
  type User, type InsertUser, 
  type Message, type InsertMessage, 
  type Chatroom, type InsertChatroom,
  type ChatroomParticipant, type InsertChatroomParticipant,
  users, messages, chatrooms, chatroomParticipants
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc } from "drizzle-orm";

// Storage Interface
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserTokens(userId: number, amount: number): Promise<User | undefined>;
  
  // Chatroom operations
  getChatroom(id: number): Promise<Chatroom | undefined>;
  getAllChatrooms(): Promise<Chatroom[]>;
  createChatroom(chatroom: InsertChatroom): Promise<Chatroom>;
  
  // Message operations
  getMessage(id: number): Promise<Message | undefined>;
  getMessagesByChatroom(chatroomId: number): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  
  // Chatroom participant operations
  getChatroomParticipants(chatroomId: number): Promise<ChatroomParticipant[]>;
  addChatroomParticipant(participant: InsertChatroomParticipant): Promise<ChatroomParticipant>;
}

// Memory Storage Implementation
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private messages: Map<number, Message>;
  private chatrooms: Map<number, Chatroom>;
  private chatroomParticipants: Map<number, ChatroomParticipant>;
  
  private userId: number;
  private messageId: number;
  private chatroomId: number;
  private participantId: number;
  
  constructor() {
    this.users = new Map();
    this.messages = new Map();
    this.chatrooms = new Map();
    this.chatroomParticipants = new Map();
    
    this.userId = 1;
    this.messageId = 1;
    this.chatroomId = 1;
    this.participantId = 1;
    
    // Initialize with some demo data
    this.setupInitialData();
  }
  
  private setupInitialData() {
    // Create default user
    const user: User = {
      id: this.userId++,
      username: "anon_user",
      password: "password123",
      walletAddress: "0x742d35Cc6634C0532925a3b844Bc454e4438f44e",
      avatarUrl: null,
      tokenBalance: 250,
      reputation: 75,
      nftBadges: [
        { id: 1, name: "Early Adopter", image: "badge_early_adopter.svg" },
        { id: 2, name: "Data Wizard", image: "badge_data_wizard.svg" }
      ],
      createdAt: new Date()
    };
    this.users.set(user.id, user);
    
    // Create AI assistant user
    const aiUser: User = {
      id: this.userId++,
      username: "ai_assistant",
      password: "secure_password",
      walletAddress: null,
      avatarUrl: null,
      tokenBalance: 0,
      reputation: 100,
      nftBadges: [],
      createdAt: new Date()
    };
    this.users.set(aiUser.id, aiUser);
    
    // Create default chatroom
    const chatroom: Chatroom = {
      id: this.chatroomId++,
      name: "General Chat",
      type: "standard",
      ownerUserId: user.id,
      metadata: {},
      isPublic: true,
      createdAt: new Date()
    };
    this.chatrooms.set(chatroom.id, chatroom);
    
    // Create a multiverse chatroom
    const multiverseChatroom: Chatroom = {
      id: this.chatroomId++,
      name: "Multiverse Alpha",
      type: "multiverse",
      ownerUserId: user.id,
      metadata: {
        dimension: "alpha",
        color: "#7B61FF"
      },
      isPublic: true,
      createdAt: new Date()
    };
    this.chatrooms.set(multiverseChatroom.id, multiverseChatroom);
    
    // Add user as participant to both chatrooms
    const participant1: ChatroomParticipant = {
      id: this.participantId++,
      chatroomId: chatroom.id,
      userId: user.id,
      joinedAt: new Date()
    };
    this.chatroomParticipants.set(participant1.id, participant1);
    
    const participant2: ChatroomParticipant = {
      id: this.participantId++,
      chatroomId: multiverseChatroom.id,
      userId: user.id,
      joinedAt: new Date()
    };
    this.chatroomParticipants.set(participant2.id, participant2);
    
    // Add AI assistant as participant to general chat
    const aiParticipant: ChatroomParticipant = {
      id: this.participantId++,
      chatroomId: chatroom.id,
      userId: aiUser.id,
      joinedAt: new Date()
    };
    this.chatroomParticipants.set(aiParticipant.id, aiParticipant);
    
    // Add some initial messages
    const welcomeMessage: Message = {
      id: this.messageId++,
      senderId: aiUser.id,
      chatroomId: chatroom.id,
      content: "Welcome to NexusViz Messenger! How can I assist you today?",
      isEncrypted: false,
      metadata: {},
      disappearAt: null,
      createdAt: new Date(Date.now() - 3600000) // 1 hour ago
    };
    this.messages.set(welcomeMessage.id, welcomeMessage);
  }
  
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }
  
  async createUser(userData: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = {
      ...userData,
      id,
      tokenBalance: 0,
      reputation: 0,
      nftBadges: [],
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }
  
  async updateUserTokens(userId: number, amount: number): Promise<User | undefined> {
    const user = await this.getUser(userId);
    if (!user) return undefined;
    
    const updatedUser: User = {
      ...user,
      tokenBalance: user.tokenBalance + amount
    };
    
    this.users.set(userId, updatedUser);
    return updatedUser;
  }
  
  // Chatroom operations
  async getChatroom(id: number): Promise<Chatroom | undefined> {
    return this.chatrooms.get(id);
  }
  
  async getAllChatrooms(): Promise<Chatroom[]> {
    return Array.from(this.chatrooms.values());
  }
  
  async createChatroom(chatroomData: InsertChatroom): Promise<Chatroom> {
    const id = this.chatroomId++;
    const chatroom: Chatroom = {
      ...chatroomData,
      id,
      metadata: {},
      createdAt: new Date()
    };
    this.chatrooms.set(id, chatroom);
    return chatroom;
  }
  
  // Message operations
  async getMessage(id: number): Promise<Message | undefined> {
    return this.messages.get(id);
  }
  
  async getMessagesByChatroom(chatroomId: number): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter(message => message.chatroomId === chatroomId)
      .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
  }
  
  async createMessage(messageData: InsertMessage): Promise<Message> {
    const id = this.messageId++;
    const message: Message = {
      ...messageData,
      id,
      metadata: {},
      createdAt: new Date()
    };
    this.messages.set(id, message);
    return message;
  }
  
  // Chatroom participant operations
  async getChatroomParticipants(chatroomId: number): Promise<ChatroomParticipant[]> {
    return Array.from(this.chatroomParticipants.values())
      .filter(participant => participant.chatroomId === chatroomId);
  }
  
  async addChatroomParticipant(participantData: InsertChatroomParticipant): Promise<ChatroomParticipant> {
    const id = this.participantId++;
    const participant: ChatroomParticipant = {
      ...participantData,
      id,
      joinedAt: new Date()
    };
    this.chatroomParticipants.set(id, participant);
    return participant;
  }
}

// Database Storage Implementation
export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username));
    return result[0];
  }
  
  async createUser(userData: InsertUser): Promise<User> {
    const result = await db.insert(users).values({
      username: userData.username,
      password: userData.password,
      walletAddress: userData.walletAddress || null,
      avatarUrl: userData.avatarUrl || null,
      tokenBalance: 0,
      reputation: 0,
      nftBadges: []
    }).returning();
    
    return result[0];
  }
  
  async updateUserTokens(userId: number, amount: number): Promise<User | undefined> {
    const user = await this.getUser(userId);
    if (!user) return undefined;
    
    const result = await db.update(users)
      .set({ tokenBalance: user.tokenBalance + amount })
      .where(eq(users.id, userId))
      .returning();
    
    return result[0];
  }
  
  // Chatroom operations
  async getChatroom(id: number): Promise<Chatroom | undefined> {
    const result = await db.select().from(chatrooms).where(eq(chatrooms.id, id));
    return result[0];
  }
  
  async getAllChatrooms(): Promise<Chatroom[]> {
    return await db.select().from(chatrooms);
  }
  
  async createChatroom(chatroomData: InsertChatroom): Promise<Chatroom> {
    const result = await db.insert(chatrooms).values({
      ...chatroomData,
      metadata: {}
    }).returning();
    
    return result[0];
  }
  
  // Message operations
  async getMessage(id: number): Promise<Message | undefined> {
    const result = await db.select().from(messages).where(eq(messages.id, id));
    return result[0];
  }
  
  async getMessagesByChatroom(chatroomId: number): Promise<Message[]> {
    return await db.select()
      .from(messages)
      .where(eq(messages.chatroomId, chatroomId))
      .orderBy(messages.createdAt);
  }
  
  async createMessage(messageData: InsertMessage): Promise<Message> {
    const result = await db.insert(messages).values({
      ...messageData,
      metadata: {}
    }).returning();
    
    return result[0];
  }
  
  // Chatroom participant operations
  async getChatroomParticipants(chatroomId: number): Promise<ChatroomParticipant[]> {
    return await db.select()
      .from(chatroomParticipants)
      .where(eq(chatroomParticipants.chatroomId, chatroomId));
  }
  
  async addChatroomParticipant(participantData: InsertChatroomParticipant): Promise<ChatroomParticipant> {
    const result = await db.insert(chatroomParticipants)
      .values(participantData)
      .returning();
    
    return result[0];
  }
  
  // Method to set up initial data in the database
  async setupInitialData(): Promise<void> {
    // Check if there's at least one user already
    const existingUsers = await db.select().from(users).limit(1);
    if (existingUsers.length > 0) {
      return; // Data already exists, no need to set up
    }
    
    // Create default user
    const user = await this.createUser({
      username: "anon_user",
      password: "password123",
      walletAddress: "0x742d35Cc6634C0532925a3b844Bc454e4438f44e",
      avatarUrl: null
    });
    
    // Update user with additional data
    await db.update(users)
      .set({
        tokenBalance: 250,
        reputation: 75,
        nftBadges: [
          { id: 1, name: "Early Adopter", image: "badge_early_adopter.svg" },
          { id: 2, name: "Data Wizard", image: "badge_data_wizard.svg" }
        ]
      })
      .where(eq(users.id, user.id));
    
    // Create AI assistant user
    const aiUser = await this.createUser({
      username: "ai_assistant",
      password: "secure_password",
      walletAddress: null,
      avatarUrl: null
    });
    
    // Update AI user with additional data
    await db.update(users)
      .set({
        reputation: 100
      })
      .where(eq(users.id, aiUser.id));
    
    // Create default chatroom
    const chatroom = await this.createChatroom({
      name: "General Chat",
      type: "standard",
      ownerUserId: user.id,
      isPublic: true
    });
    
    // Create a multiverse chatroom
    const multiverseChatroom = await this.createChatroom({
      name: "Multiverse Alpha",
      type: "multiverse",
      ownerUserId: user.id,
      isPublic: true
    });
    
    // Update multiverse chatroom with metadata
    await db.update(chatrooms)
      .set({
        metadata: {
          dimension: "alpha",
          color: "#7B61FF"
        }
      })
      .where(eq(chatrooms.id, multiverseChatroom.id));
    
    // Add user as participant to both chatrooms
    await this.addChatroomParticipant({
      chatroomId: chatroom.id,
      userId: user.id
    });
    
    await this.addChatroomParticipant({
      chatroomId: multiverseChatroom.id,
      userId: user.id
    });
    
    // Add AI assistant as participant to general chat
    await this.addChatroomParticipant({
      chatroomId: chatroom.id,
      userId: aiUser.id
    });
    
    // Add initial welcome message
    await this.createMessage({
      senderId: aiUser.id,
      chatroomId: chatroom.id,
      content: "Welcome to NexusViz Messenger! How can I assist you today?",
      isEncrypted: false,
      disappearAt: null
    });
  }
}

// Initialize storage with database implementation
export const storage = new DatabaseStorage();

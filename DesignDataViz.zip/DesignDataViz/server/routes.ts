import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertMessageSchema, insertChatroomSchema, insertChatroomParticipantSchema } from "@shared/schema";
import { generateAssistantResponse, analyzeSentiment, translateText, summarizeConversation, analyzeImage } from "./openai";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // API Routes prefix with /api
  
  // User routes
  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const newUser = await storage.createUser(userData);
      res.status(201).json(newUser);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid user data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create user" });
      }
    }
  });

  app.get("/api/users/:id", async (req, res) => {
    const userId = parseInt(req.params.id);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }
    
    const user = await storage.getUser(userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    res.json(user);
  });

  // Chatroom routes
  app.post("/api/chatrooms", async (req, res) => {
    try {
      const chatroomData = insertChatroomSchema.parse(req.body);
      const newChatroom = await storage.createChatroom(chatroomData);
      res.status(201).json(newChatroom);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid chatroom data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create chatroom" });
      }
    }
  });

  app.get("/api/chatrooms", async (req, res) => {
    const chatrooms = await storage.getAllChatrooms();
    res.json(chatrooms);
  });

  app.get("/api/chatrooms/:id", async (req, res) => {
    const chatroomId = parseInt(req.params.id);
    if (isNaN(chatroomId)) {
      return res.status(400).json({ message: "Invalid chatroom ID" });
    }
    
    const chatroom = await storage.getChatroom(chatroomId);
    if (!chatroom) {
      return res.status(404).json({ message: "Chatroom not found" });
    }
    
    res.json(chatroom);
  });

  // Message routes
  app.post("/api/messages", async (req, res) => {
    try {
      const messageData = insertMessageSchema.parse(req.body);
      const newMessage = await storage.createMessage(messageData);
      res.status(201).json(newMessage);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid message data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create message" });
      }
    }
  });

  app.get("/api/chatrooms/:id/messages", async (req, res) => {
    const chatroomId = parseInt(req.params.id);
    if (isNaN(chatroomId)) {
      return res.status(400).json({ message: "Invalid chatroom ID" });
    }
    
    const messages = await storage.getMessagesByChatroom(chatroomId);
    res.json(messages);
  });

  // Chatroom participants
  app.post("/api/chatrooms/:chatroomId/participants", async (req, res) => {
    const chatroomId = parseInt(req.params.chatroomId);
    if (isNaN(chatroomId)) {
      return res.status(400).json({ message: "Invalid chatroom ID" });
    }
    
    try {
      const participantData = insertChatroomParticipantSchema.parse({
        ...req.body,
        chatroomId
      });
      
      const newParticipant = await storage.addChatroomParticipant(participantData);
      res.status(201).json(newParticipant);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid participant data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to add participant" });
      }
    }
  });

  app.get("/api/chatrooms/:chatroomId/participants", async (req, res) => {
    const chatroomId = parseInt(req.params.chatroomId);
    if (isNaN(chatroomId)) {
      return res.status(400).json({ message: "Invalid chatroom ID" });
    }
    
    const participants = await storage.getChatroomParticipants(chatroomId);
    res.json(participants);
  });

  // Simulated Web3 API endpoints
  app.get("/api/web3/wallet/:address", (req, res) => {
    const { address } = req.params;
    res.json({
      address,
      isConnected: true,
      balance: "0.42 ETH",
      network: "Ethereum Mainnet"
    });
  });

  app.get("/api/web3/nft/:userId", async (req, res) => {
    const userId = parseInt(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }
    
    const user = await storage.getUser(userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    res.json(user.nftBadges || []);
  });

  app.post("/api/web3/tokens/:userId/reward", async (req, res) => {
    const userId = parseInt(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }
    
    try {
      const { amount } = req.body;
      if (typeof amount !== 'number' || amount <= 0) {
        return res.status(400).json({ message: "Invalid token amount" });
      }
      
      const user = await storage.updateUserTokens(userId, amount);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json({ success: true, tokenBalance: user.tokenBalance });
    } catch (error) {
      res.status(500).json({ message: "Failed to reward tokens" });
    }
  });

  // AI Assistant endpoints
  app.post("/api/ai/generate-response", async (req, res) => {
    try {
      const { prompt, personality, previousMessages } = req.body;
      
      if (!prompt || typeof prompt !== 'string') {
        return res.status(400).json({ message: "Valid prompt is required" });
      }
      
      const response = await generateAssistantResponse(
        prompt,
        personality || "helpful",
        previousMessages || []
      );
      
      res.json({ response });
    } catch (error) {
      console.error("Error generating AI response:", error);
      res.status(500).json({ message: "Failed to generate AI response" });
    }
  });
  
  app.post("/api/ai/analyze-sentiment", async (req, res) => {
    try {
      const { text } = req.body;
      
      if (!text || typeof text !== 'string') {
        return res.status(400).json({ message: "Valid text is required" });
      }
      
      const analysis = await analyzeSentiment(text);
      res.json(analysis);
    } catch (error) {
      console.error("Error analyzing sentiment:", error);
      res.status(500).json({ message: "Failed to analyze sentiment" });
    }
  });
  
  app.post("/api/ai/translate", async (req, res) => {
    try {
      const { text, targetLanguage } = req.body;
      
      if (!text || typeof text !== 'string') {
        return res.status(400).json({ message: "Valid text is required" });
      }
      
      if (!targetLanguage || typeof targetLanguage !== 'string') {
        return res.status(400).json({ message: "Valid target language is required" });
      }
      
      const translation = await translateText(text, targetLanguage);
      res.json({ translation });
    } catch (error) {
      console.error("Error translating text:", error);
      res.status(500).json({ message: "Failed to translate text" });
    }
  });
  
  app.post("/api/ai/summarize", async (req, res) => {
    try {
      const { conversation } = req.body;
      
      if (!conversation || typeof conversation !== 'string') {
        return res.status(400).json({ message: "Valid conversation is required" });
      }
      
      const summary = await summarizeConversation(conversation);
      res.json({ summary });
    } catch (error) {
      console.error("Error summarizing conversation:", error);
      res.status(500).json({ message: "Failed to summarize conversation" });
    }
  });
  
  app.post("/api/ai/analyze-image", async (req, res) => {
    try {
      const { base64Image } = req.body;
      
      if (!base64Image || typeof base64Image !== 'string') {
        return res.status(400).json({ message: "Valid base64 image is required" });
      }
      
      // Remove data URL prefix if present
      const imageData = base64Image.replace(/^data:image\/\w+;base64,/, '');
      
      const analysis = await analyzeImage(imageData);
      res.json({ analysis });
    } catch (error) {
      console.error("Error analyzing image:", error);
      res.status(500).json({ message: "Failed to analyze image" });
    }
  });

  // Create HTTP server
  const httpServer = createServer(app);

  return httpServer;
}

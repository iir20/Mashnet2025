import OpenAI from "openai";

// The newest OpenAI model is "gpt-4o" which was released May 13, 2024. Do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Basic text generation for the AI assistant
export async function generateAssistantResponse(
  userPrompt: string,
  personality: string = "helpful",
  previousMessages: { role: "user" | "assistant"; content: string }[] = []
): Promise<string> {
  try {
    // Create a system message based on personality
    let systemMessage = "You are a helpful AI assistant.";
    
    switch (personality) {
      case "creative":
        systemMessage = "You are a creative AI assistant who thinks outside the box and suggests innovative ideas. Your responses are imaginative and inspiring.";
        break;
      case "analytical":
        systemMessage = "You are an analytical AI assistant who focuses on data, logic, and structured thinking. Your responses are detailed, methodical, and evidence-based.";
        break;
      case "friendly":
        systemMessage = "You are a friendly, conversational AI assistant who maintains a warm and approachable tone. You use casual language and are encouraging.";
        break;
      case "concise":
        systemMessage = "You are a concise AI assistant who provides brief, direct answers without unnecessary details. You value efficiency and clarity.";
        break;
      case "quantum":
        systemMessage = "You are a futuristic quantum AI assistant with an advanced understanding of cutting-edge technology. Your responses reference quantum computing, blockchain, decentralized systems, and other advanced concepts.";
        break;
      default:
        systemMessage = "You are a helpful AI assistant who provides balanced, informative responses.";
    }
    
    // Add context about Quantum Nexus app
    systemMessage += " You are integrated into the Quantum Nexus 3.0 messenger application, which features Web3 technologies, decentralized communication, and futuristic interfaces.";
    
    // Create message history
    const messages = [
      { role: "system", content: systemMessage },
      ...previousMessages,
      { role: "user", content: userPrompt }
    ];
    
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: messages as any,
      max_tokens: 300,
      temperature: personality === 'creative' ? 0.8 : personality === 'analytical' ? 0.2 : 0.5,
    });

    return response.choices[0].message.content || "I couldn't process your request at this time.";
  } catch (error) {
    console.error("Error generating AI response:", error);
    return "I'm currently experiencing a technical issue. Please try again later.";
  }
}

// Analyze sentiment of text
export async function analyzeSentiment(text: string): Promise<{
  sentiment: string,
  confidence: number,
  emotion: string
}> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content:
            "You are a sentiment analysis expert. Analyze the sentiment of the text and provide a rating. Respond with JSON in this format: { 'sentiment': 'positive', 'negative', or 'neutral', 'confidence': number between 0 and 1, 'emotion': most dominant emotion }"
        },
        {
          role: "user",
          content: text
        }
      ],
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");

    return {
      sentiment: result.sentiment || "neutral",
      confidence: result.confidence || 0.5,
      emotion: result.emotion || "neutral"
    };
  } catch (error) {
    console.error("Error analyzing sentiment:", error);
    return {
      sentiment: "neutral",
      confidence: 0.5,
      emotion: "neutral"
    };
  }
}

// Translate text
export async function translateText(text: string, targetLanguage: string): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are a translation expert. Translate the provided text into ${targetLanguage}. Only respond with the translated text, nothing else.`
        },
        {
          role: "user",
          content: text
        }
      ]
    });

    return response.choices[0].message.content || "Translation error";
  } catch (error) {
    console.error("Error translating text:", error);
    return "Translation error";
  }
}

// Summarize conversation
export async function summarizeConversation(conversationHistory: string): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a conversation summarization expert. Provide a concise summary of the main points in the conversation."
        },
        {
          role: "user",
          content: `Please summarize this conversation:\n\n${conversationHistory}`
        }
      ],
      max_tokens: 150
    });

    return response.choices[0].message.content || "Summary generation error";
  } catch (error) {
    console.error("Error summarizing conversation:", error);
    return "Summary generation error";
  }
}

// Image analysis
export async function analyzeImage(base64Image: string): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: "Analyze this image in detail and describe its key elements, context, and any notable aspects."
            },
            {
              type: "image_url",
              image_url: {
                url: `data:image/jpeg;base64,${base64Image}`
              }
            }
          ],
        },
      ],
      max_tokens: 300,
    });

    return response.choices[0].message.content || "Image analysis error";
  } catch (error) {
    console.error("Error analyzing image:", error);
    return "Image analysis error";
  }
}
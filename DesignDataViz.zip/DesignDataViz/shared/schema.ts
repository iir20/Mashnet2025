import { pgTable, text, serial, integer, timestamp, json, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { relations } from "drizzle-orm";
import { z } from "zod";

// User model
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  walletAddress: text("wallet_address"),
  avatarUrl: text("avatar_url"),
  tokenBalance: integer("token_balance").default(0),
  reputation: integer("reputation").default(0),
  nftBadges: json("nft_badges").default([]),
  createdAt: timestamp("created_at").defaultNow()
});

// Message model
export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  senderId: integer("sender_id").notNull(),
  chatroomId: integer("chatroom_id").notNull(),
  content: text("content").notNull(),
  isEncrypted: boolean("is_encrypted").default(false),
  metadata: json("metadata").default({}),
  disappearAt: timestamp("disappear_at"),
  createdAt: timestamp("created_at").defaultNow()
});

// Chatroom model
export const chatrooms = pgTable("chatrooms", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull().default("standard"), // standard, multiverse, ar
  ownerUserId: integer("owner_user_id").notNull(),
  metadata: json("metadata").default({}),
  isPublic: boolean("is_public").default(true),
  createdAt: timestamp("created_at").defaultNow()
});

// ChatroomParticipant model
export const chatroomParticipants = pgTable("chatroom_participants", {
  id: serial("id").primaryKey(),
  chatroomId: integer("chatroom_id").notNull(),
  userId: integer("user_id").notNull(),
  joinedAt: timestamp("joined_at").defaultNow()
});

// Add relationships between tables
export const usersRelations = relations(users, ({ many }) => ({
  messages: many(messages),
  participations: many(chatroomParticipants),
  ownedChatrooms: many(chatrooms, { relationName: "chatroom_owner" })
}));

export const messagesRelations = relations(messages, ({ one }) => ({
  sender: one(users, {
    fields: [messages.senderId],
    references: [users.id]
  }),
  chatroom: one(chatrooms, {
    fields: [messages.chatroomId],
    references: [chatrooms.id]
  })
}));

export const chatroomsRelations = relations(chatrooms, ({ many, one }) => ({
  messages: many(messages),
  participants: many(chatroomParticipants),
  owner: one(users, {
    fields: [chatrooms.ownerUserId],
    references: [users.id],
    relationName: "chatroom_owner"
  })
}));

export const chatroomParticipantsRelations = relations(chatroomParticipants, ({ one }) => ({
  user: one(users, {
    fields: [chatroomParticipants.userId],
    references: [users.id]
  }),
  chatroom: one(chatrooms, {
    fields: [chatroomParticipants.chatroomId],
    references: [chatrooms.id]
  })
}));

// Schemas for insert operations
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  tokenBalance: true,
  reputation: true,
  nftBadges: true
});

export const insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
  createdAt: true,
  metadata: true
});

export const insertChatroomSchema = createInsertSchema(chatrooms).omit({
  id: true,
  createdAt: true,
  metadata: true
});

export const insertChatroomParticipantSchema = createInsertSchema(chatroomParticipants).omit({
  id: true,
  joinedAt: true
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Message = typeof messages.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;

export type Chatroom = typeof chatrooms.$inferSelect;
export type InsertChatroom = z.infer<typeof insertChatroomSchema>;

export type ChatroomParticipant = typeof chatroomParticipants.$inferSelect;
export type InsertChatroomParticipant = z.infer<typeof insertChatroomParticipantSchema>;
